﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightDispatchClient
{
    public class GameSyncCommand
    {
        public string Sender { get; set; }
        public string ActionType { get; set; }
        public string TargetId { get; set; }
        public string AdditionalData { get; set; }
        public string RoomId { get; set; }
        public string RoomPassword { get; set; }
    }
}
