﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightDispatchClient
{
    public class AirportReport
    {
        public string AirportName { get; set; }
        public string Icao { get; set; }
        public int FinalLevel { get; set; }
        public int StrandedPax { get; set; }
        public int MaxCapacity { get; set; }
        public long TotalProfit { get; set; }
        public int FleetSize { get; set; }
        public int DailyPaxRate { get; set; }
    }
}
