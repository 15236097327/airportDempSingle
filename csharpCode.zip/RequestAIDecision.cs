﻿using GMap.NET;
using GMap.NET.WindowsPresentation;
using System;
using System.IO;
using System.Linq;         // 🌟 新增：处理列表转换必须用到它
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace FlightDispatchClient
{
    // 🌟 核心秘诀：依然叫 MainWindow，但加上了 partial 关键字
    public partial class MainWindow : Window
    {
        // ==========================================
        // 📡 跨界通信：呼叫 Python AI 大脑 (DQN 强化学习版)
        // ==========================================
        private static readonly HttpClient httpClient = new HttpClient();
        private double aiLastReward = 0.0;
        public bool isFastTrainingMode = false;
        // ==========================================
        // 🧠 强化学习：全局记忆与轮回控制
        // ==========================================
        // private double aiLastReward = 0.0;
        private bool aiIsDone = false; // 死亡宣告标志
        private int epochCount = 0;    // 记录活了几辈子

        // 🌟 核心：世界重置函数 (AI 死后重新投胎)
        // ==========================================
        // 🌟 核心：世界重置函数 (AI 死后重新投胎)
        // ==========================================
      
// 🌟 1. 剧本动作的实体类
public class ScriptAction
    {
        public string action { get; set; }
        public string from { get; set; }
        public string to { get; set; }
        public string target_id { get; set; }
}

// 🌟 2. 在全局定义一个剧本字典 (Tick -> 动作列表)
private Dictionary<string, List<ScriptAction>> godScript = new Dictionary<string, List<ScriptAction>>();
        private void ResetWorldForNextEpoch()
        {
            if (gameTimer != null) gameTimer.Stop();
            if (animationTimer != null) animationTimer.Stop();
            gameVirtualTime = new DateTime(2026, 1, 1, 6, 0, 0);
            epochCount++;
            TxtRadioLog.Text += $"\n\n=======================================";
            TxtRadioLog.Text += $"\n🌀 [系统]: 第 {epochCount} 宇宙重启中...";
            TxtRadioLog.Text += $"\n=======================================";

            // 1. 恢复初始资金与状态
            playerFunds = 5000000000;
            totalTransportedPax = 0;
            gameTickCount = 0;
            TxtFunds.Text = $"💰 资金: {playerFunds:N0}";

            // 2. 清理天空：删除所有飞机、航线、箭头
            var markersToRemove = MainMap.Markers.Where(m =>
                m.Shape is System.Windows.Shapes.Path ||
                (m.Shape is TextBlock tb && (tb.Text == "✈" || tb.Text == "➤"))
            ).ToList();

            foreach (var m in markersToRemove) MainMap.Markers.Remove(m);

            flyingPlanes.Clear();
            activeRoutes.Clear();

            // 3. 重置所有机场：清空乘客、没收飞机、降级为 1 级
            foreach (var apt in allAirportsList)
            {
                apt.CurrentPassengers = 0;
                apt.Level = 1;

                // 🌟 完美修复：读取该机场专属的真实初始容量！
                apt.MaxCapacity = apt.InitialCapacity;

                apt.LocalFleet.Clear();

                if (apt.Demands != null)
                {
                    foreach (var key in apt.Demands.Keys.ToList()) apt.Demands[key] = 0;
                }
            }

            // 🌟 补丁：清理上一局遗留的突发事件 (台风、奥运等)
            if (activeEvents != null) activeEvents.Clear();

            // ==========================================
            // 🎁 核心保底机制：新手大礼包 (防落地成盒)
            // ==========================================
            if (allAirportsList.Count >= 2)
            {
                // 自动找客流量最大的前两个枢纽机场
                var topAirports = allAirportsList.OrderByDescending(a => a.DailyPaxRate).Take(2).ToList();
                var apt1 = topAirports[0];
                var apt2 = topAirports[1];

                // 1. 开局强行给这两个核心枢纽各送一架飞机！
                apt1.LocalFleet.Add(new GamePlaneInfo { Id = "SEED-01", Model = PlaneModelType.Regional, Level = 1 });
                apt2.LocalFleet.Add(new GamePlaneInfo { Id = "SEED-02", Model = PlaneModelType.Regional, Level = 1 });

                // 🌟 2. 终极保底：免费给它修一条往返的高速公路！打破连环锁！
                var marker1 = MainMap.Markers.FirstOrDefault(m => (m.Shape as FrameworkElement)?.Tag == apt1);
                var marker2 = MainMap.Markers.FirstOrDefault(m => (m.Shape as FrameworkElement)?.Tag == apt2);

                if (marker1 != null && marker2 != null)
                {
                    System.Windows.Shapes.Path starterPath = new System.Windows.Shapes.Path
                    {
                        Stroke = Brushes.LimeGreen, // 💚 新手保护色
                        StrokeThickness = 2,
                        StrokeDashArray = new DoubleCollection(new double[] { 4, 2 }),
                        Opacity = 0.6,
                        IsHitTestVisible = false
                    };

                    GMap.NET.WindowsPresentation.GMapRoute starterRoute = new GMap.NET.WindowsPresentation.GMapRoute(new List<GMap.NET.PointLatLng> { marker1.Position, marker2.Position })
                    {
                        Shape = starterPath,
                        ZIndex = 50
                    };
                    MainMap.Markers.Add(starterRoute);

                    // 注入物理世界：双向航线全开，让它随便飞都能成功！
                    activeRoutes.Add(new GameRouteInfo { StartNode = marker1, EndNode = marker2 });
                    activeRoutes.Add(new GameRouteInfo { StartNode = marker2, EndNode = marker1 });
                }

                TxtRadioLog.Text += $"\n🎁 [最高指令]: 已向 {apt1.Name} 与 {apt2.Name} 空投初始机队，并开通免费保底航线！";
            }
            // ==========================================

            // 4. 重置 AI 标志位
            aiLastReward = 0.0;
            aiIsDone = false;
            isGameOver = false; // 🌟 补丁：确保游戏逻辑锁解除

            if (TxtRadioLog.Parent is ScrollViewer svLog) svLog.ScrollToBottom();

            // 5. 重新点火
            if (gameTimer != null) gameTimer.Start();
            if (animationTimer != null) animationTimer.Start();
        }
        private void LoadGodScript()
        {
            try
            {
                string filePath = "Timetable_Final.json";

                // 1. 先查岗：文件到底在不在？
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("🚨 致命错误：找不到 Timetable_Final.json！\n请确保它被放到了项目的 bin\\Debug\\netX.X\\ 文件夹下！", "天网系统报警");
                    return;
                }

                // 2. 读取并反序列化
                string jsonString = File.ReadAllText(filePath);
                godScript = JsonSerializer.Deserialize<Dictionary<string, List<ScriptAction>>>(jsonString);

                // 3. 成功弹窗！
                MessageBox.Show($"✅ 上帝剧本载入成功！\n共读取到 {godScript.Count} 个时间节点的微操指令！", "天网系统启动");
            }
            catch (Exception ex)
            {
                // 4. 崩溃弹窗！
                MessageBox.Show($"❌ 剧本读取失败！\n报错信息: {ex.Message}", "天网系统崩溃");
            }
        }
        private void ExecuteScriptAction(ScriptAction cmd)
        {
            // 1. 起飞指令
            // 1. 起飞指令
            // 1. 起飞指令
            if (cmd.action == "LAUNCH_FLIGHT")
            {
                var startInfo = allAirportsList.FirstOrDefault(a => a.Name == cmd.from);
                if (startInfo != null)
                {
                    TryAutoLaunchPlane(startInfo, cmd.to); // 直接调底层！它现在绝对服从！
                    LogToRadio($"🛫 [天网调度]: 航班起飞 {cmd.from} ➔ {cmd.to}");
                }
            }
            // 2. 修建航线指令
            // 2. 修建航线指令 (完全体带 UI 渲染版)
            // 2. 修建航线指令 (完美适配 GMap.NET 霓虹弧线版)
            else if (cmd.action == "OPEN_ROUTE")
            {
                // 🌟 1. 精准抓取 GMap 上的机场 Marker
                GMapMarker sMarker = MainMap.Markers.FirstOrDefault(m => m.Shape is FrameworkElement fe && (fe.Tag as GameAirportInfo)?.Name == cmd.from);
                GMapMarker eMarker = MainMap.Markers.FirstOrDefault(m => m.Shape is FrameworkElement fe && (fe.Tag as GameAirportInfo)?.Name == cmd.to);

                if (sMarker != null && eMarker != null)
                {
                    // 扣除基建资金
                    playerFunds -= 10000000;

                    // ==========================================
                    // 🌟 2. 注入你的赛博朋克贝塞尔曲线算法
                    // ==========================================
                    double sLat = sMarker.Position.Lat, sLng = sMarker.Position.Lng;
                    double eLat = eMarker.Position.Lat, eLng = eMarker.Position.Lng;

                    List<PointLatLng> arcPts = new List<PointLatLng>();
                    double mLat = (sLat + eLat) / 2.0, mLng = (sLng + eLng) / 2.0;
                    // 控制点偏移，制造完美弧度
                    double cLat = mLat + (eLng - sLng) * 0.2, cLng = mLng - (eLat - sLat) * 0.2;

                    for (int i = 0; i <= 20; i++)
                    {
                        double t = i / 20.0, u = 1 - t;
                        arcPts.Add(new PointLatLng((u * u * sLat) + (2 * u * t * cLat) + (t * t * eLat), (u * u * sLng) + (2 * u * t * cLng) + (t * t * eLng)));
                    }

                    // 随机分配霓虹色彩
                    Color[] neonColors = { Color.FromArgb(200, 0, 255, 255), Color.FromArgb(200, 255, 0, 255), Color.FromArgb(200, 255, 165, 0), Color.FromArgb(200, 50, 255, 50) };
                    Color rColor = neonColors[new Random().Next(neonColors.Length)];

                    // 生成带发光特效的路径
                    GMapRoute fRoute = new GMapRoute(arcPts)
                    {
                        Shape = new System.Windows.Shapes.Path
                        {
                            Stroke = new SolidColorBrush(rColor),
                            StrokeThickness = 2,
                            StrokeDashArray = new DoubleCollection { 4, 3 },
                            Effect = new System.Windows.Media.Effects.DropShadowEffect { Color = rColor, BlurRadius = 12, ShadowDepth = 0 }
                        }
                    };
                    MainMap.Markers.Add(fRoute);

                    // ==========================================
                    // 🌟 3. 注入你的动态指向箭头
                    // ==========================================
                    PointLatLng midP1 = arcPts[10];
                    PointLatLng midP2 = arcPts[11];
                    double arrowAngle = Math.Atan2(midP1.Lat - midP2.Lat, midP2.Lng - midP1.Lng) * 180 / Math.PI;

                    TextBlock arrowVis = new TextBlock
                    {
                        Text = "➤",
                        FontSize = 16,
                        Foreground = new SolidColorBrush(rColor),
                        RenderTransformOrigin = new Point(0.5, 0.5),
                        RenderTransform = new RotateTransform(arrowAngle),
                        IsHitTestVisible = false,
                        Tag = "ROUTE_ARROW"
                    };

                    GMapMarker arrowMarker = new GMapMarker(midP1)
                    {
                        Shape = arrowVis,
                        Offset = new Point(-8, -10),
                        ZIndex = 499
                    };
                    MainMap.Markers.Add(arrowMarker);

                    // ==========================================
                    // 🌟 4. 录入系统的物理内存
                    // ==========================================
                    double dist = CalculateDistance(sMarker.Position, eMarker.Position);
                    activeRoutes.Add(new GameRouteInfo { StartNode = sMarker, EndNode = eMarker, Distance = dist });

                    if (!isFastTrainingMode)
                    {
                        TxtRadioLog.Text += $"\n🛣️ [基建]: 斥资开通航线 {cmd.from} ⇋ {cmd.to}";
                    }
                }
            }
            // 3. 买飞机指令
            // 3. 买飞机指令
            else if (cmd.action == "BUY_PLANE")
            {
                var targetInfo = allAirportsList.FirstOrDefault(a => a.Name == cmd.target_id);
                if (targetInfo != null)
                {
                    playerFunds -= 80000000; // 扣除买飞机钱

                    // 🌟 极简初始化：只传核心属性，Capacity 等参数它会自动根据 Model 推导！
                    targetInfo.LocalFleet.Add(new GamePlaneInfo
                    {
                        Id = "A-" + Guid.NewGuid().ToString().Substring(0, 4),
                        Level = 1,
                        Model = PlaneModelType.Regional
                    });

                    if (!isFastTrainingMode)
                    {
                        TxtRadioLog.Text += $"\n✈️ [采购]: 向 {cmd.target_id} 空投了 1 架新客机！";
                    }
                }
            }// 4. 扩建机场指令
             // 4. 扩建机场指令 (天网剧本执行器)
            else if (cmd.action == "UPGRADE_BASE")
            {
                var targetInfo = allAirportsList.FirstOrDefault(a => a.Name == cmd.target_id);
                if (targetInfo != null && targetInfo.Level < 3)
                {
                    // 扣钱
                    long upgradeCost = targetInfo.Level == 1 ? 150000000 : 500000000;
                    playerFunds -= upgradeCost;

                    // ==========================================
                    // 🌟 致命修复：让 AI 的扩建也变成真实扩容！
                    // ==========================================
                    targetInfo.Level++;
                    targetInfo.MaxCapacity *= 3;

                    if (!isFastTrainingMode)
                    {
                        // 这里用你之前改好的 LogToRadio 或 TxtRadioLog.Text += 
                        TxtRadioLog.Text += $"\n🏗️ [基建]: 天网系统斥资 ¥{upgradeCost / 100000000.0}亿，将 {cmd.target_id} 扩建至 Lv.{targetInfo.Level}，容量暴增至 {targetInfo.MaxCapacity}！\n";

                        // 截断保命
                        if (TxtRadioLog.Text.Length > 5000) TxtRadioLog.Text = TxtRadioLog.Text.Substring(2000);
                        if (TxtRadioLog.Parent is ScrollViewer sv) sv.ScrollToBottom();

                        if (currentSelectedMarker != null && ((currentSelectedMarker.Shape as FrameworkElement).Tag as GameAirportInfo) == targetInfo)
                        {
                            RefreshPanelUI(targetInfo);
                        }
                    }
                }
            }
        }
        // 🌟 防内存崩溃的全局打印中心
        // 🌟 防内存崩溃的全局打印中心 (TextBlock 专用版)
        private void LogToRadio(string message)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                if (isFastTrainingMode) return; // 极速模式下彻底闭嘴，保显存

                // TextBlock 只能用 +=，但我们有下面的截断护体！
                TxtRadioLog.Text += message + "\n";

                // 永远只保留末尾的 3000 个字符 (大约几百行)，旧日志直接丢弃！
                if (TxtRadioLog.Text.Length > 5000)
                {
                    // 截取后半段，抛弃前半段，确保内存永远处于极低占用！
                    TxtRadioLog.Text = TxtRadioLog.Text.Substring(2000);
                }

                if (TxtRadioLog.Parent is ScrollViewer sv) sv.ScrollToBottom();
            });
        }
        private async void RequestAIDecision()
        {
            if (isWaitingForAI) return;

            try
            {
                isWaitingForAI = true;
                var airportsData = allAirportsList.Select(a => new
                {
                    name = a.Name,
                    level = a.Level,
                    pax = a.CurrentPassengers,
                    capacity = a.MaxCapacity,
                    planes = a.LocalFleet.Count
                }).ToList();

                var gameState = new
                {
                    funds = playerFunds,
                    tick = gameTickCount,
                    airports = airportsData,
                    last_reward = aiLastReward,
                    is_done = aiIsDone   // 🌟 告诉 Python 游戏是否结束
                };

                // 发送完立刻给一个“存活基础奖励”，并重置标志
                if (!aiIsDone) aiLastReward = 1.0; // 只要活着每 Tick 就给 1 分鼓励

                string jsonString = JsonSerializer.Serialize(gameState);
                var content = new StringContent(jsonString, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await httpClient.PostAsync("http://127.0.0.1:9000/api/dispatch", content);

                if (response.IsSuccessStatusCode)
                {
                    string responseString = await response.Content.ReadAsStringAsync();
                    using (JsonDocument doc = JsonDocument.Parse(responseString))
                    {
                        string action = doc.RootElement.GetProperty("action").GetString();

                        // 🌟 核心：收到重置确认，立刻执行世界重置！
                        if (action == "RESET_ACK")
                        {
                            ResetWorldForNextEpoch();
                            return;
                        }

                        string targetRoute = doc.RootElement.TryGetProperty("route_target", out var routeProp) ? routeProp.GetString() : "";
                        string targetId = doc.RootElement.TryGetProperty("target_id", out var idProp) ? idProp.GetString() : "";
                        bool isRandom = doc.RootElement.TryGetProperty("is_random", out var randProp) && randProp.GetBoolean();

                        // ==========================================
                        // 🤖 动作解码器与评价系统
                        // ==========================================
                        string mode = isRandom ? "🎲 [瞎蒙]" : "🧠 [深思]";
                        aiLastReward = -10.0;
                        if (action == "DO_NOTHING")
                        {
                            // 挂机攒钱，什么都不做
                        }
                        else if (action == "BUY_PLANE" && !string.IsNullOrEmpty(targetId))
                        {
                            var targetApt = allAirportsList.FirstOrDefault(a => a.Name == targetId);
                            long planeCost = 80000000; // 固定花费 8000 万

                            if (targetApt != null)
                            {
                                // 🌟 物理限制：一个机场最多只能停 10 架飞机！
                                if (targetApt.LocalFleet.Count >= 100)
                                {
                                    // 惩罚：停机坪都满了还塞？机毁人亡！
                                    aiLastReward = -500.0;
                                }
                                else if (playerFunds >= planeCost)
                                {
                                    playerFunds -= planeCost;
                                    // 🌟 永远只买基础款：Level 1 的支线客机 (Regional)
                                    targetApt.LocalFleet.Add(new GamePlaneInfo
                                    {
                                        Id = "AI-P" + gameTickCount,
                                        Model = PlaneModelType.Regional,
                                        Level = 1
                                    });

                                    aiLastReward = 0; // 投资不给分
                                    TxtRadioLog.Text += $"\n{mode}: 斥资 8000万 买入飞机部署于 {targetId}";
                                }
                                else
                                {
                                    aiLastReward = -500.0; // 惩罚：没钱硬买
                                }
                            }
                        }
                        else if (action == "UPGRADE_BASE" && !string.IsNullOrEmpty(targetId))
                        {
                            var targetApt = allAirportsList.FirstOrDefault(a => a.Name == targetId);

                            // 🌟 增加校验：必须先找到机场，再算钱和判断等级！
                            if (targetApt != null)
                            {
                                if (targetApt.Level >= 3)
                                {
                                    // 惩罚：满级了还硬升！
                                    aiLastReward = -500.0;
                                }
                                else
                                {
                                    // 🌟 核心修改：动态阶梯定价！
                                    // 1级升2级：1.5 亿； 2级升3级：直接飙升到 5 亿！(注意加 L 防止 long 溢出)
                                    long upgradeCost = targetApt.Level == 1 ? 150000000L : 500000000L;

                                    if (playerFunds >= upgradeCost)
                                    {
                                        playerFunds -= upgradeCost;
                                        targetApt.Level++;
                                        targetApt.MaxCapacity *= 3;

                                        // 投资行为不给正分
                                        aiLastReward = 0;
                                        TxtRadioLog.Text += $"\n{mode}: 斥资 {upgradeCost / 100000000.0}亿 将 {targetId} 扩建至 Lv.{targetApt.Level}";
                                    }
                                    else
                                    {
                                        // 惩罚：没钱乱升级
                                        aiLastReward = -500.0;
                                    }
                                }
                            }
                        }
                        else if (action == "OPEN_ROUTE" && !string.IsNullOrEmpty(targetRoute))
                        {
                            string[] parts = targetRoute.Split('_');
                            if (parts.Length == 2)
                            {
                                var apA = allAirportsList.FirstOrDefault(a => a.Name == parts[0]);
                                var apB = allAirportsList.FirstOrDefault(a => a.Name == parts[1]);
                                long routeCost = 100000000; // 开航线固定花费 1 亿

                                var markerA = MainMap.Markers.FirstOrDefault(m => (m.Shape as FrameworkElement)?.Tag == apA);
                                var markerB = MainMap.Markers.FirstOrDefault(m => (m.Shape as FrameworkElement)?.Tag == apB);

                                bool routeExists = activeRoutes.Any(r =>
                                    ((r.StartNode.Shape as FrameworkElement)?.Tag as GameAirportInfo) == apA &&
                                    ((r.EndNode.Shape as FrameworkElement)?.Tag as GameAirportInfo) == apB);

                                if (apA == null || apB == null || markerA == null || markerB == null)
                                {
                                    aiLastReward = -500.0; // 惩罚：机场不存在
                                }
                                else if (routeExists)
                                {
                                    aiLastReward = -500.0; // 惩罚：航线已经存在了还硬开
                                }
                                else if (playerFunds < routeCost)
                                {
                                    aiLastReward = -500.0; // 惩罚：没钱硬开航线
                                }
                                else
                                {
                                    playerFunds -= routeCost;

                                    // 🌟 绘制天网专属的视觉路线 (赛博蓝色虚线)
                                    System.Windows.Shapes.Path aiLinePath = new System.Windows.Shapes.Path
                                    {
                                        Stroke = Brushes.Cyan,
                                        StrokeThickness = 2,
                                        StrokeDashArray = new DoubleCollection(new double[] { 4, 2 }),
                                        Opacity = 0.6,
                                        IsHitTestVisible = false
                                    };

                                    GMap.NET.WindowsPresentation.GMapRoute aiRoute = new GMap.NET.WindowsPresentation.GMapRoute(new List<GMap.NET.PointLatLng> { markerA.Position, markerB.Position })
                                    {
                                        Shape = aiLinePath,
                                        ZIndex = 50
                                    };
                                    MainMap.Markers.Add(aiRoute);

                                    // 注册到全局航线网络中
                                    activeRoutes.Add(new GameRouteInfo
                                    {
                                        StartNode = markerA,
                                        EndNode = markerB
                                    });

                                    aiLastReward = 0; // 投资行为，不给正分
                                    TxtRadioLog.Text += $"\n{mode}: 斥资 1亿 开辟航线 【{parts[0]} ⇌ {parts[1]}】";
                                }
                            }
                        }
                        else if (action == "LAUNCH_FLIGHT" && !string.IsNullOrEmpty(targetRoute))
                        {
                            string[] parts = targetRoute.Split('_');
                            if (parts.Length == 2)
                            {
                                var startApt = allAirportsList.FirstOrDefault(a => a.Name == parts[0]);
                                var endApt = allAirportsList.FirstOrDefault(a => a.Name == parts[1]); // 获取终点

                                if (startApt != null && startApt.LocalFleet.Count > 0)
                                {
                                    // 🌟 增加极其重要的业务校验：终点必须真的有客流需求！
                                    if (startApt.Demands.ContainsKey(parts[1]) && startApt.Demands[parts[1]] > 0)
                                    {
                                        TryAutoLaunchPlane(startApt, parts[1]);

                                        // 🌟 唯一真神：成功把人运出去，给予史诗级重赏！
                                        aiLastReward = 500.0;
                                        TxtRadioLog.Text += $"\n{mode}: 成功调派航班 {parts[0]} -> {parts[1]}";
                                    }
                                    else
                                    {
                                        // 惩罚：瞎派飞机（没客人飞过去烧油吗？）
                                        aiLastReward = -200.0;
                                    }
                                }
                                else
                                {
                                    // 惩罚：起点根本没有飞机，你起飞个寂寞！
                                    aiLastReward = -500.0;
                                }
                            }
                        }

                        if (TxtRadioLog.Parent is ScrollViewer svLogInner) svLogInner.ScrollToBottom();
                    }
                }
            }
            catch (Exception) { /* 忽略通信错误防止刷屏 */ }
            finally
            {
                // 🌟 无论成功失败，确保最终解锁
                isWaitingForAI = false;
            }
        }

    }
}