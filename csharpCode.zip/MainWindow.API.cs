﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

namespace FlightDispatchClient
{
    /*
     BtnRegister_Click (注册)

BtnLogin_Click (登录)

SubmitScoreBtn_Click (提交基础战绩)

UploadReportBtn_Click (上传黑匣子)

BtnPersonalRecord_Click (获取历史档案)

DownloadReportBtn_Click (下载最新战报)

DownloadHistoryRecord_Click (从档案中提取 CSV)

FetchCloudLeaderboard (向云端请求排行榜数据)
     */
    public partial class MainWindow : Window
    {
        private async void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            string user = TxtLoginUsername.Text.Trim();
            string pass = TxtLoginPassword.Password;

            if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass))
            {
                MessageBox.Show("代号和密码不能为空！", "警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var request = new UserAuthRequest { username = user, password = pass };
            string json = JsonSerializer.Serialize(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                using (var client = new HttpClient())
                {
                    HttpResponseMessage res = await client.PostAsync("http://124.220.178.183:8084/api/user/register", content);
                    string reply = await res.Content.ReadAsStringAsync();

                    if (res.IsSuccessStatusCode) MessageBox.Show(reply, "注册成功", MessageBoxButton.OK, MessageBoxImage.Information);
                    else MessageBox.Show(reply, "注册失败", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex) { MessageBox.Show("连接服务器失败：" + ex.Message); }
        }

        private async void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string user = TxtLoginUsername.Text.Trim();
            string pass = TxtLoginPassword.Password;


            LoginOverlay.Visibility = Visibility.Collapsed;
            MessageBox.Show($"欢迎回来，指挥官 ！", "认证通过", MessageBoxButton.OK, MessageBoxImage.Information);
            
            if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass)) return;

            BtnLogin.Content = "📡 验证中...";
            BtnLogin.IsEnabled = false;

            var request = new UserAuthRequest { username = user, password = pass };
            string json = JsonSerializer.Serialize(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                using (var client = new HttpClient())
                {
                    HttpResponseMessage res = await client.PostAsync("http://124.220.178.183:8084/api/user/login", content);

                    if (res.IsSuccessStatusCode)
                    {
                        string loggedInName = await res.Content.ReadAsStringAsync();
                        TxtPlayerName.Text = loggedInName;
                        TxtPlayerName.IsReadOnly = true;
                        LoginOverlay.Visibility = Visibility.Collapsed;
                        MessageBox.Show($"欢迎回来，指挥官 {loggedInName}！", "认证通过", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        string errorMsg = await res.Content.ReadAsStringAsync();
                        MessageBox.Show(errorMsg, "认证拒绝", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("连接服务器失败：" + ex.Message); }
            finally
            {
                BtnLogin.Content = "🔓 登 录 调 度 系 统";
                BtnLogin.IsEnabled = true;
            }
        }

        private async void SubmitScoreBtn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null) btn.IsEnabled = false;

            // 🌟 发射锁定信标：告诉队友“基础战绩放着我来交！”
            if (currentGameMode == "COOP" && webSocket != null && webSocket.State == WebSocketState.Open)
            {
                await SendCommandAsync("LOCK_SUBMIT_BTN");
            }

            string finalTeamName = TxtPlayerName.Text;
            if (currentGameMode == "COOP")
            {
                finalTeamName = $"{TxtPlayerName.Text} & {partnerName} 联合舰队";
            }

            var recordPayload = new
            {
                playerName = finalTeamName,
                survivedDays = (gameVirtualTime - new DateTime(2026, 1, 1)).Days,
                transportedPax = totalTransportedPax,
                finalFunds = playerFunds,
                gameMode = currentGameMode
            };

            try
            {
                string json = JsonSerializer.Serialize(recordPayload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                using (var httpClient = new HttpClient())
                {
                    var response = await httpClient.PostAsync("http://124.220.178.183:8084/api/submit", content);
                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show($"战报已成功铭刻于全球云端！\n上传署名：{finalTeamName}", "最高荣誉");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("战报上传失败：" + ex.Message);
                if (btn != null) btn.IsEnabled = true;
            }
        }

        private async void UploadReportBtn_Click(object sender, RoutedEventArgs e)
        {
            if (currentSessionReport == null) return;

            Button btn = sender as Button;
            if (btn != null) { btn.IsEnabled = false; btn.Content = "📡 数据上传中..."; }

            // 🌟 发射锁定信标：告诉队友“详细黑匣子由我接管！”
            if (currentGameMode == "COOP" && webSocket != null && webSocket.State == WebSocketState.Open)
            {
                await SendCommandAsync("LOCK_UPLOAD_BTN");
            }

            // 🌟 组装联合舰队名称
            string finalTeamName = TxtPlayerName.Text;
            if (currentGameMode == "COOP")
            {
                finalTeamName = $"{TxtPlayerName.Text} & {partnerName} 联合舰队";
            }

            currentSessionReport.GameMode = currentGameMode;
            // 🚨 修复致命内鬼：这里必须用 finalTeamName，千万不能再用 TxtPlayerName 了！
            currentSessionReport.PlayerName = string.IsNullOrWhiteSpace(finalTeamName) ? "神秘指挥官" : finalTeamName;
            currentSessionReport.TransportedPax = totalTransportedPax;

            var options = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
            string jsonPayload = JsonSerializer.Serialize(currentSessionReport, options);
            var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            try
            {
                string serverUrl = "http://124.220.178.183:8084/api/report/upload";
                using (var httpClient = new HttpClient())
                {
                    // 🚀 第一发导弹：上传重量级黑匣子 (GameReport)
                    HttpResponseMessage response = await httpClient.PostAsync(serverUrl, content);
                    response.EnsureSuccessStatusCode();

                    // 🚀 第二发导弹：顺手全自动打榜！(PlayerRecord)
                    var recordPayload = new
                    {
                        playerName = finalTeamName,
                        survivedDays = currentSessionReport.SurvivedDays,
                        transportedPax = currentSessionReport.TransportedPax,
                        finalFunds = currentSessionReport.FinalFunds,
                        gameMode = currentGameMode
                    };
                    string lbJson = JsonSerializer.Serialize(recordPayload);
                    var lbContent = new StringContent(lbJson, Encoding.UTF8, "application/json");

                    // 自动静默调用打榜 API，无需玩家再点一次！
                    await httpClient.PostAsync("http://124.220.178.183:8084/api/submit", lbContent);
                }

                MessageBox.Show("✅ 详细数据已封存！\n🏆 联合舰队的战绩已同时铭刻于全球排行榜！", "全网广播成功", MessageBoxButton.OK, MessageBoxImage.Information);

                if (btn != null) btn.Content = "☁️ 数据已全网同步";
                // 顺手把另一个打榜按钮也锁死，防止重复提交
                if (SubmitScoreBtn != null) SubmitScoreBtn.IsEnabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"上传失败：\n{ex.Message}", "网络错误", MessageBoxButton.OK, MessageBoxImage.Error);
                if (btn != null) { btn.IsEnabled = true; btn.Content = "📤 重新上传详细数据"; }
            }
        }

        private async void BtnPersonalRecord_Click(object sender, RoutedEventArgs e)
        {
            string playerName = TxtPlayerName.Text;
            if (string.IsNullOrWhiteSpace(playerName) || playerName == "AOC-001")
            {
                MessageBox.Show("未检测到指挥官身份，请先登录系统！", "访问拒绝", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            BtnPersonalRecord.Content = "📡 正在连线总部档案库...";
            BtnPersonalRecord.IsEnabled = false;

            try
            {
                using (var httpClient = new HttpClient())
                {
                    string url = $"http://124.220.178.183:8084/api/report/history?playerName={Uri.EscapeDataString(playerName)}";
                    string json = await httpClient.GetStringAsync(url);

                    var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                    var historyList = JsonSerializer.Deserialize<List<GameReportPayload>>(json, options);

                    if (historyList != null && historyList.Count > 0)
                    {
                        TxtHistoryTitle.Text = $"🧑‍✈️ 指挥官 {playerName} 的服役档案";
                        TxtTotalGames.Text = historyList.Count.ToString();

                        // 🌟 核心火力改装：全部换成 Average() 场均计算！
                        TxtTotalDays.Text = historyList.Average(x => x.SurvivedDays).ToString("0.0");
                        TxtTotalPax.Text = historyList.Average(x => x.TransportedPax).ToString("N0");
                        TxtTotalWealth.Text = "¥ " + historyList.Average(x => x.FinalFunds).ToString("N0");

                        PersonalHistoryList.ItemsSource = null;
                        PersonalHistoryList.ItemsSource = historyList;
                        PersonalHistoryOverlay.Visibility = Visibility.Visible;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"获取档案失败，请检查网络：\n{ex.Message}", "卫星失联", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                BtnPersonalRecord.Content = "📊 我的专属服役档案";
                BtnPersonalRecord.IsEnabled = true;
            }
        }
        //下载最新战报
        private async void DownloadReportBtn_Click(object sender, RoutedEventArgs e)
        {
            string finalTeamName = TxtPlayerName.Text;
            if (currentGameMode == "COOP") finalTeamName = $"{TxtPlayerName.Text} & {partnerName} 联合舰队";
            string queryPlayerName = string.IsNullOrWhiteSpace(finalTeamName) ? "神秘指挥官" : finalTeamName;

            try
            {
                string url = $"http://124.220.178.183:8084/api/report/download?playerName={Uri.EscapeDataString(queryPlayerName)}";

                using (var httpClient = new HttpClient())
                {
                    string json = await httpClient.GetStringAsync(url);
                    var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                    var report = JsonSerializer.Deserialize<GameReportPayload>(json, options);

                    if (report == null || report.AirportStats == null)
                    {
                        MessageBox.Show("云端未找到该署名的战报数据！", "下载空投失败");
                        return;
                    }

                    // 🌟 同样呼叫 Windows 保存弹窗
                    Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
                    dlg.FileName = $"云端最新战报_{queryPlayerName}_{DateTime.Now:yyyyMMdd_HHmmss}.csv";
                    dlg.DefaultExt = ".csv";
                    dlg.Filter = "Excel CSV 数据表 (.csv)|*.csv";

                    if (dlg.ShowDialog() == true)
                    {
                        StringBuilder csv = new StringBuilder();
                        csv.AppendLine("机场名称,ICAO代码,最终等级,滞留旅客,最大容量,累计净利润(元),驻扎机队(架),每日客流基数");
                        foreach (var stat in report.AirportStats)
                        {
                            csv.AppendLine($"{stat.AirportName},{stat.Icao},{stat.FinalLevel},{stat.StrandedPax},{stat.MaxCapacity},{stat.TotalProfit},{stat.FleetSize},{stat.DailyPaxRate}");
                        }

                        File.WriteAllText(dlg.FileName, csv.ToString(), new UTF8Encoding(true));
                        MessageBox.Show($"✅ 云端最新战报已成功拉取！\n保存路径：{dlg.FileName}", "下载成功", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"拉取云端数据失败：\n{ex.Message}\n请确认您之前是否成功上传过数据。", "下载失败", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        //从档案中提取 CSV
        private void DownloadHistoryRecord_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            // 从按钮的数据上下文(DataContext)中，精准抓取这一行对应的战报数据！
            if (btn != null && btn.DataContext is GameReportPayload report)
            {
                if (report.AirportStats == null || report.AirportStats.Count == 0)
                {
                    MessageBox.Show("这份档案太古老了，黑匣子数据已损坏或未记录具体机场详情！", "数据缺失", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // 呼叫 Windows 原生文件保存弹窗
                Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
                // 清理时间字符串里的特殊符号，用来做默认文件名
                string safeTime = report.CreatedAt.Replace(":", "").Replace("-", "").Replace("T", "_");
                dlg.FileName = $"黑匣子档案_{report.PlayerName}_{safeTime}.csv";
                dlg.DefaultExt = ".csv";
                dlg.Filter = "Excel CSV 数据表 (.csv)|*.csv";

                // 如果指挥官点击了【保存】
                if (dlg.ShowDialog() == true)
                {
                    StringBuilder csv = new StringBuilder();
                    csv.AppendLine("机场名称,ICAO代码,最终等级,滞留旅客,最大容量,累计净利润(元),驻扎机队(架),每日客流基数");
                    foreach (var stat in report.AirportStats)
                    {
                        csv.AppendLine($"{stat.AirportName},{stat.Icao},{stat.FinalLevel},{stat.StrandedPax},{stat.MaxCapacity},{stat.TotalProfit},{stat.FleetSize},{stat.DailyPaxRate}");
                    }

                    try
                    {
                        File.WriteAllText(dlg.FileName, csv.ToString(), new UTF8Encoding(true));
                        MessageBox.Show($"✅ 绝密档案已成功提取！\n保存路径：{dlg.FileName}", "提取成功", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"文件写入失败，请检查文件是否被 Excel 占用：\n{ex.Message}", "导出错误", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        //向云端请求排行榜数据
        private async void FetchCloudLeaderboard(string endpoint, string mode)
        {
            try
            {
                string url = $"http://124.220.178.183:8084/api/leaderboard/{endpoint}?mode={mode}";
                using (var httpClient = new HttpClient())
                {
                    string json = await httpClient.GetStringAsync(url);
                    var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                    var records = JsonSerializer.Deserialize<List<PlayerRecord>>(json, options);

                    LeaderboardList.ItemsSource = null;
                    LeaderboardList.ItemsSource = records;
                }
            }
            catch (Exception ex)
            {
                // 静默处理或打日志，防止频繁点击弹窗轰炸
                Console.WriteLine($"排行榜拉取失败: {ex.Message}");
            }
        }
    }
}
