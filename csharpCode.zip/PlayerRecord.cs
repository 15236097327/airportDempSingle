﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightDispatchClient
{
    public class PlayerRecord
    {
        public string PlayerName { get; set; }
        public int SurvivedDays { get; set; }
        public long TransportedPax { get; set; }
        public long FinalFunds { get; set; }
        public string GameMode { get; set; }
        public string CreatedAt { get; set; }
        public string FormattedDate
        {
            get
            {
                if (DateTime.TryParse(CreatedAt, out DateTime dt))
                    return dt.ToString("yyyy-MM-dd HH:mm");
                return "远古记录";
            }
        }
    }
}
