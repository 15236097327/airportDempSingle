﻿using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlightDispatchClient
{
    public class ActiveRoute
    {
        public GMapMarker StartNode { get; set; } // 起点机场锚点
        public GMapMarker EndNode { get; set; }   // 终点机场锚点

        // 预留接口：如果您需要记录地图上那条画出来的线，可以存在这里
        public GMapRoute VisualLine { get; set; }
    }
}
