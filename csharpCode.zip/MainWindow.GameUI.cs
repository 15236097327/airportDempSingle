﻿using GMap.NET;
using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace FlightDispatchClient
{
    /*LoadDataBtn_Click (载入地图数据 & 开始游戏分发器)

BtnReady_Click (点击准备)

PauseGameBtn_Click (战术暂停)

RedDot_MouseLeftButtonDown (点击机场红点)

DrawRouteBtn_Click (点击开通航线)

MainMap_MouseMove (拉伸橡皮筋连线)

CompleteRoute (完成航线建设)

UpgradeAirportBtn_Click (升级机场)

BuyLocalPlaneBtn_Click (买飞机)

Flight_MouseLeftButtonDown (点击飞行中的飞机)

UrgentAirportsList_SelectionChanged (点击左侧的高危警报列表)

RefreshPanelUI (刷新机场信息 UI 界面)

TriggerGameOver (核弹洗地：触发结算面板，极其重要！)

RestartGameBtn_Click (重新开始游戏)*/
    public partial class MainWindow:Window
    {
        private async void LoadDataBtn_Click(object sender, RoutedEventArgs e)
        {
            activeEvents.Clear();
            // === 【状态分发器：游戏已加载数据，且未 Game Over】 ===
            if (allAirportsList.Count > 0 && !isGameOver)
            {
                if (!isGameStarted)
                {
                    if (sender != null && currentGameMode == "COOP")
                    {
                        MessageBox.Show(
                            "📡 联机指挥协议已锁定！\n\n" +
                            "当前为【双人合作模式】。请在右侧通信面板进驻房间并【准备】。\n" +
                            "当两名指挥官均就绪后，云端总部将自动下发全网同步点火指令！\n\n" +
                            "(如需进行单人演习，请先在左侧切换回【孤狼单机】模式)",
                            "防抢跑系统拦截",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);
                        return; // 强行阻断，拒发车！
                    }
                    // --- 情景 A：数据已就绪，但还没点过“开始调度” ---
                    isGameStarted = true;
                    LockGameModeUI(true);
                    gameTimer.Start();
                    animationTimer.Start();
                    // 在您原本的重置游戏代码里加上这句：
                    
                    LoadDataBtn.Content = "🛑 结束游戏 (主动结算)";
                    LoadDataBtn.Background = Brushes.Crimson;
                    return;
                }
                else
                {
                    // --- 情景 B：游戏已经开始（无论当前是正常跑还是战术暂停中！） ---

                    // 记录弹窗前的真实暂停状态，防止点“否”后状态错乱
                    bool wasPausedBeforeConfirm = isPaused;
                    // 在您原本的重置游戏代码里加上这句：
                    //LockGameModeUI(true); // 🔓 游戏重置，电闸解开，允许重新选模式
                    // 强制冻结时间流逝，等待局长确认
                    gameTimer.Stop();
                    animationTimer.Stop();

                    MessageBoxResult result = MessageBox.Show(
                        "指挥官，您确定要结束当前的调度任务吗？\n\n点击【是】将立刻进行资产盘点并锁定战绩，所有航线与航班将永久停止运作。\n点击【否】返回指挥中心继续调度。",
                        "🛑 营运结算确认",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Warning);

                    if (result == MessageBoxResult.Yes)
                    {
                        // 在您原本的重置游戏代码里加上这句：
                        // LockGameModeUI(false); // 🔓 游戏重置，电闸解开，允许重新选模式
                        LockGameModeUI(false);
                        string finalStatePayload = $"{playerFunds}|{totalTransportedPax}";

                        var stopCmd = new GameSyncCommand
                        {
                            ActionType = "SYNC_GAME_OVER",
                            Sender = TxtPlayerName.Text,
                            AdditionalData = finalStatePayload // 👈 夹带战绩私货
                        };
                        // 1. 发射核弹信标：利用你已有的通信组件，直接发送 ActionType 为 "SYNC_GAME_OVER" 的指令
                        if (webSocket != null && webSocket.State == WebSocketState.Open)
                        {
                            _ = SendCommandAsync("SYNC_GAME_OVER");
                        }


                        // 2. 本地立刻执行核弹洗地程序
                        TriggerGameOver(null);
                    }
                    else
                    {
                        // 如果局长后悔了（选了否）：
                        // 只有在弹窗前【没有暂停】的情况下，才恢复时间流动！
                        if (!wasPausedBeforeConfirm)
                        {
                            gameTimer.Start();
                            animationTimer.Start();
                        }
                    }
                    return;
                }
            }
            // 在您原本的开局代码里加上这句：
            // LockGameModeUI(true); // 🔒 游戏开始，咔哒！电闸锁死！
            // === 【下面是你原本的初始化逻辑（情景 C：初始状态，加载世界数据）】 ===
            // (注意：在这里要把 isGameStarted 重置为 false)
            LockGameModeUI(false);
            if (gameTimer != null) gameTimer.Stop();
            if (animationTimer != null) animationTimer.Stop();

            isGameOver = false;
            isPaused = false;
            isGameStarted = false; // <--- 记得在这里加上重置！
            if (PauseGameBtn != null)
            {
                PauseGameBtn.Visibility = Visibility.Visible;
                PauseGameBtn.Content = "⏸️ 战术暂停 (Bullet Time)";
                PauseGameBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF8C00"));
            }

            gameTickCount = 0;
            gameVirtualTime = new DateTime(2026, 1, 1, 6, 0, 0);

            playerFunds = 10000000000;
            totalTransportedPax = 0;
            GameOverOverlay.Visibility = Visibility.Collapsed;
            LoadGodScript();
            if (BtnUploadReport != null)
            {
                BtnUploadReport.IsEnabled = true;
                BtnUploadReport.Content = "📤 授权并上传详细数据";
            }

            if (SubmitScoreBtn != null)
            {
                SubmitScoreBtn.IsEnabled = true;
                SubmitScoreBtn.Content = "🏆 仅提交基础战绩";
            }

            TxtFunds.Text = $"💰 资金: {playerFunds:N0}";
            TxtFunds.Foreground = Brushes.Gold;

            currentSelectedMarker = null;
            AirportInfoPanel.Visibility = Visibility.Collapsed;
            isDrawingRoute = false;
            routeStartMarker = null;
            if (elasticLine != null) MainMap.Markers.Remove(elasticLine);

            foreach (var plane in flyingPlanes) MainMap.Markers.Remove(plane.Marker);
            flyingPlanes.Clear();
            activeRoutes.Clear();
            allAirportsList.Clear();
            UrgentAirportsList.ItemsSource = null;
            MainMap.Markers.Clear();

            LoadDataBtn.Content = "🌐 重新构建世界中...";
            LoadDataBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));

            List<PointLatLng> asiaPoints = new List<PointLatLng>
            {
                new PointLatLng(65, 70), new PointLatLng(65, 145),
                new PointLatLng(10, 145), new PointLatLng(10, 70)
            };
            GMapPolygon darkOverlay = new GMapPolygon(asiaPoints)
            {
                Shape = new System.Windows.Shapes.Path { Fill = new SolidColorBrush(Color.FromArgb(215, 10, 10, 15)), IsHitTestVisible = false }
            };
            MainMap.Markers.Add(darkOverlay);

            try
            {
                string filePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "airports.json");
                string responseBody = System.IO.File.ReadAllText(filePath);
                using (JsonDocument doc = JsonDocument.Parse(responseBody))
                {
                    JsonElement dataArray = doc.RootElement.GetProperty("data");
                    foreach (JsonElement ap in dataArray.EnumerateArray())
                    {
                        string name = ap.GetProperty("airport_name").GetString();
                        string icao = ap.GetProperty("icao_code").GetString();
                        double lat = ap.GetProperty("latitude").GetDouble();
                        double lon = ap.GetProperty("longitude").GetDouble();
                        int pax = ap.GetProperty("daily_pax_base").GetInt32();

                        double minSize = 8.0; double maxSize = 35.0;
                        double scale = (double)pax / 250000.0; if (scale > 1.0) scale = 1.0;
                        double dotSize = minSize + scale * (maxSize - minSize);

                        GMapMarker marker = new GMapMarker(new PointLatLng(lat, lon));

                        Ellipse redDot = new Ellipse
                        {
                            Width = dotSize,
                            Height = dotSize,
                            Fill = Brushes.Crimson,
                            Stroke = Brushes.White,
                            StrokeThickness = scale > 0.5 ? 2 : 1,
                            Cursor = Cursors.Hand
                        };

                        TextBlock nameLabel = new TextBlock
                        {
                            Text = name,
                            Foreground = new SolidColorBrush(Color.FromArgb(200, 220, 220, 220)),
                            FontSize = 11,
                            FontWeight = FontWeights.Bold,
                            IsHitTestVisible = false
                        };

                        Canvas markerVisual = new Canvas();
                        markerVisual.Children.Add(redDot);
                        markerVisual.Children.Add(nameLabel);
                        Canvas.SetLeft(nameLabel, dotSize + 4);
                        Canvas.SetTop(nameLabel, (dotSize - 15) / 2);

                        int gameRate = Math.Max(2, pax / 96);
                        int dynamicCapacity = (int)(10000 + (int)(pax * 1.5))/10;

                        redDot.Tag = new GameAirportInfo
                        {
                            Name = name,
                            Icao = icao,
                            DailyPaxRate = gameRate,
                            MaxCapacity = dynamicCapacity,
                            InitialCapacity = dynamicCapacity,
                            Latitude = lat, 
                            Longitude = lon
                        };
                        redDot.DataContext = marker;
                        redDot.MouseLeftButtonDown += RedDot_MouseLeftButtonDown;

                        marker.Shape = markerVisual;
                        markerVisual.Tag = redDot.Tag;
                        marker.Offset = new Point(-dotSize / 2, -dotSize / 2);

                        MainMap.Markers.Add(marker);
                        allAirportsList.Add(redDot.Tag as GameAirportInfo);
                    }

                    LoadDataBtn.Content = "▶️ 开始调度 (Start Game)";
                    LoadDataBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2E8B57"));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
        $"指挥官，世界地图构建引擎崩溃！\n\n【致命死因】: {ex.Message}\n【异常类型】: {ex.GetType().Name}",
        "情报处最高警告",
        MessageBoxButton.OK,
        MessageBoxImage.Error);
                LoadDataBtn.Content = "🌐 载入世界失败 (重试)";
                LoadDataBtn.Background = Brushes.Crimson;
            }
        }

        private async void BtnReady_Click(object sender, RoutedEventArgs e)
        {
            if (allAirportsList == null || allAirportsList.Count == 0)
            {
                MessageBox.Show("指挥官，请先点击左侧的【载入航空大亨世界】生成地图！", "战前检查", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            await SendCommandAsync("READY");

            BtnReady.Content = "⏳ 已准备，等待队友...";
            BtnReady.Background = Brushes.SeaGreen;
            BtnReady.IsEnabled = false;

            LoadDataBtn.IsEnabled = false;
            LoadDataBtn.Content = "⏳ 等待全网同步发令...";
        }
        private async void PauseGameBtn_Click(object sender, RoutedEventArgs e)
        {
            if (webSocket != null && webSocket.State == WebSocketState.Open)
            {
                await SendCommandAsync(isPaused ? "RESUME" : "PAUSE");
            }
            else
            {
                var dummyCmd = new GameSyncCommand { Sender = "本地指令", ActionType = isPaused ? "RESUME" : "PAUSE" };
                ExecuteSyncCommand(dummyCmd);
            }
        }

        private void RedDot_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            if (isGameOver) return;

            if (sender is FrameworkElement element && element.Tag is GameAirportInfo info)
            {
                if (isDrawingRoute && routeStartMarker != null)
                {
                    CompleteRoute(routeStartMarker, element.DataContext as GMapMarker);
                    return;
                }

                currentSelectedMarker = element.DataContext as GMapMarker;
                RefreshPanelUI(info);
                AirportInfoPanel.Visibility = Visibility.Visible;
            }
        }
        private void DrawRouteBtn_Click(object sender, RoutedEventArgs e)
        {
            if (currentSelectedMarker == null) return;

            var info = (currentSelectedMarker.Shape as FrameworkElement).Tag as GameAirportInfo;
            if (info.LocalFleet.Count <= 0)
            {
                MessageBox.Show("该机场没有驻扎飞机，无法开通航线！请先购买飞机。", "调度提醒");
                return;
            }

            isDrawingRoute = true;
            routeStartMarker = currentSelectedMarker;
            AirportInfoPanel.Visibility = Visibility.Collapsed;
        }

        private void MainMap_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawingRoute && routeStartMarker != null)
            {
                Point mousePos = e.GetPosition(MainMap);
                PointLatLng mouseLatLng = MainMap.FromLocalToLatLng((int)mousePos.X, (int)mousePos.Y);

                if (elasticLine != null)
                {
                    MainMap.Markers.Remove(elasticLine);
                }

                List<PointLatLng> pts = new List<PointLatLng> { routeStartMarker.Position, mouseLatLng };

                elasticLine = new GMapRoute(pts)
                {
                    Shape = new System.Windows.Shapes.Path
                    {
                        Stroke = Brushes.Cyan,
                        StrokeThickness = 2,
                        StrokeDashArray = new DoubleCollection { 4, 2 },
                        IsHitTestVisible = false
                    },
                    ZIndex = 500
                };

                MainMap.Markers.Add(elasticLine);

                double distanceKm = MainMap.MapProvider.Projection.GetDistance(routeStartMarker.Position, mouseLatLng);
                long previewCost = (long)(distanceKm * 50000);

                if (costPreviewMarker == null)
                {
                    TextBlock costTxt = new TextBlock
                    {
                        Background = new SolidColorBrush(Color.FromArgb(200, 10, 10, 20)),
                        Foreground = Brushes.Lime,
                        Padding = new Thickness(6),
                        FontWeight = FontWeights.Bold,
                        IsHitTestVisible = false
                    };
                    costPreviewMarker = new GMapMarker(mouseLatLng) { Shape = costTxt, Offset = new Point(20, 20), ZIndex = 1005 };
                    MainMap.Markers.Add(costPreviewMarker);
                }

                ((TextBlock)costPreviewMarker.Shape).Text = $"💰 预估建线费用: ¥ {previewCost:N0}\n📏 航程: {distanceKm:F1} km";
                costPreviewMarker.Position = mouseLatLng;
            }
        }
        private async void CompleteRoute(GMapMarker start, GMapMarker end)
        {
            isDrawingRoute = false;
            if (elasticLine != null) MainMap.Markers.Remove(elasticLine);
            if (costPreviewMarker != null)
            {
                MainMap.Markers.Remove(costPreviewMarker);
                costPreviewMarker = null;
            }

            if (start == end) return;

            var startInfo = (start.Shape as FrameworkElement).Tag as GameAirportInfo;
            var endInfo = (end.Shape as FrameworkElement).Tag as GameAirportInfo;

            bool routeExists = activeRoutes.Any(r => r.StartNode == start && r.EndNode == end);
            if (routeExists)
            {
                MessageBox.Show($"司令部提示：\n【{startInfo.Name}】飞往【{endInfo.Name}】的航线已存在！\n请勿重复投资！", "重复建设拦截");
                return;
            }

            double dist = CalculateDistance(start.Position, end.Position);
            long routeCost = (long)(dist * 5000);
            if (playerFunds < routeCost)
            {
                MessageBox.Show($"余额不足！开通此航线需要 ¥{routeCost:N0}", "财务警报");
                return;
            }

            if (webSocket != null && webSocket.State == WebSocketState.Open)
            {
                await SendCommandAsync("OPEN_ROUTE", startInfo.Name, endInfo.Name);
            }
            else
            {
                var dummyCmd = new GameSyncCommand { Sender = "本地指令", ActionType = "OPEN_ROUTE", TargetId = startInfo.Name, AdditionalData = endInfo.Name };
                ExecuteSyncCommand(dummyCmd);
            }
        }
        private async void UpgradeAirportBtn_Click(object sender, RoutedEventArgs e)
        {
            if (currentSelectedMarker == null) return;
            GameAirportInfo info = (currentSelectedMarker.Shape as FrameworkElement).Tag as GameAirportInfo;
            if (info.Level >= 3)
            {
                MessageBox.Show($"【{info.Name}】已经是最高等级 (Lv.3) 的顶级洲际枢纽，无法继续扩建！", "工程部提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // 🌟 核心升级：阶梯定价系统！(Lv.1升Lv.2要0.15亿，Lv.2升Lv.3要0.5亿)
            long upgradeCost = info.Level == 1 ? 15000000 : 50000000;
            long maxCapacityUp=info.Level==1?2*info.MaxCapacity:3*info.MaxCapacity;
            if (playerFunds >= upgradeCost)
            {
                // 智能分流调度
                if (RdoSingle.IsChecked == true)
                {
                    var localCmd = new GameSyncCommand
                    {
                        ActionType = "UPGRADE_BASE",
                        Sender = TxtPlayerName.Text,
                        TargetId = info.Name
                    };
                    ExecuteSyncCommand(localCmd);
                }
                else
                {
                    await SendCommandAsync("UPGRADE_BASE", info.Name);
                }
            }
            else
            {
                // 动态提示差多少钱
                MessageBox.Show($"资金不足！\n\n扩建至 Lv.{info.Level + 1} 需要 ¥{upgradeCost / 100000000.0} 亿\n当前仅有 ¥{playerFunds / 100000000.0:0.##} 亿。", "财务警告", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private async void BuyLocalPlaneBtn_Click(object sender, RoutedEventArgs e)
        {
            if (currentSelectedMarker == null) return;
            GameAirportInfo info = (currentSelectedMarker.Shape as FrameworkElement).Tag as GameAirportInfo;

            long planeCost = 150000000;
            if (playerFunds >= planeCost)
            {
                string targetAirportId = info.Icao;

                if (webSocket != null && webSocket.State == WebSocketState.Open)
                {
                    await SendCommandAsync("BUY_PLANE", targetAirportId);
                }
                else
                {
                    var dummyCmd = new GameSyncCommand { Sender = "单机指令", ActionType = "BUY_PLANE", TargetId = targetAirportId };
                    ExecuteSyncCommand(dummyCmd);
                }
            }
            else
            {
                MessageBox.Show($"资金不足！购买一架飞机需要 ¥{planeCost:N0}", "财务警报");
            }
        }
        private void Flight_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            if (sender is FrameworkElement element && element.Tag is ActiveFlight flight)
            {
                var startInfo = (flight.StartNode.Shape as FrameworkElement).Tag as GameAirportInfo;
                var endInfo = (flight.EndNode.Shape as FrameworkElement).Tag as GameAirportInfo;

                MessageBox.Show(
                    $"✈ 实时航班雷达追踪: {flight.FlightCode}\n" +
                    $"------------------------------------\n" +
                    $"🛫 始发航站楼: {startInfo.Name}\n" +
                    $"🛬 目标航站楼: {endInfo.Name}\n\n" +
                    $"👥 当前搭载旅客: {flight.Passengers:N0} 人\n" +
                    $"💰 预计抵达收益: ¥ {flight.ExpectedProfit:N0}\n\n" +
                    $"📍 航程完成度: {(flight.Progress * 100):F1} %",
                    "空中管制雷达 (ATC)", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void UrgentAirportsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (UrgentAirportsList.SelectedItem is GameAirportInfo selectedInfo)
            {
                var targetMarker = MainMap.Markers.FirstOrDefault(m =>
                    m.Shape is FrameworkElement element &&
                    (element.Tag as GameAirportInfo)?.Name == selectedInfo.Name);

                if (targetMarker != null)
                {
                    MainMap.Position = targetMarker.Position;
                    currentSelectedMarker = targetMarker;
                    RefreshPanelUI(selectedInfo);
                    AirportInfoPanel.Visibility = Visibility.Visible;
                }
                UrgentAirportsList.SelectedItem = null;
            }
        }
        // ==========================================
        // 🌟 核心情报面板：动态渲染指挥中心
        // ==========================================
        private void RefreshPanelUI(GameAirportInfo info)
        {
            // ------------------------------------------
            // 1. 基础情报与运力负荷
            // ------------------------------------------
            TxtAirportName.Text = $"📍 {info.Name} ({info.Icao})";
            TxtAirportLevel.Text = $"⭐ 等级: Lv.{info.Level} (容量: {info.MaxCapacity:N0})";
            TxtAirportPax.Text = $"👥 当前滞留: {info.CurrentPassengers:N0} 人";

            // ------------------------------------------
            // 2. 雷达侦听排队情况
            // ------------------------------------------
            var topDemands = info.Demands.OrderByDescending(kv => kv.Value).Take(3).ToList();
            if (topDemands.Count == 0) TxtDestinations.Text = "📡 雷达侦听: 暂无旅客排队";
            else
            {
                TxtDestinations.Text = "📡 高频目的地排队情报:\n";
                foreach (var demand in topDemands) TxtDestinations.Text += $"   🚩 去 {demand.Key} : {demand.Value:N0} 人\n";
            }

            // ------------------------------------------
            // 3. 基建工程部：动态渲染机场扩建按钮
            // ------------------------------------------
            if (UpgradeAirportBtn != null)
            {
                if (info.Level >= 3)
                {
                    UpgradeAirportBtn.Content = "⭐ 机场已达满级 (Lv.3)";
                    UpgradeAirportBtn.IsEnabled = false; // 满级变灰不可点
                    UpgradeAirportBtn.Background = Brushes.Gray;
                }
                else
                {
                    // 动态计算下一级的价格显示在按钮上
                    long nextCost = info.Level == 1 ? 15000000 : 50000000;
                    UpgradeAirportBtn.Content = $"⬆️ 扩建至 Lv.{info.Level + 1} (¥ {nextCost / 100000000.0} 亿)";
                    UpgradeAirportBtn.IsEnabled = true;
                    UpgradeAirportBtn.Background = Brushes.DarkGoldenrod; // 恢复土豪金
                }
            }

            // ------------------------------------------
            // 4. 停机坪：机队跨代改装系统
            // ------------------------------------------
            FleetContainer.Children.Clear(); // 刷新前清空旧卡片

            if (info.LocalFleet.Count == 0)
            {
                FleetContainer.Children.Add(new TextBlock { Text = "   暂无驻扎飞机，运力停摆！", Foreground = Brushes.Gray, FontStyle = FontStyles.Italic });
            }
            else
            {
                foreach (var plane in info.LocalFleet)
                {
                    Button planeBtn = new Button
                    {
                        Background = new SolidColorBrush(Color.FromArgb(255, 30, 30, 40)),
                        Foreground = Brushes.White,
                        Margin = new Thickness(0, 2, 0, 4),
                        Padding = new Thickness(8, 5, 8, 5),
                        Cursor = Cursors.Hand,
                        HorizontalContentAlignment = HorizontalAlignment.Left
                    };

                    // 动态读取真实机型名称和容量
                    string btnText = $"✈ {plane.Id} | {plane.ModelName} (运力: {plane.Capacity}人)\n";

                    if (plane.IsMaxLevel)
                    {
                        btnText += $"   👑 已达满级科技 (终极超音速客机)";
                    }
                    else
                    {
                        // 预判下一代的科技属性
                        PlaneModelType nextModel = plane.Model == PlaneModelType.Regional ? PlaneModelType.Widebody : PlaneModelType.Supersonic;
                        GamePlaneInfo previewNext = new GamePlaneInfo { Model = nextModel };

                        btnText += $"   ✨ 改装 [{previewNext.ModelName}] (需跑道Lv.{previewNext.RequiredAirportLevel}) | 需 ¥{plane.UpgradeCost / 100000000.0}亿";
                    }
                    planeBtn.Content = btnText;

                    // 挂载改装扣钱与逻辑校验模块
                    if (!plane.IsMaxLevel)
                    {
                        planeBtn.Click += (s, e) =>
                        {
                            PlaneModelType targetModel = plane.Model == PlaneModelType.Regional ? PlaneModelType.Widebody : PlaneModelType.Supersonic;
                            GamePlaneInfo previewPlane = new GamePlaneInfo { Model = targetModel };

                            // 🚨 塔台硬核拦截：跑道等级不足！
                            if (info.Level < previewPlane.RequiredAirportLevel)
                            {
                                MessageBox.Show($"跑道长度不足！\n\n起降【{previewPlane.ModelName}】需要当前机场达到 Lv.{previewPlane.RequiredAirportLevel}。\n请先执行机场扩建工程！", "塔台警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                                return;
                            }

                            // 🚨 财务硬核拦截：经费不足
                            if (playerFunds >= plane.UpgradeCost)
                            {
                                // 拨付经费并执行物理改装
                                playerFunds -= plane.UpgradeCost;
                                plane.Model = targetModel; // 🌟 核心：切换物理机型！
                                plane.Level++;

                                TxtFunds.Text = $"💰 资金: {playerFunds:N0}";
                                RefreshPanelUI(info); // 改装完毕，瞬间刷新面板！
                            }
                            else
                            {
                                MessageBox.Show($"经费严重不足！\n机队改装需要拨款 ¥{plane.UpgradeCost / 100000000.0} 亿！", "财务警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                            }
                        };
                    }

                    FleetContainer.Children.Add(planeBtn);
                }
            }
        }
        private void TriggerGameOver(GameAirportInfo crashedAirport)
        {
            // ==========================================
            // 🌟 AI 训练专属：免死金牌与强力拦截！
            // 如果 crashedAirport 不为空，说明是因为爆仓导致的，我们在这里强行拦截！
            // ==========================================
            if (crashedAirport != null)
            {
                // 🌟 核心补丁 1：立刻进入绝对静止状态
                isGameOver = true;
                if (gameTimer != null) gameTimer.Stop();
                if (animationTimer != null) animationTimer.Stop();

                aiIsDone = true;
                aiLastReward = -100000.0;

                // 打印遗言
                TxtRadioLog.Text += $"\n💥 [毁灭]: {crashedAirport.Name} 爆仓，正在执行时空回收...";

                // 🌟 核心补丁 2：使用 await 确保 Python 收到后再往下走 (需将方法改为 async)
                RequestAIDecision();
                return;
            }

            // ==========================================
            // 下面是你原本的代码：只有当你“主动点击结束按钮” (crashedAirport 为 null) 时，才会正常结算！
            // ==========================================

            // isGameOver = true;
            if (gameTimer != null) gameTimer.Stop();
            if (animationTimer != null) animationTimer.Stop();

            long totalProfit = 0;
            long totalStranded = 0;
            int totalFleet = 0;
            int survivedDays = (gameVirtualTime - new DateTime(2026, 1, 1)).Days;

            currentSessionReport = new GameReportPayload
            {
                SurvivedDays = survivedDays,
                FinalFunds = playerFunds,
                CreatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                AirportStats = new List<AirportReport>()
            };

            foreach (var marker in MainMap.Markers)
            {
                if (marker.Shape is FrameworkElement element && element.Tag is GameAirportInfo info)
                {
                    currentSessionReport.AirportStats.Add(new AirportReport
                    {
                        AirportName = info.Name,
                        Icao = info.Icao,
                        FinalLevel = info.Level,
                        StrandedPax = info.CurrentPassengers,
                        MaxCapacity = info.MaxCapacity,
                        TotalProfit = info.Profit,
                        FleetSize = info.LocalFleet.Count,
                        DailyPaxRate = info.DailyPaxRate
                    });

                    totalProfit += info.Profit;
                    totalStranded += info.CurrentPassengers;
                    totalFleet += info.LocalFleet.Count;
                }
            }

            TxtFailReason.Text = "🛑 营运中止: 指挥官已主动结束本次调度任务，资产锁定完毕。";
            TxtFailReason.Foreground = Brushes.LightSkyBlue;

            TxtFinalDays.Text = $"🏆 存活时间: {survivedDays} 天";
            TxtFinalPax.Text = $"👥 累计运送: {totalTransportedPax:N0} 人次";
            TxtFinalFunds.Text = $"💰 最终结余: ¥ {playerFunds:N0}";

            GameOverOverlay.Visibility = Visibility.Visible;

            if (currentGameMode == "COOP")
            {
                // 规则：名字字母顺序靠前的人，被系统委任为“上传主控官 (Host)”
                if (string.Compare(TxtPlayerName.Text, partnerName) < 0)
                {
                    BtnUploadReport.IsEnabled = true;
                    SubmitScoreBtn.IsEnabled = true;
                    BtnUploadReport.Content = "📤 授权并上传详细数据";
                    SubmitScoreBtn.Content = "🏆 仅提交基础战绩";
                }
                else
                {
                    BtnUploadReport.IsEnabled = false;
                    SubmitScoreBtn.IsEnabled = false;
                    BtnUploadReport.Background = Brushes.Gray;
                    SubmitScoreBtn.Background = Brushes.Gray;
                    BtnUploadReport.Content = "☁️ 等待队长上传黑匣子";
                    SubmitScoreBtn.Content = "🏆 等待队长打榜";
                }
            }
            else
            {
                BtnUploadReport.IsEnabled = true;
                SubmitScoreBtn.IsEnabled = true;
            }

            LoadDataBtn.Content = "🔄 开启下一局 (Restart)";
            LoadDataBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));

            MessageBox.Show(
                $"营运结束！\n\n资产已盘点完毕。\n\n" +
                $"📊 【清算总结】\n" +
                $"- 剩余资金: ¥ {playerFunds:N0}\n" +
                $"- 总滞留: {totalStranded:N0} 人\n" +
                $"- 总机队: {totalFleet} 架\n\n" +
                $"⚠️ 数据暂存于终端内存。请在后方大屏决定是否将详细数据【上传至云端】！",
                "结算完成", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private void RestartGameBtn_Click(object sender, RoutedEventArgs e)
        {
            activeEvents.Clear();
            LoadDataBtn_Click(null, null);
            // 在您原本的重置游戏代码里加上这句：
            LockGameModeUI(false); // 🔓 游戏重置，电闸解开，允许重新选模式
        }
        // ==========================================
        // 🛑 战术中止协议：右键取消航线规划
        // ==========================================


        // 判断当前是否处于“正在规划航线”的状态
        // TODO: 请将 isRoutingMode 替换为你代码里实际代表“拉线中”的布尔值或起点变量
        // 比如：if (currentRouteStartMarker != null)
        // ==========================================
        // 🛑 战术中止协议：右键取消航线规划 (修复幽灵半条线)
        // ==========================================
        // ==========================================
        // 🛑 战术中止协议：右键取消航线规划 (完美无损版)
        // ==========================================
        private void MainMap_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (isDrawingRoute)
            {
                // 1. 关掉拉线逻辑开关
                isDrawingRoute = false;

                // 2. 🎯 精准狙击：扯断那根跟随鼠标的“橡皮筋”！
                if (elasticLine != null)
                {
                    MainMap.Markers.Remove(elasticLine); // 从地图上物理抹除
                    elasticLine = null;                  // 彻底清空内存，等待下一次拉线
                }

                // 🌟 补充保险：如果你代码里还有记录“起点机场”的变量（比如 startMarker），请在这里也把它设为 null
                // startMarker = null; 

                // 3. 恢复鼠标指针为正常状态
                MainMap.Cursor = Cursors.Arrow;

                // 4. 电台日志播报
                Application.Current.Dispatcher.Invoke(() => {
                    TxtRadioLog.Text += "\n🛑 [指挥部]: 航线规划已中止，雷达视图已净化。";
                    if (TxtRadioLog.Parent is ScrollViewer svLog) svLog.ScrollToBottom();
                });

                // 拦截系统默认右键事件（防止地图被右键乱拖）
                e.Handled = true;
            }
        }

    }
}
