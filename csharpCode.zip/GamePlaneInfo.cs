﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightDispatchClient
{
    // 🌟 核心升级：定义三种划时代的机型
    public enum PlaneModelType
    {
        Regional,   // 支线客机 (类似 A320)
        Widebody,   // 宽体客机 (类似 B777)
        Supersonic  // 超音速客机 (类似 协和号)
    }

    public class GamePlaneInfo
    {
        public string Id { get; set; }
        public int Level { get; set; } = 1; // 1=支线, 2=宽体, 3=超音速 (兼容旧代码的 Level)
        public PlaneModelType Model { get; set; } = PlaneModelType.Regional;

        // ✈️ 动态属性获取器：根据机型自动返回不同参数
        public long UpgradeCost => Model == PlaneModelType.Regional ? 200000000 : (Model == PlaneModelType.Widebody ? 450000000 : 0);
        public bool IsMaxLevel => Model == PlaneModelType.Supersonic;
        public string ModelName => Model == PlaneModelType.Regional ? "A320 支线客机" : (Model == PlaneModelType.Widebody ? "B777 宽体客机" : "协和号 超音速客机");
        public int Capacity => Model == PlaneModelType.Regional ? 150 : (Model == PlaneModelType.Widebody ? 350 : 100);
        public double SpeedMultiplier => Model == PlaneModelType.Regional ? 1.0 : (Model == PlaneModelType.Widebody ? 1.2 : 3.0);
        public long Cost => Model == PlaneModelType.Regional ? 80000000 : (Model == PlaneModelType.Widebody ? 250000000 : 600000000); // 8千万，2.5亿，6亿
        public long FuelCostPerKm => Model == PlaneModelType.Regional ? 50 : (Model == PlaneModelType.Widebody ? 120 : 400); // 燃油损耗倍率
        public int RequiredAirportLevel => Model == PlaneModelType.Regional ? 1 : (Model == PlaneModelType.Widebody ? 2 : 3);
    }
}
