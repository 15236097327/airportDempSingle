﻿using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlightDispatchClient
{
    public class GameRouteInfo
    {
        public GMapMarker StartNode { get; set; }
        public GMapMarker EndNode { get; set; }
        public double Distance { get; set; }
    }
}
