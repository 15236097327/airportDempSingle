﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;

namespace FlightDispatchClient
{
    /*
     BtnLbSingle_Click (切单机榜)

BtnLbCoop_Click (切联机榜)

LoadSurvivalBoard_Click (切生存榜)

LoadWealthBoard_Click (切财富榜)

UpdateLeaderboardUI (刷新榜单 UI 颜色)

BtnGlobalLeaderboard_Click (打开排行榜主面板)

CloseLeaderboardBtn_Click (关闭排行榜)

ClosePersonalHistoryBtn_Click (关闭历史档案柜)

LoadLeaderboard (本地排行榜加载，如果有用的话)
     */
    public partial class MainWindow : Window//荣誉大厅：排行榜与档案 UI
    {
        private void BtnLbSingle_Click(object sender, RoutedEventArgs e)
        {
            lbCurrentMode = "SINGLE";
            UpdateLeaderboardUI();
        }

        private void BtnLbCoop_Click(object sender, RoutedEventArgs e)
        {
            lbCurrentMode = "COOP";
            UpdateLeaderboardUI();
        }

        private void LoadSurvivalBoard_Click(object sender, RoutedEventArgs e)
        {
            lbCurrentCategory = "survival";
            UpdateLeaderboardUI();
        }

        private void LoadWealthBoard_Click(object sender, RoutedEventArgs e)
        {
            lbCurrentCategory = "wealth";
            UpdateLeaderboardUI();
        }

        private void UpdateLeaderboardUI()
        {
            // 1. 刷新赛道按钮的火力颜色
            if (BtnLbSingle != null) BtnLbSingle.Background = lbCurrentMode == "SINGLE" ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2E8B57")) : new SolidColorBrush((Color)ColorConverter.ConvertFromString("#333344"));
            if (BtnLbCoop != null) BtnLbCoop.Background = lbCurrentMode == "COOP" ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#8A2BE2")) : new SolidColorBrush((Color)ColorConverter.ConvertFromString("#333344"));

            // 2. 刷新维度按钮的火力颜色
            if (BtnSurvBoard != null) BtnSurvBoard.Background = lbCurrentCategory == "survival" ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC")) : new SolidColorBrush((Color)ColorConverter.ConvertFromString("#333344"));
            if (BtnWealthBoard != null) BtnWealthBoard.Background = lbCurrentCategory == "wealth" ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("DarkGoldenrod")) : new SolidColorBrush((Color)ColorConverter.ConvertFromString("#333344"));

            // 3. 呼叫云端数据 (注意这里传了 lbCurrentMode)
            FetchCloudLeaderboard(lbCurrentCategory, lbCurrentMode);
        }
        //打开排行榜主面板
        private void BtnGlobalLeaderboard_Click(object sender, RoutedEventArgs e)
        {
            // 这里的细节拉满：如果你现在处于联合模式，打开榜单直接默认进联合舰队榜！
            lbCurrentMode = currentGameMode;
            lbCurrentCategory = "survival"; // 默认切生存榜

            UpdateLeaderboardUI(); // 触发全套UI渲染和数据拉取
            LeaderboardOverlay.Visibility = Visibility.Visible;
        }

        //关闭排行榜主面板
        private void CloseLeaderboardBtn_Click(object sender, RoutedEventArgs e)
        {
            LeaderboardOverlay.Visibility = Visibility.Collapsed;
        }
        //关闭历史档案柜
        private void ClosePersonalHistoryBtn_Click(object sender, RoutedEventArgs e)
        {
            PersonalHistoryOverlay.Visibility = Visibility.Collapsed;
        }
        private void LoadLeaderboard()
        {
            try
            {
                if (File.Exists(leaderboardFilePath))
                {
                    string json = File.ReadAllText(leaderboardFilePath);
                    leaderboardData = JsonSerializer.Deserialize<List<PlayerRecord>>(json) ?? new List<PlayerRecord>();
                }
            }
            catch { leaderboardData = new List<PlayerRecord>(); }
        }
    }
}
