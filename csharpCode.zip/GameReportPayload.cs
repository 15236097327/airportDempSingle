﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightDispatchClient
{
    public class GameReportPayload
    {
        public string PlayerName { get; set; }
        public int SurvivedDays { get; set; }
        public long FinalFunds { get; set; }
        public long TransportedPax { get; set; }
        public string CreatedAt { get; set; }
        public string GameMode { get; set; }
        public List<AirportReport> AirportStats { get; set; } = new List<AirportReport>();
        public string FormattedDate => CreatedAt;
        public string DisplayGameMode => (GameMode == "COOP") ? "👥 联合" : "👤 单机";
    }
}
