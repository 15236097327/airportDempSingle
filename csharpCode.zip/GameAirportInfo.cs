﻿using System;
using System.Collections.Generic;
using System.Text;
using static FlightDispatchClient.MainWindow;

namespace FlightDispatchClient
{
    public class GameAirportInfo
    {
        public string Name { get; set; }
        public string Icao { get; set; }
        public int DailyPaxRate { get; set; }
        public int MaxCapacity { get; set; }
        public int Level { get; set; } = 1;
        public long Profit { get; set; } = 0;
        public int CurrentPassengers { get; set; } = 0;
        public Dictionary<string, int> Demands { get; set; } = new Dictionary<string, int>();
        public List<GamePlaneInfo> LocalFleet { get; set; } = new List<GamePlaneInfo>();

        public string EventIcon { get; set; } = "";
        public int InitialCapacity { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
