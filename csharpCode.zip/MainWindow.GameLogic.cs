﻿using GMap.NET;
using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace FlightDispatchClient
{
    public partial class MainWindow : Window
    {
        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (isGameOver) return;
            if (isWaitingForAI) return;
            gameTickCount++;

            
            if (allAirportsList.Count > 0)
            {
                for (int i = activeEvents.Count - 1; i >= 0; i--)
                {
                    var ev = activeEvents[i];

                    if (ev.WarningTicks > 0)
                    {
                        ev.WarningTicks--;
                        if (ev.WarningTicks <= 0)
                        {
                            string startMsg = ev.Type == EventType.EconomicBoom
                                ? $"🔥 [突发]: {ev.TargetAirportName} 盛会正式开幕！全网客流正在向该地疯狂涌入！"
                                : $"🌪️ [突发]: {ev.TargetAirportName} 超级雷暴已登陆！该地空域已化为泥潭！";

                            // 🌟 限制训练模式下的日志刷新频率，防止 UI 卡死
                           
                        }
                    }
                    else
                    {
                        ev.RemainingTicks--;
                        if (ev.RemainingTicks <= 0)
                        {
                            string endMsg = ev.Type == EventType.EconomicBoom ? "📉 [全球快讯]: 盛会落幕。" : "🌤️ [气象局]: 警报解除。";
                            if (!isFastTrainingMode || gameTickCount % 50 == 0)
                            {
                                TxtRadioLog.Text += $"\n{endMsg} ({ev.TargetAirportName})";
                                if (TxtRadioLog.Parent is ScrollViewer svLog) svLog.ScrollToBottom();
                            }
                            activeEvents.RemoveAt(i);
                        }
                    }
                }

                /*if (gameTickCount % 10 == 0 && randomEngine.Next(1000) < 2 && activeEvents.Count < 3)
                {
                    var targetAp = allAirportsList[randomEngine.Next(allAirportsList.Count)];

                    if (!activeEvents.Any(ev => ev.TargetAirportName == targetAp.Name))
                    {
                        bool isBoom = randomEngine.Next(100) < 50;

                        GlobalEvent newEvent = new GlobalEvent
                        {
                            Type = isBoom ? EventType.EconomicBoom : EventType.SevereWeather,
                            TargetAirportName = targetAp.Name,
                            WarningTicks = 20,
                            RemainingTicks = randomEngine.Next(30, 80)
                        };
                        activeEvents.Add(newEvent);

                        string broadcast = isBoom
                            ? $"📢 [商业情报]: {targetAp.Name} 即将举办博览会！"
                            : $"⚠️ [气象预警]: 超级雷暴正向 {targetAp.Name} 移动！";

                        if (!isFastTrainingMode || gameTickCount % 50 == 0)
                        {
                            TxtRadioLog.Text += $"\n{broadcast}";
                            if (TxtRadioLog.Parent is ScrollViewer svLog) svLog.ScrollToBottom();
                        }
                    }
                }*/
            }

            gameVirtualTime = gameVirtualTime.AddMinutes(15);
            int survivedDays = (gameVirtualTime - new DateTime(2026, 1, 1)).Days;

            // 标题栏保留更新，方便你观察游戏有没有在跑
            this.Title = $"✈ 航空大亨指挥中心 | 当前游戏时间: {gameVirtualTime:yyyy年MM月dd日 HH:mm} | 🏆 已存活: {survivedDays} 天";

            double timeMultiplier = 1.0 + 0.8 * Math.Sin((gameVirtualTime.Hour - 8) / 24.0 * Math.PI * 2);

            foreach (var marker in MainMap.Markers)
            {
                if (marker.Shape is FrameworkElement element && element.Tag is GameAirportInfo info)
                {
                    double randomFactor = 0.8 + (randomEngine.NextDouble() * 0.4);
                    int actualArrivals = (int)((info.DailyPaxRate) * timeMultiplier * randomFactor)/10;
                    if (gameTickCount < 20)
                    {
                        actualArrivals = (int)(actualArrivals * 0.2);
                    }
                    if (activeEvents.Any(ev => ev.TargetAirportName == info.Name && ev.Type == EventType.EconomicBoom && ev.IsActive))
                    {
                        actualArrivals *= 2;
                    }
                    if (actualArrivals > 0)
                    {
                        int totalWeight = allAirportsList.Sum(a => a.DailyPaxRate);
                        int randValue = randomEngine.Next(totalWeight);
                        GameAirportInfo destInfo = allAirportsList.Last();

                        foreach (var candidate in allAirportsList)
                        {
                            randValue -= candidate.DailyPaxRate;
                            if (randValue <= 0)
                            {
                                destInfo = candidate;
                                break;
                            }
                        }

                        if (destInfo.Name == info.Name)
                        {
                            destInfo = allAirportsList.OrderByDescending(a => a.DailyPaxRate).First(a => a.Name != info.Name);
                        }

                        if (!info.Demands.ContainsKey(destInfo.Name))
                            info.Demands[destInfo.Name] = 0;

                        info.Demands[destInfo.Name] += actualArrivals;
                        info.CurrentPassengers += actualArrivals;
                    }

                   /* if (info.CurrentPassengers >= info.MaxCapacity)
                    {
                        if (currentGameMode == "COOP")
                        {
                            string finalPayload = $"{playerFunds}|{totalTransportedPax}|{gameVirtualTime.Ticks}";
                            _ = SendCommandAsync("SYNC_AUTO_GAME_OVER", info.Name, finalPayload);
                        }

                        TriggerGameOver(info);
                        return;
                    }*/
                }
            }

            long tickTotalProfit = 0;

            // ==========================================
            // 🌟 上帝视角：按剧本发车！
            // ==========================================
            string currentTickStr = gameTickCount.ToString();
            if (godScript.ContainsKey(currentTickStr))
            {
                var actionsForThisTick = godScript[currentTickStr];
                foreach (var cmd in actionsForThisTick)
                {
                    ExecuteScriptAction(cmd);
                }
            }

            // 🌟 纯 UI 渲染部分：训练时直接跳过！
            if (!isFastTrainingMode)
            {
                if (tickTotalProfit > 0)
                {
                    TxtFunds.Text = $"💰 资金: {playerFunds:N0} (+{tickTotalProfit:N0})";
                    TxtFunds.Foreground = Brushes.LimeGreen;
                }
                else
                {
                    TxtFunds.Text = $"💰 资金: {playerFunds:N0}";
                    TxtFunds.Foreground = Brushes.Gold;
                }

                if (currentSelectedMarker != null && AirportInfoPanel.Visibility == Visibility.Visible)
                {
                    GameAirportInfo currentInfo = (currentSelectedMarker.Shape as FrameworkElement).Tag as GameAirportInfo;
                    RefreshPanelUI(currentInfo);
                }

                foreach (var ap in allAirportsList) ap.EventIcon = "";
                foreach (var ev in activeEvents)
                {
                    var affectedAirport = allAirportsList.FirstOrDefault(a => a.Name == ev.TargetAirportName);
                    if (affectedAirport != null)
                    {
                        if (!ev.IsActive)
                            affectedAirport.EventIcon = ev.Type == EventType.EconomicBoom ? $"⏳即将暴富({ev.WarningTicks})" : $"⚠️台风逼近({ev.WarningTicks})";
                        else
                            affectedAirport.EventIcon = ev.Type == EventType.EconomicBoom ? $"💰金币狂欢({ev.RemainingTicks})" : $"⛈️雷暴肆虐({ev.RemainingTicks})";
                    }
                }

                var urgentList = allAirportsList
                    .OrderByDescending(a => (double)a.CurrentPassengers / a.MaxCapacity)
                    .ToList();
                UrgentAirportsList.ItemsSource = null;
                UrgentAirportsList.ItemsSource = urgentList;

                foreach (var marker in MainMap.Markers)
                {
                    if (marker.Shape is Canvas canvas && canvas.Tag is GameAirportInfo info)
                    {
                        var dot = canvas.Children.OfType<System.Windows.Shapes.Ellipse>().FirstOrDefault();
                        if (dot != null)
                        {
                            double dangerRatio = (double)info.CurrentPassengers / info.MaxCapacity;
                            if (dangerRatio < 0.5) dot.Fill = Brushes.MediumSeaGreen;
                            else if (dangerRatio < 0.8) dot.Fill = Brushes.DarkOrange;
                            else dot.Fill = Brushes.Crimson;
                        }

                        var nameLabel = canvas.Children.OfType<TextBlock>().FirstOrDefault();
                        if (nameLabel != null)
                        {
                            nameLabel.Text = string.IsNullOrEmpty(info.EventIcon) ? info.Name : $"{info.EventIcon} {info.Name}";

                            if (info.EventIcon.Contains("⏳") || info.EventIcon.Contains("⚠️"))
                            {
                                nameLabel.Foreground = Brushes.DarkOrange;
                                nameLabel.FontWeight = FontWeights.ExtraBold;
                            }
                            else if (info.EventIcon == "💰")
                            {
                                nameLabel.Foreground = Brushes.Gold;
                                nameLabel.FontWeight = FontWeights.Black;
                            }
                            else if (info.EventIcon == "⛈️")
                            {
                                nameLabel.Foreground = Brushes.DeepSkyBlue;
                                nameLabel.FontWeight = FontWeights.Black;
                            }
                            else
                            {
                                nameLabel.Foreground = new SolidColorBrush(Color.FromArgb(200, 220, 220, 220));
                                nameLabel.FontWeight = FontWeights.Bold;
                            }
                        }
                    }
                }
            }
            
        }


        private void AnimationTimer_Tick(object sender, EventArgs e)
        {
            if (isGameOver) return;
            if (flyingPlanes == null) return;

            for (int i = flyingPlanes.Count - 1; i >= 0; i--)
            {
                var flight = flyingPlanes[i];

                // ==========================================
                // 🌪️ 核心物理引擎：气象阻力判定
                // ==========================================
                double currentSpeed = flight.Speed;
                var endInfo = (flight.EndNode.Shape as FrameworkElement)?.Tag as GameAirportInfo;

                if (endInfo != null && activeEvents.Any(ev => ev.TargetAirportName == endInfo.Name && ev.Type == EventType.SevereWeather && ev.IsActive))
                {
                    currentSpeed *= 0.3; // 陷入泥潭，只剩 30% 龟速！
                }

                // 🚀 核心推进：就算看不见图标，物理进度依然在涨！
                flight.Progress += currentSpeed;
                // ==========================================

                if (flight.Progress >= 1.0)
                {
                    playerFunds += flight.ExpectedProfit;
                    totalTransportedPax += flight.Passengers;

                    if (flight.PhysicalPlane != null && endInfo != null)
                    {
                        endInfo.LocalFleet.Add(flight.PhysicalPlane);

                        if (currentSelectedMarker == flight.EndNode)
                        {
                            RefreshPanelUI(endInfo);
                        }
                    }

                    // 🌟 护盾 1：降落销毁时，判空！
                    if (flight.Marker != null && MainMap.Markers.Contains(flight.Marker))
                    {
                        MainMap.Markers.Remove(flight.Marker);
                    }

                    flyingPlanes.RemoveAt(i);
                }
                else
                {
                    // 🌟 护盾 2：只有在图标存在时，才去计算 UI 曲线和更新坐标！
                    if (flight.Marker != null)
                    {
                        double startLat = flight.StartNode.Position.Lat;
                        double startLng = flight.StartNode.Position.Lng;
                        double endLat = flight.EndNode.Position.Lat;
                        double endLng = flight.EndNode.Position.Lng;

                        double midLat = (startLat + endLat) / 2.0;
                        double midLng = (startLng + endLng) / 2.0;
                        double dx = endLng - startLng;
                        double dy = endLat - startLat;

                        double curvature = 0.2;
                        double ctrlLat = midLat + dx * curvature;
                        double ctrlLng = midLng - dy * curvature;

                        double t = flight.Progress;
                        double u = 1 - t;

                        double curLat = (u * u * startLat) + (2 * u * t * ctrlLat) + (t * t * endLat);
                        double curLng = (u * u * startLng) + (2 * u * t * ctrlLng) + (t * t * endLng);

                        flight.Marker.Position = new PointLatLng(curLat, curLng);
                    }
                }
            }
        }
        // ==========================================
        // 🌟 时间扭曲引擎：发送变速指令
        // ==========================================
        // ==========================================
        // ⏱️ 时间控制器：0.5x 缓速
        // ==========================================
        private async void BtnSpeedSlow_Click(object sender, RoutedEventArgs e)
        {
            if (!isGameStarted || isPaused) return;

            if (RdoSingle.IsChecked == true)
            {
                // 单机直连：直接扔给本地处理器
                var localCmd = new GameSyncCommand { ActionType = "CHANGE_SPEED", Sender = TxtPlayerName.Text, TargetId = "0.5" };
                ExecuteSyncCommand(localCmd);
            }
            else
            {
                // 联机广播：发射到云端
                await SendCommandAsync("CHANGE_SPEED", "0.5");
            }
        }

        // ==========================================
        // ⏱️ 时间控制器：1.0x 标准
        // ==========================================
        private async void BtnSpeedNormal_Click(object sender, RoutedEventArgs e)
        {
            if (!isGameStarted || isPaused) return;

            if (RdoSingle.IsChecked == true)
            {
                var localCmd = new GameSyncCommand { ActionType = "CHANGE_SPEED", Sender = TxtPlayerName.Text, TargetId = "1.0" };
                ExecuteSyncCommand(localCmd);
            }
            else
            {
                await SendCommandAsync("CHANGE_SPEED", "1.0");
            }
        }

        // ==========================================
        // ⏱️ 时间控制器：2.0x 曲率加速
        // ==========================================
        private async void BtnSpeedFast_Click(object sender, RoutedEventArgs e)
        {
            if (!isGameStarted || isPaused) return;

            if (RdoSingle.IsChecked == true)
            {
                var localCmd = new GameSyncCommand { ActionType = "CHANGE_SPEED", Sender = TxtPlayerName.Text, TargetId = "2.0" };
                ExecuteSyncCommand(localCmd);
            }
            else
            {
                await SendCommandAsync("CHANGE_SPEED", "2.0");
            }
        }

        // ==========================================
        // 🧠 天网智脑：自动派发大脑 (每隔几秒思考一次)
        // ==========================================
        // ==========================================
        // 🧠 天网智脑：自动派发大脑 (蜂群升级版)
        // ==========================================
        // ==========================================
        // 🧠 天网智脑：自动派发大脑 (防破产版)
        // ==========================================
        private void RunSkyNetDispatch()
        {
            if (currentAIStrategy == DispatchStrategy.Off) return;

            foreach (var airport in allAirportsList.Where(a => a.LocalFleet.Count > 0))
            {
                while (airport.LocalFleet.Count > 0)
                {
                    // 提前看看我们要派出去的是什么飞机
                    var planeToUse = airport.LocalFleet[0];

                    // 🌟 商业核心防线：上座率熔断！
                    // 规定：目标航线的排队人数，必须大于这架飞机总容量的 50%，否则绝不起飞！宁愿停在机库里！
                    int minPaxRequired = (int)(planeToUse.Capacity * 0.5);
                    if (minPaxRequired < 10) minPaxRequired = 10; // 就算小飞机，也至少凑够 10 个人才飞

                    // 过滤出那些排队人数达标的航线
                    var potentialRoutes = airport.Demands.Where(d => d.Value >= minPaxRequired).ToList();

                    // 🚨 如果没有一条航线能凑够这架飞机的油钱，直接取消本次派发！让飞机在地勤待命！
                    if (potentialRoutes.Count == 0) break;

                    // 3. 核心算法：为每条航线计算“优先级评分”
                    var bestRoute = potentialRoutes.OrderByDescending(route => {
                        var destAirport = allAirportsList.FirstOrDefault(a => a.Name == route.Key);
                        if (destAirport == null) return 0;

                        if (currentAIStrategy == DispatchStrategy.ProfitFirst)
                            return route.Value * 1.5;
                        else
                            return (double)destAirport.CurrentPassengers / destAirport.MaxCapacity;
                    }).First();

                    // 4. 执行起飞！
                    TryAutoLaunchPlane(airport, bestRoute.Key);
                }
            }
        }
        private void RunSkyNetConstruction()
        {
            if (currentAIStrategy == DispatchStrategy.Off) return;

            // 设定一条“财政安全红线”，AI 花钱不能把国库掏空，必须留 10 亿备用金防破产！
            long safeReserve = 100000000;

            foreach (var airport in allAirportsList)
            {
                // ------------------------------------------------
                // 审批项目 1：机场扩建 (防止爆仓的终极手段)
                // ------------------------------------------------
                // ------------------------------------------------
                // 审批项目 1：机场扩建 (防止爆仓的终极手段)
                // ------------------------------------------------
                if (airport.Level < 3)
                {
                    double dangerRatio = (double)airport.CurrentPassengers / airport.MaxCapacity;
                    long upgradeCost = airport.Level == 1 ? 15000000 : 50000000;

                    // 🌟 抢修 1：看看这个机场是不是正在举办“经济大爆发”？如果是，无脑升满！
                    bool hasBoomEvent = activeEvents.Any(ev => ev.TargetAirportName == airport.Name && ev.Type == EventType.EconomicBoom);

                    // 🌟 抢修 2：降低预警线！只要容量过半 (> 0.5) 或者有暴富事件，并且钱够，立刻破土动工！
                    if ((dangerRatio > 0.5 || hasBoomEvent) && playerFunds >= (upgradeCost + safeReserve))
                    {
                        playerFunds -= upgradeCost;
                        airport.Level++;

                        // 🌟 抢修 3 (最致命修复)：真实增加机场的物理容量！(数值您可以根据您开局的设定自行微调)
                        if (airport.Level == 2) airport.MaxCapacity = (int)(airport.MaxCapacity * 2.0); // Lv.2 容量 2 倍
                        if (airport.Level == 3) airport.MaxCapacity = (int)(airport.MaxCapacity * 3.0); // Lv.3 容量再翻 3 倍

                        TxtRadioLog.Text += $"\n🏗️ [天网工程]: 危机预判！AI 强行拨款 ¥{upgradeCost / 100000000.0}亿 将 {airport.Name} 扩建至 Lv.{airport.Level}，容量暴增至 {airport.MaxCapacity}！";

                        if (currentSelectedMarker != null && (currentSelectedMarker.Shape as FrameworkElement)?.Tag == airport) RefreshPanelUI(airport);

                        // 刚升完级需要稳固一下地基，跳过本次购买飞机环节
                        continue;
                    }
                }

                // ------------------------------------------------
                // 审批项目 2：运力采购 (爆单但没飞机时)
                // ------------------------------------------------
                int totalDemand = airport.Demands.Sum(d => d.Value); // 计算这个机场总共多少人排队

                // 决策逻辑：如果有超过 150 人排队，但停机坪上的飞机不到 2 架，说明严重缺乏运力！买！
                if (totalDemand > 150 && airport.LocalFleet.Count < 2)
                {
                    // 智能选型：根据当前机场的等级，买最顶级的飞机！
                    PlaneModelType targetModel = airport.Level == 3 ? PlaneModelType.Supersonic : (airport.Level == 2 ? PlaneModelType.Widebody : PlaneModelType.Regional);
                    long planeCost = targetModel == PlaneModelType.Supersonic ? 450000000 : (targetModel == PlaneModelType.Widebody ? 200000000 : 80000000); // 飞机造价

                    if (playerFunds > (planeCost + safeReserve))
                    {
                        playerFunds -= planeCost;

                        // 组装新飞机并交付
                        GamePlaneInfo newPlane = new GamePlaneInfo
                        {
                            Id = "AI-" + randomEngine.Next(1000, 9999).ToString(),
                            Model = targetModel,
                            Level = airport.Level
                        };
                        airport.LocalFleet.Add(newPlane);

                        TxtRadioLog.Text += $"\n✈️ [天网采购]: 运力告急！AI 斥资 ¥{planeCost / 100000000.0}亿 为 {airport.Name} 空投了一架 {newPlane.ModelName}！";

                        if (currentSelectedMarker != null && (currentSelectedMarker.Shape as FrameworkElement)?.Tag == airport) RefreshPanelUI(airport);
                    }
                }
            }
        }

        // ==========================================
        // 🚀 天网智脑：全自动物理起飞执行器 (无需人工连线)
        // ==========================================
        // ==========================================
        // 🚀 天网智脑：全自动物理起飞执行器 (绝对服从版)
        // ==========================================
        private void TryAutoLaunchPlane(GameAirportInfo startInfo, string destAirportName)
        {
            var startMarker = MainMap.Markers.FirstOrDefault(m => (m.Shape as FrameworkElement)?.Tag == startInfo);
            var destAirport = allAirportsList.FirstOrDefault(a => a.Name == destAirportName);
            if (startMarker == null || destAirport == null) return;

            var destMarker = MainMap.Markers.FirstOrDefault(m => (m.Shape as FrameworkElement)?.Tag == destAirport);
            if (destMarker == null) return;

            // 🌟 1. 切除安检！上帝说飞，没飞机也得捏造一架飞！
            GamePlaneInfo planeToUse;
            if (startInfo.LocalFleet.Count > 0)
            {
                planeToUse = startInfo.LocalFleet[0];
                startInfo.LocalFleet.RemoveAt(0);
            }
            else
            {
                // 凭空捏造一架飞机执行剧本（解决飞机来不及降落导致无法起飞的 Bug）
                planeToUse = new GamePlaneInfo { Id = "GHOST-" + randomEngine.Next(1000, 9999), Model = PlaneModelType.Regional, Level = 1 };
            }

            // 🌟 2. 切除客流安检！
            int paxToMove = Math.Min(planeToUse.Capacity, startInfo.CurrentPassengers);
            if (paxToMove <= 0) paxToMove = planeToUse.Capacity; // 哪怕是空的，也满载起飞！

            startInfo.CurrentPassengers -= paxToMove;
            if (startInfo.CurrentPassengers < 0) startInfo.CurrentPassengers = 0;

            // 计算物理距离与利润
            double dyRoute = startMarker.Position.Lat - destMarker.Position.Lat;
            double dxRoute = destMarker.Position.Lng - startMarker.Position.Lng;
            double distance = Math.Sqrt(dyRoute * dyRoute + dxRoute * dxRoute) * 111.0;
            if (distance < 10) distance = 10;

            long ticketRevenue = (long)(paxToMove * distance * 1.5);
            long fuelCost = (long)(distance * planeToUse.FuelCostPerKm);
            long expectedProfit = ticketRevenue - fuelCost;

            TextBlock planeVisual = null;
            GMap.NET.WindowsPresentation.GMapMarker planeMarker = null;

            // 🌟 3. UI 渲染：只有在人类观赏模式下才画飞机！
            if (!isFastTrainingMode)
            {
                double angle = Math.Atan2(dyRoute, dxRoute) * 180 / Math.PI + 45;
                double visualSize = 22 + (planeToUse.Level * 8);

                planeVisual = new TextBlock
                {
                    Text = "✈",
                    FontSize = visualSize,
                    Foreground = expectedProfit < 0 ? Brushes.Red : Brushes.White,
                    RenderTransformOrigin = new Point(0.5, 0.5),
                    RenderTransform = new RotateTransform(angle),
                    Cursor = Cursors.Hand
                };

                planeMarker = new GMap.NET.WindowsPresentation.GMapMarker(startMarker.Position)
                {
                    Shape = planeVisual,
                    Offset = new Point(-visualSize / 2, -visualSize / 2),
                    ZIndex = 1000
                };
            }

            ActiveFlight newFlight = new ActiveFlight
            {
                Marker = planeMarker,
                StartNode = startMarker,
                EndNode = destMarker,
                Progress = 0,
                Speed = (40.0 * planeToUse.SpeedMultiplier) / distance,
                Passengers = paxToMove,
                ExpectedProfit = expectedProfit,
                FlightCode = planeToUse.Id,
                PhysicalPlane = planeToUse
            };

            // 添加到地图并执行动画
            if (!isFastTrainingMode)
            {
                try { planeVisual.Tag = newFlight; planeVisual.MouseLeftButtonDown += Flight_MouseLeftButtonDown; } catch { }
                MainMap.Markers.Add(planeMarker);
                if (currentSelectedMarker == startMarker) RefreshPanelUI(startInfo);
            }

            flyingPlanes.Add(newFlight);
        }

        // ==========================================
        // 🧠 天网指挥中心：UI 控制台切换事件
        // ==========================================
        private void ComboAISet_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // 防止在窗口刚加载时触发空引用
            if (!IsLoaded) return;

            if (sender is ComboBox comboBox && comboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                string strategyTag = selectedItem.Tag?.ToString();

                if (strategyTag == "Off")
                {
                    currentAIStrategy = DispatchStrategy.Off;
                    if (TxtRadioLog != null) TxtRadioLog.Text += "\n🧠 [天网系统]: 自动调度已关闭，恢复【人工微操】模式。";
                }
                else if (strategyTag == "ProfitFirst")
                {
                    currentAIStrategy = DispatchStrategy.ProfitFirst;
                    if (TxtRadioLog != null) TxtRadioLog.Text += "\n💰 [天网系统]: 切换至【利润至上】模式！AI 将优先执飞高净值航线。";
                }
                else if (strategyTag == "RescueFirst")
                {
                    currentAIStrategy = DispatchStrategy.RescueFirst;
                    if (TxtRadioLog != null) TxtRadioLog.Text += "\n🚒 [天网系统]: 切换至【紧急救援】模式！AI 将全力疏散高危爆仓机场！";
                }

                // 自动滚动电台日志
                if (TxtRadioLog != null && TxtRadioLog.Parent is ScrollViewer svLog)
                {
                    svLog.ScrollToBottom();
                }
            }
        }
    }
}
