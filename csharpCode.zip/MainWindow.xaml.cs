﻿using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace FlightDispatchClient
{
    public partial class MainWindow : Window
    {
        private static readonly HttpClient client = new HttpClient();
        private System.Net.WebSockets.ClientWebSocket webSocket;
        private bool isGameStarted = false; // 记录游戏是否已经正式开局
        // 🌟 全局资金池
        private long playerFunds = 5000000000;
        private GMapMarker currentSelectedMarker = null;
        private System.Windows.Threading.DispatcherTimer gameTimer;
        private bool isGameOver = false;
        private bool isPaused = false;
        public enum EventType
        {
            EconomicBoom,  // 经济爆发 (客流暴增)
            SevereWeather  // 极端天气 (航速减半)
        }
        private bool isWaitingForAI = false; // 并发锁
        public class GlobalEvent
        {
            public EventType Type { get; set; }
            public string TargetAirportName { get; set; } // 遭殃/受益的机场
            public int RemainingTicks { get; set; }       // 事件持续的 Tick 数 (寿命)
            public int WarningTicks { get; set; } // 🌟 新增：预警倒计时 (预留给指挥官反应的时间)
            

            // 🌟 新增：判断事件是否已经越过预警期，正式爆发！
            public bool IsActive => WarningTicks <= 0;
        }
        private List<GlobalEvent> activeEvents = new List<GlobalEvent>();
        // 🌟 航线模式状态
        private bool isDrawingRoute = false;      // 是否处于拉线模式
        private GMapMarker routeStartMarker = null; // 连线的起点机场
        private GMapMarker elasticLine = null;     // 跟着鼠标走的“橡皮筋”虚线

        private long gameTickCount = 0;
        private Random randomEngine = new Random();
        private DateTime gameVirtualTime = new DateTime(2026, 1, 1, 6, 0, 0);
        private List<GameRouteInfo> activeRoutes = new List<GameRouteInfo>();

        private System.Windows.Threading.DispatcherTimer animationTimer;
        private List<ActiveFlight> flyingPlanes = new List<ActiveFlight>();
        private List<GameAirportInfo> allAirportsList = new List<GameAirportInfo>();
        private GMapMarker costPreviewMarker = null;
        private long totalTransportedPax = 0;
        private string currentRoomId = "";
        private List<PlayerRecord> leaderboardData = new List<PlayerRecord>();
        private string lbCurrentMode = "SINGLE";      // 赛道记忆
        private string lbCurrentCategory = "survival"; // 维度记忆
        // 🌟 赛道与联名管理
        private string currentGameMode = "SINGLE"; // 默认单机
        private string partnerName = "神秘僚机"; // 用来存储队友的名字

        // 🌟 全局剪贴板：暂存这局的数据
        private GameReportPayload currentSessionReport = null;
        private string leaderboardFilePath = "leaderboard.json";

        private System.Windows.Threading.DispatcherTimer heartbeatTimer;
        
        // 在客户端的全局控制类中定义
        public enum GameState
        {
            WaitingForPlayers, // 匹配/准备阶段
            Playing,           // 正常运行
            Paused,            // 战术暂停
            GameOver           // 彻底结束（核弹洗地状态）
        }
        public GameState CurrentGameState { get; private set; }
        // 唯一的状态指示器
        //public GameState CurrentGameState { get; private set; }
        // ==========================================
        // 🌟 内部数据结构类
        // ==========================================
        public class UserAuthRequest
        {
            public string username { get; set; }
            public string password { get; set; }
        }

        // 🌟 航线纯数据版
        public class SyncRouteDTO
        {
            public string StartName { get; set; }
            public string EndName { get; set; }
        }

        // 🌟 飞行航班纯数据版
        public class SyncFlightDTO
        {
            public string StartName { get; set; }
            public string EndName { get; set; }
            public double Progress { get; set; }
            public int Passengers { get; set; }
            public long ExpectedProfit { get; set; }
            public string FlightCode { get; set; }
            public GamePlaneInfo PhysicalPlane { get; set; }
        }

        // 🌟 终极世界快照包裹
        public class FullStateDTO
        {
            public long Funds { get; set; }
            public long Pax { get; set; }
            public long Ticks { get; set; }
            public bool IsPaused { get; set; }
            // GameAirportInfo 本身就是纯数据，可以直接传！
            public List<GameAirportInfo> Airports { get; set; } = new List<GameAirportInfo>();
            public List<SyncRouteDTO> Routes { get; set; } = new List<SyncRouteDTO>();
            public List<SyncFlightDTO> Flights { get; set; } = new List<SyncFlightDTO>();
        }
        // ==========================================
        // 🌟 初始化模块
        // ==========================================
        public MainWindow()
        {
            try
            {
                InitializeComponent();

                GMapProvider.WebProxy = null;
                MainMap.MapProvider = GMapProviders.BingSatelliteMap;
                MainMap.ShowTileGridLines = false;
                MainMap.Position = new PointLatLng(35.0, 105.0);
                MainMap.MinZoom = 5;
                MainMap.MaxZoom = 8;
                MainMap.Zoom = 5;
                MainMap.MouseWheelZoomType = MouseWheelZoomType.MousePositionAndCenter;
                MainMap.CanDragMap = true;
                MainMap.DragButton = MouseButton.Right;

                gameTimer = new System.Windows.Threading.DispatcherTimer();
                gameTimer.Interval = TimeSpan.FromSeconds(1);
                gameTimer.Tick += GameTimer_Tick;
                MainMap.MouseMove += MainMap_MouseMove;
                heartbeatTimer = new System.Windows.Threading.DispatcherTimer();
                heartbeatTimer.Interval = TimeSpan.FromSeconds(20);
                heartbeatTimer.Tick += async (s, e) =>
                {
                    if (webSocket != null && webSocket.State == WebSocketState.Open)
                    {
                        // 悄悄向云端发送存活证明
                        await SendCommandAsync("PING", "", "");
                    }
                };
                animationTimer = new System.Windows.Threading.DispatcherTimer();
                animationTimer.Interval = TimeSpan.FromMilliseconds(50);
                animationTimer.Tick += AnimationTimer_Tick;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"司令部严重故障！系统未能启动。\n\n" +
                    $"【错误原因】: {ex.Message}\n\n" +
                    $"【深层原因】: {ex.InnerException?.Message}\n\n" +
                    $"【崩溃位置】: {ex.StackTrace}",
                    "致命启动崩溃", MessageBoxButton.OK, MessageBoxImage.Error);
                Application.Current.Shutdown();
            }
        }

        private double CalculateDistance(PointLatLng start, PointLatLng end)
        {
            double e = 0.017453292519943295;
            double a = start.Lng * e;
            double b = start.Lat * e;
            double c = end.Lng * e;
            double d = end.Lat * e;
            double f = Math.Sin(b) * Math.Sin(d) + Math.Cos(b) * Math.Cos(d) * Math.Cos(a - c);
            return 6371.0 * Math.Acos(Math.Min(1.0, f));
        }

        // ==========================================
        // 🌟 模式切换与账户管理
        // ==========================================
        private void GameMode_Changed(object sender, RoutedEventArgs e)
        {
            if (RdoCoop?.IsChecked == true)
            {
                currentGameMode = "COOP";
                if (CoopPanel != null) CoopPanel.Visibility = Visibility.Visible;
            }
            else
            {
                currentGameMode = "SINGLE";
                if (CoopPanel != null) CoopPanel.Visibility = Visibility.Collapsed;
            }
        }
        // ==========================================
        // 🌟 紧急撤离与系统重置协议 (Hard Reset)
        // ==========================================
        private void ReturnToMainMenu()
        {
            // 1. 彻底切断云端网络与心跳起搏器
            if (webSocket != null)
            {
                webSocket.Abort();
                webSocket.Dispose();
                webSocket = null;
            }
            if (heartbeatTimer != null) heartbeatTimer.Stop();

            // 2. 停止一切游戏物理时钟
            if (gameTimer != null) gameTimer.Stop();
            if (animationTimer != null) animationTimer.Stop();

            // 3. 全局状态彻底格式化
            isGameOver = false;
            isPaused = false;
            isGameStarted = false;
            isPartnerDisconnected = false;
            currentRoomId = "";
            currentRoomPassword = "";
            partnerName = "神秘僚机";
            playerFunds = 10000000000;
            totalTransportedPax = 0;

            // 4. 清理地图引擎与内存驻留
            MainMap.Markers.Clear();
            activeRoutes.Clear();
            flyingPlanes.Clear();
            allAirportsList.Clear();
            currentSelectedMarker = null;

            // 5. 还原游戏面板 UI
            if (GameOverOverlay != null) GameOverOverlay.Visibility = Visibility.Collapsed;
            if (AirportInfoPanel != null) AirportInfoPanel.Visibility = Visibility.Collapsed;

            TxtFunds.Text = "💰 资金: 10,000,000,000";
            TxtFunds.Foreground = Brushes.Gold;
            TxtRadioLog.Text = "等待输入战区代码...";

            // 6. 还原联机大厅 UI
            if (BtnJoinRoom != null)
            {
                BtnJoinRoom.Content = "📡 进 驻 战 区";
                BtnJoinRoom.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));
                BtnJoinRoom.IsEnabled = true;
            }
            if (TxtRoomId != null) TxtRoomId.IsEnabled = true;
            if (TxtRoomPassword != null) TxtRoomPassword.IsEnabled = true;

            if (BtnReady != null)
            {
                BtnReady.Content = "✅ 准备就绪 (等待队友)";
                BtnReady.Background = Brushes.Gray;
                BtnReady.IsEnabled = false;
            }
            if (BtnLeaveRoom != null) BtnLeaveRoom.Visibility = Visibility.Collapsed; // 隐藏撤离按钮

            // 7. 还原左侧主发车按钮
            if (LoadDataBtn != null)
            {
                LoadDataBtn.Content = "🌍 载入航空大亨世界";
                LoadDataBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));
                LoadDataBtn.IsEnabled = true;
            }

            MessageBox.Show("📡 已切断与当前战区的连接，系统已彻底恢复至初始状态！\n您可以载入单机世界，或进驻新的联机战区。", "安全撤离", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // 绑定给 UI 按钮的点击事件
        private void BtnLeaveRoom_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("确定要断开连接并返回大厅吗？\n如果游戏正在进行中，您的僚机将收到您已失联的警告！", "撤离确认", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                ReturnToMainMenu();
            }
        }
        // ==========================================
        // 🚪 撤离协议：安全退出游戏
        // ==========================================
        private async void BtnExitGame_Click(object sender, RoutedEventArgs e)
        {
            // 1. 战术弹窗确认，防止局长在激烈微操时误触！
            MessageBoxResult result = MessageBox.Show(
                "长官，您确定要结束调度、撤离指挥中心吗？\n\n(若当前处于联合营运状态，您的僚机将自动接管全盘资产与上传权限！)",
                "撤离确认 (Exit Protocol)",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                // 2. 🌟 联机善后：如果连着云端服务器，发一份“离线声明”，让队友触发【单飞接管协议】
                if (webSocket != null && webSocket.State == System.Net.WebSockets.WebSocketState.Open)
                {
                    try
                    {
                        // 发射断线核弹
                        await SendCommandAsync("PLAYER_LEFT", "主动撤离");

                        // 优雅关闭 WebSocket
                        await webSocket.CloseAsync(
                            System.Net.WebSockets.WebSocketCloseStatus.NormalClosure,
                            "Commander Offline",
                            System.Threading.CancellationToken.None);
                    }
                    catch
                    {
                        // 忽略断开时可能发生的网络抖动异常
                    }
                }

                // 3. 切断所有时钟电源
                if (gameTimer != null) gameTimer.Stop();
                if (animationTimer != null) animationTimer.Stop();
                if (heartbeatTimer != null) heartbeatTimer.Stop();

                // 4. 彻底销毁进程，关闭程序！
                Application.Current.Shutdown();
            }
        }
        // ==========================================
        // 🌟 动态 Z 轴管理：点击面板自动置顶防遮挡
        // ==========================================
        // ==========================================
        // 🌟 动态 Z 轴管理：加装防吞噬安全锁
        // ==========================================
        private void AirportInfoPanel_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            // 只有当面板不在最顶层时，才触发 Z 轴物理移动，防止吞噬按钮点击！
            if (Panel.GetZIndex(AirportInfoPanel) != 99)
            {
                Panel.SetZIndex(AirportInfoPanel, 99);
                if (CommBasePanel != null) Panel.SetZIndex(CommBasePanel, 0);
            }
        }

        private void CommBasePanel_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (CommBasePanel != null && Panel.GetZIndex(CommBasePanel) != 99)
            {
                Panel.SetZIndex(CommBasePanel, 99);
                Panel.SetZIndex(AirportInfoPanel, 0);
            }
        }
        // ==========================================
        // 🌟 物理引擎：面板最小化折叠
        // ==========================================
        private void MinimizeAirportPanel_Click(object sender, RoutedEventArgs e)
        {
            AirportInfoContent.Visibility = AirportInfoContent.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
            e.Handled = true; // 防止点击最小化时触发底层拖拽
        }
        // ==========================================
        // 🌟 物理防线：自适应体积膨胀碰撞检测 (修复展开出界)
        // ==========================================
        private void DynamicPanel_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (sender is FrameworkElement panel && panel.Parent is FrameworkElement parentContainer)
            {
                TranslateTransform transform = null;
                if (panel.Name == "CommBasePanel") transform = CommTransform;
                else if (panel.Name == "AirportInfoPanel") transform = AirportTransform;

                if (transform != null)
                {
                    // 🌟 核心细节：使用 Dispatcher 延迟执行，确保 UI 的“展开动画和布局”彻底完成后再测算坐标！
                    panel.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        try
                        {
                            Point topLeft = panel.TransformToAncestor(parentContainer).Transform(new Point(0, 0));
                            Point bottomRight = panel.TransformToAncestor(parentContainer).Transform(new Point(panel.ActualWidth, panel.ActualHeight));

                            // 撞破上天花板，强行往下推！
                            if (topLeft.Y < 0) transform.Y -= topLeft.Y;

                            // 撞破下地板，强行往上拉！
                            if (bottomRight.Y > parentContainer.ActualHeight) transform.Y -= (bottomRight.Y - parentContainer.ActualHeight);

                            // 左右边界防御 (同理)
                            if (topLeft.X < 0) transform.X -= topLeft.X;
                            if (bottomRight.X > parentContainer.ActualWidth) transform.X -= (bottomRight.X - parentContainer.ActualWidth);
                        }
                        catch
                        {
                            // 忽略在极速关闭窗口时可能引发的渲染树异常
                        }
                    }), System.Windows.Threading.DispatcherPriority.Loaded);
                }
            }
        }
        private void MinimizeCommPanel_Click(object sender, RoutedEventArgs e)
        {
            CommBaseContent.Visibility = CommBaseContent.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
            e.Handled = true;
        }
        // ==========================================
        // 🔒 安全阀：战时 UI 物理死锁协议
        // ==========================================
        private void LockGameModeUI(bool isLocked)
        {
            Application.Current.Dispatcher.Invoke(() => {
                // 游戏开始时(isLocked=true)，禁用单人/双人切换按钮
                if (RdoSingle != null) RdoSingle.IsEnabled = !isLocked;
                if (RdoCoop != null) RdoCoop.IsEnabled = !isLocked;

                // 可选细节：顺便把战区代码和密码框也锁死，防止战时瞎改
                if (TxtRoomId != null) TxtRoomId.IsEnabled = !isLocked;
                if (TxtRoomPassword != null) TxtRoomPassword.IsEnabled = !isLocked;
            });
        }

        // ==========================================
        // 🌟 物理引擎：全局自由拖拽系统
        // ==========================================
        private bool isDraggingHUD = false;
        private Point lastMousePosition;
        private TranslateTransform activeTransform = null;
       
        private Point dragStartMousePosition; // 记录按下瞬间的鼠标位置
        private double initialTransformX;     // 记录按下瞬间的面板 X 偏移
        private double initialTransformY;     // 记录按下瞬间的面板 Y 偏移

        
        private FrameworkElement activePanel = null; // 🌟 新增：记录当前正在移动的物理面板本体
        private void PanelHeader_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is FrameworkElement header)
            {
                string tag = header.Tag as string;
                if (tag == "Airport")
                {
                    activeTransform = AirportTransform;
                    activePanel = AirportInfoPanel;
                }
                else if (tag == "Comm")
                {
                    activeTransform = CommTransform;
                    activePanel = CommBasePanel;
                }

                if (activeTransform != null && activePanel != null)
                {
                    isDraggingHUD = true;
                    // 🌟 核心防滑：锚定初始坐标，杜绝鼠标出界后的增量误差！
                    dragStartMousePosition = e.GetPosition(this);
                    initialTransformX = activeTransform.X;
                    initialTransformY = activeTransform.Y;

                    header.CaptureMouse();
                    e.Handled = true;
                }
            }
        }
        // ==========================================
        // 🌟 差异化机队采购中心
        // ==========================================
        private async void BuySpecificPlane_Click(object sender, RoutedEventArgs e)
        {
            if (currentSelectedMarker == null || !(sender is Button btn)) return;

            GameAirportInfo selectedAirport = (currentSelectedMarker.Shape as FrameworkElement).Tag as GameAirportInfo;
            if (selectedAirport == null) return;

            string planeModelStr = btn.Tag as string; // 获取绑定的机型 (Regional, Widebody, Supersonic)
            PlaneModelType requestedModel = (PlaneModelType)Enum.Parse(typeof(PlaneModelType), planeModelStr);

            // 生成一个临时假飞机来读取属性
            GamePlaneInfo previewPlane = new GamePlaneInfo { Model = requestedModel };

            // 1. 校验机场等级门槛
            if (selectedAirport.Level < previewPlane.RequiredAirportLevel)
            {
                MessageBox.Show($"跑道长度不足！\n\n【{previewPlane.ModelName}】需要机场等级达到 Lv.{previewPlane.RequiredAirportLevel} 才能起降！\n请先扩建机场。", "塔台警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 2. 校验资金
            if (playerFunds < previewPlane.Cost)
            {
                MessageBox.Show($"财政赤字！\n\n您的资金不足以购买【{previewPlane.ModelName}】(需要 ¥{previewPlane.Cost:N0})。", "财务警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            // ==========================================
            // 🚀 核心点火：智能分流调度
            // ==========================================
            if (RdoSingle.IsChecked == true)
            {
                // 🌟 孤狼单机模式：没有云端，直接伪造一个网络包喂给本地接收器！
                var localCmd = new GameSyncCommand
                {
                    ActionType = "BUY_PLANE",
                    Sender = TxtPlayerName.Text,
                    TargetId = selectedAirport.Name,
                    AdditionalData = planeModelStr
                };
                // 直接调用您原本处理网络包的方法，完美复用扣钱和战报逻辑！
                ExecuteSyncCommand(localCmd);
            }
            else
            {
                // 📡 双人合作模式：发射到云端，等待云端回传广播
                await SendCommandAsync("BUY_PLANE", selectedAirport.Name, planeModelStr);
            }

            // 3. 发射联机采购指令 (AdditionalData 携带机型情报)
           // await SendCommandAsync("BUY_PLANE", selectedAirport.Name, planeModelStr);
        }

        private void PanelHeader_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDraggingHUD && activeTransform != null && activePanel != null)
            {
                // 1. 根据鼠标滑动的距离，计算位移
                Point currentMousePosition = e.GetPosition(this);
                activeTransform.X = initialTransformX + (currentMousePosition.X - dragStartMousePosition.X);
                activeTransform.Y = initialTransformY + (currentMousePosition.Y - dragStartMousePosition.Y);

                // 🌟 核心防线升级：找到容纳面板和地图的那个“父级容器 (Parent Grid)”
                if (activePanel.Parent is FrameworkElement parentContainer)
                {
                    // ===============================================
                    // 🛡️ 战区绝对屏障：计算面板在【地图区域内】的坐标
                    // ===============================================
                    Point topLeft = activePanel.TransformToAncestor(parentContainer).Transform(new Point(0, 0));
                    Point bottomRight = activePanel.TransformToAncestor(parentContainer).Transform(new Point(activePanel.ActualWidth, activePanel.ActualHeight));

                    // 撞破上天花板
                    if (topLeft.Y < 0)
                        activeTransform.Y -= topLeft.Y;

                    // 🌟 撞破左墙壁 (完美解决！它撞到地图的左边缘就会停下，绝不会钻进左侧的菜单栏)
                    if (topLeft.X < 0)
                        activeTransform.X -= topLeft.X;

                    // 撞破右边界 (相对于右侧地图区域的宽度)
                    if (bottomRight.X > parentContainer.ActualWidth)
                        activeTransform.X -= (bottomRight.X - parentContainer.ActualWidth);

                    // 撞破下地板 (相对于右侧地图区域的高度)
                    if (bottomRight.Y > parentContainer.ActualHeight)
                        activeTransform.Y -= (bottomRight.Y - parentContainer.ActualHeight);
                }
            }
        }

        private void PanelHeader_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (isDraggingHUD)
            {
                isDraggingHUD = false;
                activeTransform = null;
                activePanel = null;
                if (sender is FrameworkElement header)
                {
                    header.ReleaseMouseCapture();
                }
            }
        }
        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void ClosePanel_Click(object sender, RoutedEventArgs e)
        {
            AirportInfoPanel.Visibility = Visibility.Collapsed;
        }
    }
}