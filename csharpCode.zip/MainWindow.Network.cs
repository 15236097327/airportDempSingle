﻿using GMap.NET;
using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace FlightDispatchClient
{
    public partial class MainWindow : Window
    {
        private string currentRoomPassword = ""; // 🌟 存储当前口令
        private bool isPartnerDisconnected = false; // 记录逃兵状态
        private bool isUploadLocked = false;        // 防止重复上传锁
        //private string currentRoomPassword = "";    // 房间机密口令
        public enum DispatchStrategy
        {
            Off,          // 关闭自动调度
            ProfitFirst,  // 利润至上 (哪条线赚得多飞哪条)
            RescueFirst,  // 紧急救援 (哪个机场快爆了飞哪个)
            Balanced      // 均衡模式
        }

        // 在 MainWindow 中记录当前策略
        private DispatchStrategy currentAIStrategy = DispatchStrategy.Off;
        private async void BtnJoinRoom_Click(object sender, RoutedEventArgs e)
        {
            currentRoomId = TxtRoomId.Text.Trim();
            currentRoomPassword = TxtRoomPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(currentRoomId))
            {
                MessageBox.Show("战区代码不能为空！", "警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 🌟 1. 冻结面板，等待云端宣判 (绝对不要在这里显示“已进驻”)
            BtnJoinRoom.Content = "📡 校验口令中...";
            BtnJoinRoom.Background = Brushes.DimGray;
            BtnJoinRoom.IsEnabled = false;
            TxtRoomId.IsEnabled = false;
            if (TxtRoomPassword != null) TxtRoomPassword.IsEnabled = false;

            try
            {
                if (webSocket == null || webSocket.State != WebSocketState.Open)
                {
                    webSocket = new System.Net.WebSockets.ClientWebSocket();
                    await webSocket.ConnectAsync(new Uri("ws://124.220.178.183:8084/game-room"), System.Threading.CancellationToken.None);
                    _ = Task.Run(ReceiveNetworkMessages);
                    if (heartbeatTimer != null) heartbeatTimer.Start();
                }

                // 🌟 2. 发射加入请求，然后耐心等待服务器的回音
                await SendCommandAsync("JOIN_ROOM");
            }
            catch (Exception ex)
            {
                MessageBox.Show("连接总部服务器失败，请检查网络！\n" + ex.Message, "失联", MessageBoxButton.OK, MessageBoxImage.Error);
                ReturnToMainMenu(); // 如果连不上，直接格式化恢复 UI
            }
        }

        private async Task SendCommandAsync(string action, string target = "", string additional = "")
        {
            if (webSocket != null && webSocket.State == WebSocketState.Open)
            {
                var cmd = new GameSyncCommand
                {
                    Sender = TxtPlayerName.Text,
                    ActionType = action,
                    TargetId = target,
                    AdditionalData = additional,
                    RoomId = currentRoomId,
                    RoomPassword = currentRoomPassword
                };

                var options = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
                string json = JsonSerializer.Serialize(cmd, options);
                var bytes = Encoding.UTF8.GetBytes(json);
                await webSocket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, System.Threading.CancellationToken.None);
            }
        }
        private async Task ReceiveNetworkMessages()
        {
            var buffer = new byte[1024 * 8]; // 基础缓冲池扩大到 8KB
            try
            {
                while (webSocket.State == WebSocketState.Open)
                {
                    // 🌟 核心升级：使用内存流，拼接超大号的快照包裹！
                    using (var ms = new System.IO.MemoryStream())
                    {
                        WebSocketReceiveResult result;
                        do
                        {
                            result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), System.Threading.CancellationToken.None);
                            if (result.MessageType == WebSocketMessageType.Close) break;

                            ms.Write(buffer, 0, result.Count); // 把收到的碎片拼起来
                        }
                        while (!result.EndOfMessage); // 如果包没传完，继续收！

                        if (result.MessageType == WebSocketMessageType.Close) break;

                        // 包裹接收完毕，解压成字符串
                        ms.Seek(0, System.IO.SeekOrigin.Begin);
                        using (var reader = new System.IO.StreamReader(ms, Encoding.UTF8))
                        {
                            string message = reader.ReadToEnd();
                            Dispatcher.Invoke(() =>
                            {
                                try
                                {
                                    var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                                    var cmd = JsonSerializer.Deserialize<GameSyncCommand>(message, options);
                                    if (cmd != null && !string.IsNullOrEmpty(cmd.ActionType))
                                    {
                                        ExecuteSyncCommand(cmd);
                                    }
                                }
                                catch
                                {
                                    TxtRadioLog.Text += $"\n[乱码或非标指令]: {message}";
                                }
                            });
                        }
                    }
                }
            }
            catch (Exception) { /* 静默处理断线 */ }
        }



        private void ExecuteSyncCommand(GameSyncCommand cmd)
        {
            // ==========================================================
            // 🛡️ 第 1 层：【物理隔离防线】
            // ==========================================================
            if (!string.IsNullOrEmpty(cmd.RoomId) && cmd.RoomId != currentRoomId)
            {
                return; // 拒收！绝不让其他房间的信号污染我的内存！
            }

            // ==========================================================
            // 📡 第 2 层：【雷达身份嗅探】
            // ==========================================================
            if (cmd.Sender != TxtPlayerName.Text && cmd.Sender != "SERVER(总部服务器)" && !string.IsNullOrEmpty(cmd.Sender))
            {
                partnerName = cmd.Sender;
            }

            // ==========================================================
            // 🛑 第 3 层：【安检与生命线拦截】 (错误直接 return)
            // ==========================================================
            if (cmd.ActionType == "WRONG_PASSWORD")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (webSocket != null) { webSocket.Abort(); webSocket.Dispose(); webSocket = null; }
                    if (heartbeatTimer != null) heartbeatTimer.Stop();

                    BtnJoinRoom.Content = "📡 进 驻 战 区";
                    BtnJoinRoom.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));
                    BtnJoinRoom.IsEnabled = true;
                    TxtRoomId.IsEnabled = true;
                    if (TxtRoomPassword != null) TxtRoomPassword.IsEnabled = true;

                    MessageBox.Show($"进驻战区 [{currentRoomId}] 失败！\n\n您输入的机密口令不正确，请重新核对。", "访问被拒绝", MessageBoxButton.OK, MessageBoxImage.Error);
                    currentRoomId = "";
                    currentRoomPassword = "";
                });
                return;
            }

            if (cmd.ActionType == "ROOM_FULL")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (webSocket != null) { webSocket.Abort(); webSocket.Dispose(); webSocket = null; }
                    if (heartbeatTimer != null) heartbeatTimer.Stop();

                    BtnJoinRoom.Content = "📡 进 驻 战 区";
                    BtnJoinRoom.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));
                    BtnJoinRoom.IsEnabled = true;
                    TxtRoomId.IsEnabled = true;
                    if (TxtRoomPassword != null) TxtRoomPassword.IsEnabled = true;

                    MessageBox.Show($"您请求进驻的战区 [{currentRoomId}] 已经满员！\n请更换一个战区代号。", "战区满员", MessageBoxButton.OK, MessageBoxImage.Warning);
                    currentRoomId = "";
                });
                return;
            }

            if (cmd.ActionType == "PLAYER_LEFT")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    isPartnerDisconnected = true; // 依然打上逃兵标记（为了结尾结算时给你最高权限）

                    // 把暂停按钮变成黄色警报状态，但不强制暂停游戏！
                    if (PauseGameBtn != null)
                    {
                        PauseGameBtn.Content = "⚠️ 僚机断连 (单飞模式)";
                        PauseGameBtn.Background = Brushes.DarkGoldenrod;
                    }

                    if (GameOverOverlay.Visibility == Visibility.Visible)
                    {
                        // 场景 A：如果你们刚好打完了弹出结算面板，队友掉线了，你立刻解锁上传按钮！
                        if (BtnUploadReport != null)
                        {
                            BtnUploadReport.IsEnabled = true;
                            BtnUploadReport.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));
                            BtnUploadReport.Content = "📤 紧急接管并上传数据";
                        }
                        if (SubmitScoreBtn != null)
                        {
                            SubmitScoreBtn.IsEnabled = true;
                            SubmitScoreBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF8C00"));
                            SubmitScoreBtn.Content = "🏆 紧急接管打榜";
                        }
                        MessageBox.Show("🚨 僚机已断开连接！您已自动获得本局数据的最高上传授权。", "紧急接管", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        // 🌟 场景 B：游戏正在进行中队友掉线！(致命Bug修复处)
                        // 绝对不调用 TriggerGameOver！只打印警报，游戏继续！
                        TxtRadioLog.Text += "\n⚠️ [系统警报]: 僚机已断线！指挥官，您已接管全盘指挥权，请继续营运，随时准备为僚机重连提供快照！";
                        if (TxtRadioLog.Parent is ScrollViewer svLog) svLog.ScrollToBottom();

                        MessageBox.Show(
                            "🚨 僚机指挥官已失去连接！\n\n不必惊慌！【代号：凤凰】重连协议已就绪。您可以继续进行调度营运，当僚机重新进驻本战区时，系统会自动将您打下的江山全息同步给他！",
                            "僚机失联 - 开启单飞模式",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);
                    }
                });
                return;
            }

            // ==========================================================
            // 🔁 第 4 层：【大厅进驻与“代号凤凰”重连系统】
            // ==========================================================
            if (cmd.ActionType == "JOIN_ROOM")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (cmd.Sender == TxtPlayerName.Text)
                    {
                        // 自己成功加入的回音：解锁UI
                        BtnJoinRoom.Content = "✅ 已进驻";
                        BtnJoinRoom.Background = Brushes.SeaGreen;
                        BtnReady.IsEnabled = true;
                        BtnReady.Background = Brushes.DarkGoldenrod;
                        if (BtnLeaveRoom != null) BtnLeaveRoom.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        // 队友加入：判断是否需要打包世界
                        if (isGameStarted)
                        {
                            isPartnerDisconnected = false;
                            TxtRadioLog.Text += $"\n📡 侦测到僚机 [{partnerName}] 重连！正在全息打包当前世界状态...";

                            try
                            {
                                var state = new FullStateDTO
                                {
                                    Funds = playerFunds,
                                    Pax = totalTransportedPax,
                                    Ticks = gameVirtualTime.Ticks,
                                    IsPaused = isPaused,
                                    Airports = allAirportsList,
                                    Routes = activeRoutes.Select(r => new SyncRouteDTO { StartName = ((GameAirportInfo)((FrameworkElement)r.StartNode.Shape).Tag).Name, EndName = ((GameAirportInfo)((FrameworkElement)r.EndNode.Shape).Tag).Name }).ToList(),
                                    Flights = flyingPlanes.Select(f => new SyncFlightDTO { StartName = ((GameAirportInfo)((FrameworkElement)f.StartNode.Shape).Tag).Name, EndName = ((GameAirportInfo)((FrameworkElement)f.EndNode.Shape).Tag).Name, Progress = f.Progress, Passengers = f.Passengers, ExpectedProfit = f.ExpectedProfit, FlightCode = f.FlightCode, PhysicalPlane = f.PhysicalPlane }).ToList()
                                };
                                string jsonState = JsonSerializer.Serialize(state, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });

                                TxtRadioLog.Text += $"\n📦 [系统提示]: 快照打包完成！准备发射！";
                                _ = SendCommandAsync("SYNC_FULL_STATE", "", jsonState);
                            }
                            catch (Exception ex) { MessageBox.Show($"打包失败：{ex.Message}"); }
                        }
                        else
                        {
                            TxtRadioLog.Text += $"\n✅ 僚机 [{partnerName}] 已进入战区，等待双方就绪。";
                        }
                        if (TxtRadioLog.Parent is ScrollViewer svLog) svLog.ScrollToBottom();
                    }
                });
                return;
            }

            if (cmd.ActionType == "SYNC_FULL_STATE")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    try
                    {
                        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                        var state = JsonSerializer.Deserialize<FullStateDTO>(cmd.AdditionalData, options);

                        // 🌟 核心补丁 1：如果重连者的世界是空的，立刻帮他强行“创世”加载红点！
                        if (allAirportsList == null || allAirportsList.Count == 0)
                        {
                            TxtRadioLog.Text += "\n🌐 [系统]: 侦测到本地地图为空，正在自动重建世界基础地形...";
                            LoadDataBtn_Click(null, null);
                        }

                        // 1. 恢复资产与时间
                        playerFunds = state.Funds;
                        totalTransportedPax = state.Pax;
                        gameVirtualTime = new DateTime(state.Ticks);
                        isPaused = state.IsPaused;
                        TxtFunds.Text = $"💰 资金: {playerFunds:N0}";

                        // 2. 刷新所有机场的等级、客流、驻扎飞机
                        foreach (var syncApt in state.Airports)
                        {
                            var localApt = allAirportsList.FirstOrDefault(a => a.Name == syncApt.Name);
                            if (localApt != null)
                            {
                                localApt.Level = syncApt.Level;
                                localApt.CurrentPassengers = syncApt.CurrentPassengers;
                                localApt.Profit = syncApt.Profit;
                                localApt.LocalFleet = syncApt.LocalFleet;
                                localApt.Demands = syncApt.Demands;
                            }
                        }

                        // 🌟 核心补丁 2：安全擦除旧航线，彻底杜绝类型转换崩溃！
                        var oldRoutes = MainMap.Markers.OfType<GMapRoute>().ToList();
                        foreach (var routeMarker in oldRoutes)
                        {
                            MainMap.Markers.Remove(routeMarker);
                        }
                        foreach (var f in flyingPlanes)
                        {
                            MainMap.Markers.Remove(f.Marker);
                        }
                        activeRoutes.Clear();
                        flyingPlanes.Clear();

                        // 🌟 核心补丁 3：全息重建航线 (使用完整的贝塞尔曲线算法)
                        foreach (var rData in state.Routes)
                        {
                            GMapMarker sMarker = MainMap.Markers.FirstOrDefault(m => m.Shape is FrameworkElement fe && (fe.Tag as GameAirportInfo)?.Name == rData.StartName);
                            GMapMarker eMarker = MainMap.Markers.FirstOrDefault(m => m.Shape is FrameworkElement fe && (fe.Tag as GameAirportInfo)?.Name == rData.EndName);

                            if (sMarker != null && eMarker != null)
                            {
                                double dist = CalculateDistance(sMarker.Position, eMarker.Position);
                                double sLat = sMarker.Position.Lat, sLng = sMarker.Position.Lng;
                                double eLat = eMarker.Position.Lat, eLng = eMarker.Position.Lng;

                                List<PointLatLng> arcPts = new List<PointLatLng>();
                                double mLat = (sLat + eLat) / 2.0, mLng = (sLng + eLng) / 2.0;
                                double cLat = mLat + (eLng - sLng) * 0.2, cLng = mLng - (eLat - sLat) * 0.2;

                                for (int i = 0; i <= 20; i++)
                                {
                                    double t = i / 20.0, u = 1 - t;
                                    arcPts.Add(new PointLatLng((u * u * sLat) + (2 * u * t * cLat) + (t * t * eLat), (u * u * sLng) + (2 * u * t * cLng) + (t * t * eLng)));
                                }

                                // 随机分配霓虹色彩
                                Color[] neonColors = { Color.FromArgb(200, 0, 255, 255), Color.FromArgb(200, 255, 0, 255), Color.FromArgb(200, 255, 165, 0), Color.FromArgb(200, 50, 255, 50) };
                                Color rColor = neonColors[randomEngine != null ? randomEngine.Next(neonColors.Length) : new Random().Next(neonColors.Length)];

                                GMapRoute fRoute = new GMapRoute(arcPts)
                                {
                                    Shape = new System.Windows.Shapes.Path { Stroke = new SolidColorBrush(rColor), StrokeThickness = 2, StrokeDashArray = new DoubleCollection { 4, 3 }, Effect = new System.Windows.Media.Effects.DropShadowEffect { Color = rColor, BlurRadius = 12, ShadowDepth = 0 } }
                                };
                                MainMap.Markers.Add(fRoute);
                                PointLatLng midP1 = arcPts[10];
                                PointLatLng midP2 = arcPts[11];
                                double arrowAngle = Math.Atan2(midP1.Lat - midP2.Lat, midP2.Lng - midP1.Lng) * 180 / Math.PI;
                                TextBlock arrowVis = new TextBlock
                                {
                                    Text = "➤",
                                    FontSize = 16,
                                    Foreground = new SolidColorBrush(rColor), // 颜色跟航线保持一致
                                    RenderTransformOrigin = new Point(0.5, 0.5),
                                    RenderTransform = new RotateTransform(arrowAngle),
                                    IsHitTestVisible = false, // 禁止鼠标点击，防止阻挡后面的地图交互
                                    Tag = "ROUTE_ARROW"       // 🏷️ 贴个高亮标签，方便后面大扫除！
                                };

                                // 把箭头固定在航线的正中央
                                GMapMarker arrowMarker = new GMapMarker(midP1)
                                {
                                    Shape = arrowVis,
                                    Offset = new Point(-8, -10), // 让箭头完美居中
                                    ZIndex = 499 // 放在飞机的下面，航线的上面
                                };
                                MainMap.Markers.Add(arrowMarker);
                                // 计算箭头偏转角度 (WPF中角度顺时针为正)
                                
                                activeRoutes.Add(new GameRouteInfo { StartNode = sMarker, EndNode = eMarker, Distance = dist });
                            }
                        }

                        // 🌟 核心补丁 4：全息重建空中飞机 (包含飞机大小、偏转角度、飞行进度)
                        foreach (var fData in state.Flights)
                        {
                            GMapMarker sMarker = MainMap.Markers.FirstOrDefault(m => m.Shape is FrameworkElement fe && (fe.Tag as GameAirportInfo)?.Name == fData.StartName);
                            GMapMarker eMarker = MainMap.Markers.FirstOrDefault(m => m.Shape is FrameworkElement fe && (fe.Tag as GameAirportInfo)?.Name == fData.EndName);
                            if (sMarker != null && eMarker != null)
                            {
                                double t = fData.Progress, u = 1 - t;
                                double sLat = sMarker.Position.Lat, sLng = sMarker.Position.Lng;
                                double eLat = eMarker.Position.Lat, eLng = eMarker.Position.Lng;
                                double mLat = (sLat + eLat) / 2.0, mLng = (sLng + eLng) / 2.0;
                                double cLat = mLat + (eLng - sLng) * 0.2, cLng = mLng - (eLat - sLat) * 0.2;

                                // 计算飞机当前应该在的精确坐标
                                double curLat = (u * u * sLat) + (2 * u * t * cLat) + (t * t * eLat);
                                double curLng = (u * u * sLng) + (2 * u * t * cLng) + (t * t * eLng);

                                // 计算飞机的偏转角度
                                double angle = Math.Atan2(sLat - eLat, eLng - sLng) * 180 / Math.PI + 45;
                                TextBlock planeVis = new TextBlock { Text = "✈", FontSize = 22 + (fData.PhysicalPlane.Level * 8), Foreground = Brushes.White, RenderTransformOrigin = new Point(0.5, 0.5), RenderTransform = new RotateTransform(angle), Cursor = Cursors.Hand };
                                GMapMarker planeMarker = new GMapMarker(new PointLatLng(curLat, curLng)) { Shape = planeVis, Offset = new Point(-15, -15), ZIndex = 1000 };

                                // 计算当前航线的标准速度
                                double speed = 60.0 / CalculateDistance(sMarker.Position, eMarker.Position);

                                ActiveFlight nFlight = new ActiveFlight { Marker = planeMarker, StartNode = sMarker, EndNode = eMarker, Progress = fData.Progress, Speed = speed, Passengers = fData.Passengers, ExpectedProfit = fData.ExpectedProfit, PhysicalPlane = fData.PhysicalPlane, FlightCode = fData.FlightCode };
                                planeVis.Tag = nFlight;
                                planeVis.MouseLeftButtonDown += Flight_MouseLeftButtonDown; // 恢复点击查阅航班的功能

                                MainMap.Markers.Add(planeMarker);
                                flyingPlanes.Add(nFlight);
                            }
                        }

                        // 4. 暴力拉起时钟并恢复 UI 控制权！
                        isGameStarted = true;
                        isGameOver = false;
                        LoadDataBtn.Content = "🛑 结束游戏 (主动结算)";
                        LoadDataBtn.Background = Brushes.Crimson;
                        BtnReady.Content = "⚔️ 重连成功！";
                        BtnReady.IsEnabled = false;

                        if (!isPaused)
                        {
                            gameTimer.Start();
                            animationTimer.Start();
                        }

                        MessageBox.Show("📡 全息快照同步完成！已原地恢复至僚机当前战况！", "代号：凤凰", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"重连解析失败，请联系指挥中心：{ex.Message}", "同步失败", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                });
                return;
            }

            // ==========================================================
            // 🔒 第 5 层：【打榜防重复锁】
            // ==========================================================
            if (cmd.ActionType == "LOCK_SUBMIT_BTN")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (SubmitScoreBtn != null) { SubmitScoreBtn.IsEnabled = false; SubmitScoreBtn.Content = "🏆 队友已接管打榜"; SubmitScoreBtn.Background = Brushes.Gray; }
                });
                return;
            }
            else if (cmd.ActionType == "LOCK_UPLOAD_BTN")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (BtnUploadReport != null) { BtnUploadReport.IsEnabled = false; BtnUploadReport.Content = "☁️ 队友正在传黑匣子"; BtnUploadReport.Background = Brushes.Gray; }
                    MessageBox.Show($"僚机指挥官 [{cmd.Sender}] 正在向云端上传联合战报！\n你无需再次上传，防止数据重复覆盖。", "协同防重", MessageBoxButton.OK, MessageBoxImage.Information);
                });
                return;
            }

            // ==========================================================
            // 💥 第 6 层：【核弹洗地与对账】
            // ==========================================================
            if (cmd.ActionType == "SYNC_GAME_OVER" || cmd.ActionType == "SYNC_AUTO_GAME_OVER")
            {
                long newFunds = playerFunds, newPax = totalTransportedPax, newTicks = gameVirtualTime.Ticks;
                if (!string.IsNullOrEmpty(cmd.AdditionalData) && cmd.AdditionalData.Contains("|"))
                {
                    string[] parts = cmd.AdditionalData.Split('|');
                    if (parts.Length >= 2) { long.TryParse(parts[0], out newFunds); long.TryParse(parts[1], out newPax); }
                    if (parts.Length >= 3) { long.TryParse(parts[2], out newTicks); }
                }

                bool shouldOverride = false;
                if (cmd.ActionType == "SYNC_GAME_OVER") shouldOverride = true;
                else
                {
                    if (!isGameOver) shouldOverride = true;
                    else if (string.Compare(cmd.Sender, TxtPlayerName.Text) < 0) shouldOverride = true;
                }

                if (shouldOverride)
                {
                    playerFunds = newFunds; totalTransportedPax = newPax; gameVirtualTime = new DateTime(newTicks);
                    if (currentSessionReport != null)
                    {
                        currentSessionReport.FinalFunds = playerFunds; currentSessionReport.TransportedPax = totalTransportedPax;
                        currentSessionReport.SurvivedDays = (gameVirtualTime - new DateTime(2026, 1, 1)).Days;
                    }
                    Application.Current.Dispatcher.Invoke(() => {
                        if (GameOverOverlay.Visibility == Visibility.Visible)
                        {
                            TxtFinalFunds.Text = $"💰 最终结余: ¥ {playerFunds:N0}";
                            TxtFinalPax.Text = $"👥 累计运送: {totalTransportedPax:N0} 人次";
                            if (TxtFinalDays != null) TxtFinalDays.Text = $"🏆 存活时间: {(gameVirtualTime - new DateTime(2026, 1, 1)).Days} 天";
                        }
                    });
                }

                if (!isGameOver)
                {
                    isGameOver = true; isGameStarted = false;
                    var crashedAirport = allAirportsList.FirstOrDefault(a => a.Name == cmd.TargetId);
                    Application.Current.Dispatcher.Invoke(() => {
                        if (gameTimer != null) gameTimer.Stop();
                        if (animationTimer != null) animationTimer.Stop();
                        LoadDataBtn.Content = "🛑 营运已终止"; LoadDataBtn.Background = Brushes.Gray; LoadDataBtn.IsEnabled = false;
                        TriggerGameOver(crashedAirport);
                    });
                }
                return;
            }

            // ==========================================================
            // 💀 第 7 层：【死亡免疫层】
            // ==========================================================
            if (isGameOver) return;

            // ==========================================================
            // ⚙️ 第 8 层：【日常战术业务层】
            // ==========================================================
            Application.Current.Dispatcher.Invoke(() => {
                TxtRadioLog.Text += $"\n[{cmd.Sender}]: {cmd.ActionType}";
                if (TxtRadioLog.Parent is ScrollViewer sv) sv.ScrollToBottom();
            });

            if (cmd.ActionType == "START_GAME")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    TxtRadioLog.Text += "\n🚀 双方指挥官均已就绪，全网时空同步点火！";
                    int seed = 0;
                    if (!string.IsNullOrEmpty(currentRoomId) && int.TryParse(currentRoomId, out int parsedRoomId)) seed = parsedRoomId;
                    randomEngine = new Random(seed);

                    LoadDataBtn.IsEnabled = true;
                    LoadDataBtn.Content = "▶️ 开始调度";
                    LoadDataBtn_Click(null, null);

                    BtnReady.Content = "⚔️ 联机交战中...";
                    BtnReady.Background = Brushes.DimGray;
                    BtnReady.IsEnabled = false;
                });
            }
            else if (cmd.ActionType == "PAUSE")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (!isGameStarted) return;
                    if (gameTimer != null) gameTimer.Stop();
                    if (animationTimer != null) animationTimer.Stop();
                    isPaused = true;
                    PauseGameBtn.Content = "▶️ 解除冻结 (全网 Resume)";
                    PauseGameBtn.Background = Brushes.SeaGreen;
                });
            }
            else if (cmd.ActionType == "RESUME")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (!isGameStarted) return;
                    if (gameTimer != null) gameTimer.Start();
                    if (animationTimer != null) animationTimer.Start();
                    isPaused = false;
                    PauseGameBtn.Content = "⏸️ 战术暂停 (全网 Bullet Time)";
                    PauseGameBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF8C00"));
                });
            }
            else if (cmd.ActionType == "BUY_PLANE")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    var targetAirport = allAirportsList.FirstOrDefault(a => a.Icao == cmd.TargetId || a.Name == cmd.TargetId);
                    if (targetAirport != null)
                    {
                        // 解析传过来的机型，如果没有传，默认给最便宜的支线客机
                        PlaneModelType boughtModel = PlaneModelType.Regional;
                        if (!string.IsNullOrEmpty(cmd.AdditionalData))
                        {
                            Enum.TryParse(cmd.AdditionalData, out boughtModel);
                        }

                        GamePlaneInfo newPlane = new GamePlaneInfo
                        {
                            Id = (boughtModel == PlaneModelType.Supersonic ? "S-" : "B-") + randomEngine.Next(1000, 9999),
                            Model = boughtModel,
                            Level = boughtModel == PlaneModelType.Regional ? 1 : (boughtModel == PlaneModelType.Widebody ? 2 : 3)
                        };

                        // 扣除这架飞机专属的真实造价
                        playerFunds -= newPlane.Cost;
                        TxtFunds.Text = $"💰 资金: {playerFunds:N0}";

                        targetAirport.LocalFleet.Add(newPlane);

                        // 更霸气的战报播报
                        string colorHex = boughtModel == PlaneModelType.Regional ? "#2E8B57" : (boughtModel == PlaneModelType.Widebody ? "#4169E1" : "#B22222");
                        TxtRadioLog.Text += $"\n✈️ [军火]: 指挥官 {cmd.Sender} 耗资 ¥{newPlane.Cost / 100000000.0:0.##}亿，为 {targetAirport.Name} 添置了【{newPlane.ModelName}】({newPlane.Id})！";

                        if (currentSelectedMarker != null && ((currentSelectedMarker.Shape as FrameworkElement).Tag as GameAirportInfo)?.Name == targetAirport.Name)
                        {
                            RefreshPanelUI(targetAirport);
                        }
                    }
                });
            }
            else if (cmd.ActionType == "OPEN_ROUTE")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    string srcName = cmd.TargetId;
                    string destName = cmd.AdditionalData;

                    GMapMarker startMarker = MainMap.Markers.FirstOrDefault(m => m.Shape is FrameworkElement fe && (fe.Tag as GameAirportInfo)?.Name == srcName);
                    GMapMarker endMarker = MainMap.Markers.FirstOrDefault(m => m.Shape is FrameworkElement fe && (fe.Tag as GameAirportInfo)?.Name == destName);

                    if (startMarker != null && endMarker != null && !activeRoutes.Any(r => r.StartNode == startMarker && r.EndNode == endMarker))
                    {
                        double dist = CalculateDistance(startMarker.Position, endMarker.Position);
                        long routeCost = (long)(dist * 5000);

                        playerFunds -= routeCost;
                        TxtFunds.Text = $"💰 资金: {playerFunds:N0}";
                        if (playerFunds < 0) TxtFunds.Foreground = Brushes.Red;

                        double startLat = startMarker.Position.Lat, startLng = startMarker.Position.Lng;
                        double endLat = endMarker.Position.Lat, endLng = endMarker.Position.Lng;
                        List<PointLatLng> arcPoints = new List<PointLatLng>();
                        double midLat = (startLat + endLat) / 2.0, midLng = (startLng + endLng) / 2.0;
                        double ctrlLat = midLat + (endLng - startLng) * 0.2, ctrlLng = midLng - (endLat - startLat) * 0.2;

                        for (int i = 0; i <= 20; i++)
                        {
                            double t = i / 20.0, u = 1 - t;
                            arcPoints.Add(new PointLatLng((u * u * startLat) + (2 * u * t * ctrlLat) + (t * t * endLat), (u * u * startLng) + (2 * u * t * ctrlLng) + (t * t * endLng)));
                        }
                        Color[] neonColors = {
                    Color.FromArgb(200, 0, 255, 255),   // 赛博青
                    Color.FromArgb(200, 255, 0, 255),   // 霓虹紫
                    Color.FromArgb(200, 255, 165, 0),   // 警戒橙
                    Color.FromArgb(200, 50, 255, 50)    // 辐射绿
                }; Color routeColor = neonColors[randomEngine != null ? randomEngine.Next(neonColors.Length) : new Random().Next(neonColors.Length)];
                        //Color routeColor = Color.FromArgb(200, 0, 255, 255); // 默认青色
                        GMapRoute finalRoute = new GMapRoute(arcPoints)
                        {
                            Shape = new System.Windows.Shapes.Path { Stroke = new SolidColorBrush(routeColor), StrokeThickness = 2, StrokeDashArray = new DoubleCollection { 4, 3 },
                                Effect = new System.Windows.Media.Effects.DropShadowEffect { Color = routeColor, BlurRadius = 12, ShadowDepth = 0 }

                            }

                        };

                        MainMap.Markers.Add(finalRoute);
                        activeRoutes.Add(new GameRouteInfo { StartNode = startMarker, EndNode = endMarker, Distance = dist });

                        // 🌟 新增：在航线正中间加装方向箭头！(严格遵守执行顺序)
                        PointLatLng midP1 = arcPoints[10];
                        PointLatLng midP2 = arcPoints[11];
                        double arrowAngle = Math.Atan2(midP1.Lat - midP2.Lat, midP2.Lng - midP1.Lng) * 180 / Math.PI;

                        TextBlock arrowVis = new TextBlock
                        {
                            Text = "➤",
                            FontSize = 16,
                            Foreground = new SolidColorBrush(routeColor),
                            RenderTransformOrigin = new Point(0.5, 0.5),
                            RenderTransform = new RotateTransform(arrowAngle),
                            IsHitTestVisible = false,
                            Tag = "ROUTE_ARROW"
                        };

                        GMapMarker arrowMarker = new GMapMarker(midP1) { Shape = arrowVis, Offset = new Point(-8, -10), ZIndex = 499 };
                        MainMap.Markers.Add(arrowMarker);
                        // 🌟 箭头装配完毕

                        TxtRadioLog.Text += $"\n🔗 [战报]: 指挥官 {cmd.Sender} 耗资 ¥{routeCost:N0}，打通了 {srcName} ⇌ {destName} 的黄金航线！";
                    }
                });
            }
            else if (cmd.ActionType == "UPGRADE_BASE")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    var targetAirport = allAirportsList.FirstOrDefault(a => a.Name == cmd.TargetId);
                    if (targetAirport != null && targetAirport.Level < 3)
                    {
                        // 1. 动态计算真实造价 (1升2要1.5亿，2升3要5亿)
                        long upgradeCost = targetAirport.Level == 1 ? 150000000 : 500000000;

                        playerFunds -= upgradeCost;
                        TxtFunds.Text = $"💰 资金: {playerFunds:N0}";
                        if (playerFunds < 0) TxtFunds.Foreground = Brushes.Red;

                        // ==========================================
                        // 🌟 致命修复：真实物理容量翻倍！不再是豆腐渣！
                        // ==========================================
                        targetAirport.Level += 1;
                        targetAirport.MaxCapacity *= 3; // ← 就是漏了这句救命的代码！！！

                        TxtRadioLog.Text += $"\n🏗️ [战报]: 指挥官 {cmd.Sender} 豪掷 ¥{upgradeCost / 100000000.0}亿，将 {targetAirport.Name} 扩建至 Lv.{targetAirport.Level} (容量暴增至 {targetAirport.MaxCapacity})！";

                        if (currentSelectedMarker != null && ((currentSelectedMarker.Shape as FrameworkElement).Tag as GameAirportInfo)?.Name == targetAirport.Name)
                        {
                            RefreshPanelUI(targetAirport);
                        }
                    }
                });
            }
            else if (cmd.ActionType == "CHANGE_SPEED")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    // 解析传过来的速度倍率
                    double speedMode = 1.0;
                    double.TryParse(cmd.TargetId, out speedMode);

                    // 恢复所有按钮的默认底色
                    if (BtnSpeedSlow != null) BtnSpeedSlow.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#444455"));
                    if (BtnSpeedNormal != null) BtnSpeedNormal.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#444455"));
                    if (BtnSpeedFast != null) BtnSpeedFast.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#444455"));

                    // 🌟 核心：通过调整 Timer 的 Interval，从物理底层改变世界流速！
                    // 假设默认：天数跳动(gameTimer)为 1000 毫秒，动画刷新(animationTimer)为 50 毫秒
                    if (speedMode == 0.5)
                    {
                        if (gameTimer != null) gameTimer.Interval = TimeSpan.FromMilliseconds(2000); // 2秒过1天
                        if (animationTimer != null) animationTimer.Interval = TimeSpan.FromMilliseconds(100);
                        if (BtnSpeedSlow != null) BtnSpeedSlow.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF8C00")); // 亮起橙色
                        TxtRadioLog.Text += $"\n🐢 [战报]: 指挥官 {cmd.Sender} 启动了时间缓速场 (0.5x)！";
                    }
                    else if (speedMode == 2.0)
                    {
                        // 🌟 1. 游戏主时间轴：拉到物理极限
                        if (gameTimer != null)
                            gameTimer.Interval = TimeSpan.FromMilliseconds(1000);

                        // 🌟 2. 飞行物理引擎：必须同步拉到极限！绝不能让飞机堵在天上！
                        if (animationTimer != null)
                            animationTimer.Interval = TimeSpan.FromMilliseconds(1);

                        if (BtnSpeedFast != null)
                            BtnSpeedFast.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF8C00"));

                        // 🌟 3. 日志打印加个限制，免得无头模式下它乱刷
                        if (!isFastTrainingMode)
                        {
                            TxtRadioLog.Text += $"\n⏩ [战报]: 开启【AI 暴走加速】，时空引擎与飞行引擎已全部超载至极限！";
                        }
                    }
                    else
                    {
                        if (gameTimer != null) gameTimer.Interval = TimeSpan.FromMilliseconds(1000); // 1秒过1天
                        if (animationTimer != null) animationTimer.Interval = TimeSpan.FromMilliseconds(50);
                        if (BtnSpeedNormal != null) BtnSpeedNormal.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC")); // 亮起蓝色
                        TxtRadioLog.Text += $"\n▶️ [战报]: 指挥官 {cmd.Sender} 将时间流速重置为标准频率 (1.0x)。";
                    }
                });
            }
        }
    }
}
