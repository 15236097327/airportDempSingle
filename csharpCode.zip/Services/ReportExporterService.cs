﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightDispatchClient.Services
{
    public static class ReportExporterService
    {
    }
}
