﻿using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlightDispatchClient
{
    public class ActiveFlight
    {
        public GMapMarker Marker { get; set; }       // 地图上的飞机图标
        public GMapMarker StartNode { get; set; }    // 起飞机场
        public GMapMarker EndNode { get; set; }      // 降落机场
        public double Progress { get; set; }         // 飞行进度 (0.0 到 1.0)
        public double Speed { get; set; }            // 飞行速度
        public int Passengers { get; set; }          // 搭载旅客
        public long ExpectedProfit { get; set; }     // 机票预期收益
        public string FlightCode { get; set; }       // 航班号
        public GamePlaneInfo PhysicalPlane { get; set; }
        public List<GMapMarker> Waypoints { get; set; }
        public int CurrentWaypointIndex { get; set; }
    }
}
