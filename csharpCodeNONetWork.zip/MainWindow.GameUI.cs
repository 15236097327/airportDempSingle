﻿using GMap.NET;
using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace FlightDispatchClient
{
    /*LoadDataBtn_Click (载入地图数据 & 开始游戏分发器)

BtnReady_Click (点击准备)

PauseGameBtn_Click (战术暂停)

RedDot_MouseLeftButtonDown (点击机场红点)

DrawRouteBtn_Click (点击开通航线)

MainMap_MouseMove (拉伸橡皮筋连线)

CompleteRoute (完成航线建设)

UpgradeAirportBtn_Click (升级机场)

BuyLocalPlaneBtn_Click (买飞机)

Flight_MouseLeftButtonDown (点击飞行中的飞机)

UrgentAirportsList_SelectionChanged (点击左侧的高危警报列表)

RefreshPanelUI (刷新机场信息 UI 界面)

TriggerGameOver (核弹洗地：触发结算面板，极其重要！)

RestartGameBtn_Click (重新开始游戏)*/
    public partial class MainWindow:Window
    {
        // 把原来的 GMapMarker 全删掉，换成这几个：
        private GameAirportInfo currentSelectedAirport = null;
        private GameAirportInfo routeStartAirport = null;
       private System.Windows.Shapes.Line elasticLine = null; // 拉线用的橡皮筋
        private TextBlock costPreviewText = null; // 鼠标上的文字提示框
        private async void LoadDataBtn_Click(object sender, RoutedEventArgs e)
        {
            activeEvents.Clear();

            // === 【状态分发器：游戏已加载数据，且未 Game Over】 ===
            if (allAirportsList.Count > 0 && !isGameOver)
            {
                if (!isGameStarted)
                {
                    if (sender != null && currentGameMode == "COOP")
                    {
                        MessageBox.Show("📡 联机指挥协议已锁定！请等待双方准备完毕。", "防抢跑系统拦截", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                    isGameStarted = true;
                    // LockGameModeUI(true); // 如果你有这个方法就取消注释
                    gameTimer.Start();
                    animationTimer.Start();
                    LoadDataBtn.Content = "🛑 结束游戏 (主动结算)";
                    LoadDataBtn.Background = Brushes.Crimson;
                    return;
                }
                else
                {
                    // 游戏运行中，主动点击结算
                    bool wasPausedBeforeConfirm = isPaused;
                    gameTimer.Stop(); animationTimer.Stop();

                    MessageBoxResult result = MessageBox.Show("确定要结束调度并盘点资产吗？", "🛑 营运结算确认", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                    if (result == MessageBoxResult.Yes)
                    {
                        // LockGameModeUI(false); 
                        string finalStatePayload = $"{playerFunds}|{totalTransportedPax}";

                        if (webSocket != null && webSocket.State == WebSocketState.Open)
                            _ = SendCommandAsync("SYNC_GAME_OVER", "", finalStatePayload);

                        TriggerGameOver(null);
                    }
                    else if (!wasPausedBeforeConfirm)
                    {
                        gameTimer.Start(); animationTimer.Start();
                    }
                    return;
                }
            }

            // === 【初始化逻辑：加载世界数据】 ===
            // LockGameModeUI(false); 
            if (gameTimer != null) gameTimer.Stop();
            if (animationTimer != null) animationTimer.Stop();

            isGameOver = false; isPaused = false; isGameStarted = false;
            if (PauseGameBtn != null)
            {
                PauseGameBtn.Visibility = Visibility.Visible;
                PauseGameBtn.Content = "⏸️ 战术暂停";
                PauseGameBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF8C00"));
            }

            gameTickCount = 0; gameVirtualTime = new DateTime(2026, 1, 1, 6, 0, 0);
            playerFunds = 10000000000; totalTransportedPax = 0;
            GameOverOverlay.Visibility = Visibility.Collapsed;

            TxtFunds.Text = $"💰 资金: {playerFunds:N0}";
            TxtFunds.Foreground = Brushes.Gold;

            // 🌟 物理清理图纸
            currentSelectedAirport = null;
            AirportInfoPanel.Visibility = Visibility.Collapsed;
            isDrawingRoute = false; routeStartAirport = null;

            MainBlueprint.Children.Clear(); // 彻底清空画板
            flyingPlanes.Clear(); activeRoutes.Clear(); allAirportsList.Clear();
            UrgentAirportsList.ItemsSource = null;

            LoadDataBtn.Content = "🌐 重新构建世界中...";

            try
            {
                // 🌟 纯净的数据读取逻辑：只读数据，不再画任何 GMapMarker！
                string filePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "airports.json");
                string responseBody = System.IO.File.ReadAllText(filePath);
                using (JsonDocument doc = JsonDocument.Parse(responseBody))
                {
                    JsonElement dataArray = doc.RootElement.GetProperty("data");
                    foreach (JsonElement ap in dataArray.EnumerateArray())
                    {
                        int pax = ap.GetProperty("daily_pax_base").GetInt32();
                        int gameRate = Math.Max(2, pax / 96);
                        int dynamicCapacity = (int)(10000 + (int)(pax * 1.5)) / 10;

                        GameAirportInfo newApt = new GameAirportInfo
                        {
                            Name = ap.GetProperty("airport_name").GetString(),
                            Icao = ap.GetProperty("icao_code").GetString(),
                            Lat = ap.GetProperty("latitude").GetDouble(),   // 真实纬度
                            Lng = ap.GetProperty("longitude").GetDouble(),  // 真实经度
                            DailyPaxRate = gameRate,
                            MaxCapacity = dynamicCapacity,
                            InitialCapacity = dynamicCapacity,
                            Level = 1
                        };
                        allAirportsList.Add(newApt);
                    }
                }

                // 🌟 数据就绪，呼叫图纸引擎渲染机场光点！(前提是你已经加了我之前给你的 DrawAirportsOnBlueprint 方法)
                DrawAirportsOnBlueprint();

                LoadDataBtn.Content = "▶️ 开始调度 (Start Game)";
                LoadDataBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2E8B57"));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"构建世界失败！\n\n{ex.Message}", "情报处最高警告", MessageBoxButton.OK, MessageBoxImage.Error);
                LoadDataBtn.Content = "🌐 载入世界失败 (重试)";
            }
        }

        private async void BtnReady_Click(object sender, RoutedEventArgs e)
        {
            if (allAirportsList == null || allAirportsList.Count == 0) return;
            await SendCommandAsync("READY");
            BtnReady.Content = "⏳ 已准备，等待队友..."; BtnReady.IsEnabled = false;
            LoadDataBtn.IsEnabled = false; LoadDataBtn.Content = "⏳ 等待同步发令...";
        }

        private async void PauseGameBtn_Click(object sender, RoutedEventArgs e)
        {
            if (webSocket != null && webSocket.State == WebSocketState.Open) await SendCommandAsync(isPaused ? "RESUME" : "PAUSE");
            else ExecuteSyncCommand(new GameSyncCommand { Sender = "本地指令", ActionType = isPaused ? "RESUME" : "PAUSE" });
        }

        // 🌟 点击机场红点 (注意参数和以前不同了，直接绑在 Ellipse 上)
        private void RedDot_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            if (isGameOver) return;

            // 获取我们绑在控件 Tag 上的机场数据
            if (sender is FrameworkElement element && element.Tag is GameAirportInfo info)
            {
                if (isDrawingRoute && routeStartAirport != null)
                {
                    CompleteRoute(routeStartAirport, info);
                    return;
                }

                currentSelectedAirport = info;
                RefreshPanelUI(info);
                AirportInfoPanel.Visibility = Visibility.Visible;
            }
        }

        private void DrawRouteBtn_Click(object sender, RoutedEventArgs e)
        {
            if (currentSelectedAirport == null) return;

            if (currentSelectedAirport.LocalFleet.Count <= 0)
            {
                MessageBox.Show("该机场没有驻扎飞机，无法开通航线！请先购买飞机。", "调度提醒");
                return;
            }

            isDrawingRoute = true;
            routeStartAirport = currentSelectedAirport;
            AirportInfoPanel.Visibility = Visibility.Collapsed;
        }

        // 🌟 鼠标在蓝图上移动 (拉出测距橡皮筋)
        private void MainBlueprint_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawingRoute && routeStartAirport != null)
            {
                Point mousePos = e.GetPosition(MainBlueprint);

                if (elasticLine == null)
                {
                    elasticLine = new System.Windows.Shapes.Line
                    {
                        Stroke = Brushes.Cyan,
                        StrokeThickness = 2,
                        StrokeDashArray = new DoubleCollection { 4, 2 },
                        IsHitTestVisible = false
                    };
                    MainBlueprint.Children.Add(elasticLine);
                }

                // 更新橡皮筋的位置
                elasticLine.X1 = routeStartAirport.ScreenX;
                elasticLine.Y1 = routeStartAirport.ScreenY;
                elasticLine.X2 = mousePos.X;
                elasticLine.Y2 = mousePos.Y;

                // 简单的屏幕像素距离换算为预估价格 (为了流畅，这里直接按像素比例估算)
                double pixelDist = Math.Sqrt(Math.Pow(mousePos.X - routeStartAirport.ScreenX, 2) + Math.Pow(mousePos.Y - routeStartAirport.ScreenY, 2));
                long previewCost = (long)(pixelDist * 500000); // 你可以调整这个系数

                if (costPreviewText == null)
                {
                    costPreviewText = new TextBlock
                    {
                        Background = new SolidColorBrush(Color.FromArgb(200, 10, 10, 20)),
                        Foreground = Brushes.Lime,
                        Padding = new Thickness(6),
                        FontWeight = FontWeights.Bold,
                        IsHitTestVisible = false
                    };
                    Canvas.SetZIndex(costPreviewText, 1005);
                    MainBlueprint.Children.Add(costPreviewText);
                }

                costPreviewText.Text = $"💰 预估建线费用: ¥ {previewCost:N0}";
                Canvas.SetLeft(costPreviewText, mousePos.X + 20);
                Canvas.SetTop(costPreviewText, mousePos.Y + 20);
            }
        }

        // 🌟 完成连线
        private async void CompleteRoute(GameAirportInfo startInfo, GameAirportInfo endInfo)
        {
            isDrawingRoute = false;
            if (elasticLine != null) { MainBlueprint.Children.Remove(elasticLine); elasticLine = null; }
            if (costPreviewText != null) { MainBlueprint.Children.Remove(costPreviewText); costPreviewText = null; }

            if (startInfo == endInfo) return;

            bool routeExists = activeRoutes.Any(r => r.StartAirport == startInfo && r.EndAirport == endInfo);
            if (routeExists)
            {
                MessageBox.Show($"【{startInfo.Name}】飞往【{endInfo.Name}】的航线已存在！", "重复建设拦截");
                return;
            }

            double dist = CalculateDistance(startInfo.Lat, startInfo.Lng, endInfo.Lat, endInfo.Lng);
            long routeCost = (long)(dist * 5000);
            if (playerFunds < routeCost)
            {
                MessageBox.Show($"余额不足！开通此航线需要 ¥{routeCost:N0}", "财务警报");
                return;
            }

            if (webSocket != null && webSocket.State == WebSocketState.Open) await SendCommandAsync("OPEN_ROUTE", startInfo.Name, endInfo.Name);
            else ExecuteSyncCommand(new GameSyncCommand { Sender = "本地指令", ActionType = "OPEN_ROUTE", TargetId = startInfo.Name, AdditionalData = endInfo.Name });
        }

        private async void UpgradeAirportBtn_Click(object sender, RoutedEventArgs e)
        {
            if (currentSelectedAirport == null) return;
            if (currentSelectedAirport.Level >= 3) return;

            long upgradeCost = currentSelectedAirport.Level == 1 ? 15000000 : 50000000;
            if (playerFunds >= upgradeCost)
            {
                if (webSocket != null && webSocket.State == WebSocketState.Open) await SendCommandAsync("UPGRADE_BASE", currentSelectedAirport.Name);
                else ExecuteSyncCommand(new GameSyncCommand { ActionType = "UPGRADE_BASE", Sender = TxtPlayerName.Text, TargetId = currentSelectedAirport.Name });
            }
            else
            {
                MessageBox.Show($"资金不足！扩建需要 ¥{upgradeCost / 100000000.0} 亿。", "财务警告", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private async void BuyLocalPlaneBtn_Click(object sender, RoutedEventArgs e)
        {
            if (currentSelectedAirport == null) return;
            long planeCost = 150000000;
            if (playerFunds >= planeCost)
            {
                if (webSocket != null && webSocket.State == WebSocketState.Open) await SendCommandAsync("BUY_PLANE", currentSelectedAirport.Icao);
                else ExecuteSyncCommand(new GameSyncCommand { Sender = "单机指令", ActionType = "BUY_PLANE", TargetId = currentSelectedAirport.Icao });
            }
            else MessageBox.Show($"资金不足！购买一架飞机需要 ¥{planeCost:N0}", "财务警报");
        }

        // 🌟 点击空中的航班查看详细情报
        private void Flight_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            if (sender is FrameworkElement element && element.Tag is ActiveFlight flight)
            {
                MessageBox.Show(
                    $"✈ 实时航班雷达: {flight.FlightCode}\n" +
                    $"------------------------------------\n" +
                    $"🛫 始发: {flight.StartAirport.Name}\n" +
                    $"🛬 目标: {flight.EndAirport.Name}\n\n" +
                    $"👥 旅客: {flight.Passengers:N0} 人\n" +
                    $"💰 预期收益: ¥ {flight.ExpectedProfit:N0}\n" +
                    $"📍 完成度: {(flight.Progress * 100):F1} %",
                    "空中管制 (ATC)", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void UrgentAirportsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (UrgentAirportsList.SelectedItem is GameAirportInfo selectedInfo)
            {
                currentSelectedAirport = selectedInfo;
                RefreshPanelUI(selectedInfo);
                AirportInfoPanel.Visibility = Visibility.Visible;
                UrgentAirportsList.SelectedItem = null;
            }
        }
        // ==========================================
        // 🌟 核心情报面板：动态渲染指挥中心 UI
        // ==========================================
        private void RefreshPanelUI(GameAirportInfo info)
        {
            if (info == null) return;

            // ------------------------------------------
            // 1. 基础情报与运力负荷
            // ------------------------------------------
            TxtAirportName.Text = $"📍 {info.Name} ({info.Icao})";
            TxtAirportLevel.Text = $"⭐ 等级: Lv.{info.Level} (容量: {info.MaxCapacity:N0})";
            TxtAirportPax.Text = $"👥 当前滞留: {info.CurrentPassengers:N0} 人";

            // ------------------------------------------
            // 2. 雷达侦听排队情况 (只显示前 3 个最火爆的目的地)
            // ------------------------------------------
            if (info.Demands == null) info.Demands = new Dictionary<string, int>(); // 防空指针护盾
            var topDemands = info.Demands.OrderByDescending(kv => kv.Value).Take(3).ToList();

            if (topDemands.Count == 0)
            {
                TxtDestinations.Text = "📡 雷达侦听: 暂无旅客排队";
            }
            else
            {
                TxtDestinations.Text = "📡 高频目的地排队情报:\n";
                foreach (var demand in topDemands)
                {
                    TxtDestinations.Text += $"   🚩 去 {demand.Key} : {demand.Value:N0} 人\n";
                }
            }

            // ------------------------------------------
            // 3. 基建工程部：动态渲染机场扩建按钮
            // ------------------------------------------
            if (UpgradeAirportBtn != null)
            {
                if (info.Level >= 3)
                {
                    UpgradeAirportBtn.Content = "⭐ 机场已达满级 (Lv.3)";
                    UpgradeAirportBtn.IsEnabled = false; // 满级变灰不可点
                    UpgradeAirportBtn.Background = Brushes.Gray;
                }
                else
                {
                    // 动态计算下一级的价格显示在按钮上
                    long nextCost = info.Level == 1 ? 15000000 : 50000000;
                    UpgradeAirportBtn.Content = $"⬆️ 扩建至 Lv.{info.Level + 1} (¥ {nextCost / 100000000.0} 亿)";
                    UpgradeAirportBtn.IsEnabled = true;
                    UpgradeAirportBtn.Background = Brushes.DarkGoldenrod; // 恢复土豪金
                }
            }

            // ------------------------------------------
            // 4. 停机坪：机队跨代改装系统
            // ------------------------------------------
            if (FleetContainer != null)
            {
                FleetContainer.Children.Clear(); // 刷新前清空旧卡片

                if (info.LocalFleet.Count == 0)
                {
                    FleetContainer.Children.Add(new TextBlock { Text = "   暂无驻扎飞机，运力停摆！", Foreground = Brushes.Gray, FontStyle = FontStyles.Italic });
                }
                else
                {
                    foreach (var plane in info.LocalFleet)
                    {
                        Button planeBtn = new Button
                        {
                            Background = new SolidColorBrush(Color.FromArgb(255, 30, 30, 40)),
                            Foreground = Brushes.White,
                            Margin = new Thickness(0, 2, 0, 4),
                            Padding = new Thickness(8, 5, 8, 5),
                            Cursor = Cursors.Hand,
                            HorizontalContentAlignment = HorizontalAlignment.Left
                        };

                        // 动态读取真实机型名称和容量
                        string btnText = $"✈ {plane.Id} | {plane.ModelName} (运力: {plane.Capacity}人)\n";

                        if (plane.IsMaxLevel)
                        {
                            btnText += $"   👑 已达满级科技 (终极超音速客机)";
                        }
                        else
                        {
                            // 预判下一代的科技属性
                            PlaneModelType nextModel = plane.Model == PlaneModelType.Regional ? PlaneModelType.Widebody : PlaneModelType.Supersonic;
                            GamePlaneInfo previewNext = new GamePlaneInfo { Model = nextModel };

                            btnText += $"   ✨ 改装 [{previewNext.ModelName}] (需跑道Lv.{previewNext.RequiredAirportLevel}) | 需 ¥{plane.UpgradeCost / 100000000.0}亿";
                        }
                        planeBtn.Content = btnText;

                        // 挂载改装扣钱与逻辑校验模块 (完全纯本地运算)
                        if (!plane.IsMaxLevel)
                        {
                            planeBtn.Click += (s, e) =>
                            {
                                PlaneModelType targetModel = plane.Model == PlaneModelType.Regional ? PlaneModelType.Widebody : PlaneModelType.Supersonic;
                                GamePlaneInfo previewPlane = new GamePlaneInfo { Model = targetModel };

                                // 🚨 塔台硬核拦截：跑道等级不足！
                                if (info.Level < previewPlane.RequiredAirportLevel)
                                {
                                    MessageBox.Show($"跑道长度不足！\n\n起降【{previewPlane.ModelName}】需要当前机场达到 Lv.{previewPlane.RequiredAirportLevel}。\n请先执行机场扩建工程！", "塔台警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                                    return;
                                }

                                // 🚨 财务硬核拦截：经费不足
                                if (playerFunds >= plane.UpgradeCost)
                                {
                                    // 拨付经费并执行物理改装
                                    playerFunds -= plane.UpgradeCost;
                                    plane.Model = targetModel; // 🌟 核心：切换物理机型！
                                    plane.Level++;

                                    TxtFunds.Text = $"💰 资金: {playerFunds:N0}";
                                    RefreshPanelUI(info); // 🌟 改装完毕，自己调用自己，瞬间刷新面板！
                                }
                                else
                                {
                                    MessageBox.Show($"经费严重不足！\n机队改装需要拨款 ¥{plane.UpgradeCost / 100000000.0} 亿！", "财务警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                                }
                            };
                        }

                        FleetContainer.Children.Add(planeBtn);
                    }
                }
            }
        }
        private void TriggerGameOver(GameAirportInfo crashedAirport)
        {
            isGameOver = true;
            if (gameTimer != null) gameTimer.Stop();
            if (animationTimer != null) animationTimer.Stop();

            long totalProfit = 0; long totalStranded = 0; int totalFleet = 0;
            int survivedDays = (gameVirtualTime - new DateTime(2026, 1, 1)).Days;

            foreach (var info in allAirportsList)
            {
                totalProfit += info.Profit;
                totalStranded += info.CurrentPassengers;
                totalFleet += info.LocalFleet.Count;
            }

            TxtFinalDays.Text = $"🏆 存活时间: {survivedDays} 天";
            TxtFinalPax.Text = $"👥 累计运送: {totalTransportedPax:N0} 人次";
            TxtFinalFunds.Text = $"💰 最终结余: ¥ {playerFunds:N0}";
            GameOverOverlay.Visibility = Visibility.Visible;
            LoadDataBtn.Content = "🔄 开启下一局 (Restart)";
            LoadDataBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));
        }

        private void RestartGameBtn_Click(object sender, RoutedEventArgs e)
        {
            activeEvents.Clear();
            LoadDataBtn_Click(null, null);
        }

        // 🌟 右键打断连线操作
        private void MainBlueprint_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (isDrawingRoute)
            {
                isDrawingRoute = false;
                if (elasticLine != null) { MainBlueprint.Children.Remove(elasticLine); elasticLine = null; }
                if (costPreviewText != null) { MainBlueprint.Children.Remove(costPreviewText); costPreviewText = null; }
                routeStartAirport = null;
                MainBlueprint.Cursor = Cursors.Arrow;
                e.Handled = true;
            }
        }

    }
}
