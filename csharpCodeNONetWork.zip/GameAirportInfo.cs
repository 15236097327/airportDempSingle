﻿using System;
using System.Collections.Generic;
using System.Text;
using static FlightDispatchClient.MainWindow;

namespace FlightDispatchClient
{
    public class GameAirportInfo
    {
        public string Name { get; set; }
        public string Icao { get; set; }
        public int DailyPaxRate { get; set; }
        public int MaxCapacity { get; set; }
        public int Level { get; set; } = 1;
        public long Profit { get; set; } = 0;
        public int CurrentPassengers { get; set; } = 0;
        public Dictionary<string, int> Demands { get; set; } = new Dictionary<string, int>();
        public List<GamePlaneInfo> LocalFleet { get; set; } = new List<GamePlaneInfo>();

        public string EventIcon { get; set; } = "";
        public int InitialCapacity { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }

        // 🌟 补上真实经纬度 (如果原来叫 Latitude/Longitude，请改成 Lat/Lng 或者调整代码里的调用)
        public double Lat { get; set; }
        public double Lng { get; set; }

        // 🌟 补上纯净版图纸专用的屏幕坐标
        public double ScreenX { get; set; }
        public double ScreenY { get; set; }
    }
}
