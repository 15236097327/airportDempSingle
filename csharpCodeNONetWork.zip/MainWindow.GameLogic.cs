﻿using GMap.NET;
using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace FlightDispatchClient
{
    public partial class MainWindow : Window
    {
        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (isGameOver) return;
            // if (isWaitingForAI) return; // 如果已经没有 AI 逻辑了，这行可以删掉
            gameTickCount++;

            if (allAirportsList.Count > 0)
            {
                // ==========================================
                // 🌪️ 1. 全局事件结算
                // ==========================================
                for (int i = activeEvents.Count - 1; i >= 0; i--)
                {
                    var ev = activeEvents[i];
                    if (ev.WarningTicks > 0)
                    {
                        ev.WarningTicks--;
                    }
                    else
                    {
                        ev.RemainingTicks--;
                        if (ev.RemainingTicks <= 0)
                        {
                            string endMsg = ev.Type == EventType.EconomicBoom ? "📉 [全球快讯]: 盛会落幕。" : "🌤️ [气象局]: 警报解除。";
                            if (gameTickCount % 50 == 0)
                            {
                                TxtRadioLog.Text += $"\n{endMsg} ({ev.TargetAirportName})";
                                if (TxtRadioLog.Parent is ScrollViewer svLog) svLog.ScrollToBottom();
                            }
                            activeEvents.RemoveAt(i);
                        }
                    }
                }

                if (gameTickCount % 10 == 0 && randomEngine.Next(1000) < 2 && activeEvents.Count < 3)
                {
                    var targetAp = allAirportsList[randomEngine.Next(allAirportsList.Count)];
                    if (!activeEvents.Any(ev => ev.TargetAirportName == targetAp.Name))
                    {
                        bool isBoom = randomEngine.Next(100) < 50;
                        GlobalEvent newEvent = new GlobalEvent
                        {
                            Type = isBoom ? EventType.EconomicBoom : EventType.SevereWeather,
                            TargetAirportName = targetAp.Name,
                            WarningTicks = 20,
                            RemainingTicks = randomEngine.Next(30, 80)
                        };
                        activeEvents.Add(newEvent);

                        string broadcast = isBoom ? $"📢 [商业情报]: {targetAp.Name} 即将举办博览会！" : $"⚠️ [气象预警]: 超级雷暴正向 {targetAp.Name} 移动！";
                        if (gameTickCount % 50 == 0)
                        {
                            TxtRadioLog.Text += $"\n{broadcast}";
                            if (TxtRadioLog.Parent is ScrollViewer svLog) svLog.ScrollToBottom();
                        }
                    }
                }
            }

            // ==========================================
            // ⏱️ 2. 时间推进与潮汐计算
            // ==========================================
            gameVirtualTime = gameVirtualTime.AddMinutes(15);
            int survivedDays = (gameVirtualTime - new DateTime(2026, 1, 1)).Days;
            this.Title = $"✈ 航空大亨指挥中心 | 当前时间: {gameVirtualTime:yyyy年MM月dd日 HH:mm} | 🏆 存活: {survivedDays} 天";

            double timeMultiplier = 1.0 + 0.8 * Math.Sin((gameVirtualTime.Hour - 8) / 24.0 * Math.PI * 2);

            // ==========================================
            // 🧮 3. 核心物理结算 (纯内存计算，不碰 UI)
            // ==========================================
            foreach (var info in allAirportsList)
            {
                double randomFactor = 0.8 + (randomEngine.NextDouble() * 0.4);
                int actualArrivals = (int)((info.DailyPaxRate) * timeMultiplier * randomFactor) / 10;

                if (gameTickCount < 20) actualArrivals = (int)(actualArrivals * 0.2);
                if (activeEvents.Any(ev => ev.TargetAirportName == info.Name && ev.Type == EventType.EconomicBoom && ev.IsActive)) actualArrivals *= 2;

                if (actualArrivals > 0)
                {
                    int totalWeight = allAirportsList.Sum(a => a.DailyPaxRate);
                    int randValue = randomEngine.Next(totalWeight);
                    GameAirportInfo destInfo = allAirportsList.Last();

                    foreach (var candidate in allAirportsList)
                    {
                        randValue -= candidate.DailyPaxRate;
                        if (randValue <= 0) { destInfo = candidate; break; }
                    }

                    if (destInfo.Name == info.Name) destInfo = allAirportsList.OrderByDescending(a => a.DailyPaxRate).First(a => a.Name != info.Name);
                    if (!info.Demands.ContainsKey(destInfo.Name)) info.Demands[destInfo.Name] = 0;

                    info.Demands[destInfo.Name] += actualArrivals;
                    info.CurrentPassengers += actualArrivals;
                }

                // 🚨 终极死神拦截！
                if (info.CurrentPassengers >= info.MaxCapacity)
                {
                    if (currentGameMode == "COOP")
                    {
                        string finalPayload = $"{playerFunds}|{totalTransportedPax}|{gameVirtualTime.Ticks}";
                        _ = SendCommandAsync("SYNC_AUTO_GAME_OVER", info.Name, finalPayload);
                    }
                    TriggerGameOver(info);
                    return; // 只要爆仓，直接终止这一秒！
                }
            }
            // ==========================================
            // 🚀 核心逻辑：天网航班全自动发车员
            // ==========================================
            foreach (var startApt in allAirportsList)
            {
                if (startApt.LocalFleet.Count <= 0) continue;

                // 🌟 核心防坑：通过 Name 去匹配航线，防止重连后对象引用变了导致找不着！
                var myRoutes = activeRoutes.Where(r => r.StartAirport.Name == startApt.Name).ToList();

                while (startApt.LocalFleet.Count > 0)
                {
                    bool launchedAny = false;
                    foreach (var route in myRoutes)
                    {
                        var destApt = route.EndAirport;
                        int currentDemand = 0;

                        // 🌟 只要排队去这个目的地的人 >= 50，立刻起飞！
                        if (startApt.Demands.TryGetValue(destApt.Name, out currentDemand) && currentDemand >= 50)
                        {
                            var planeToUse = startApt.LocalFleet[0];
                            startApt.LocalFleet.RemoveAt(0);

                            // 发射物理飞机！
                            LaunchPlanePhysics(startApt, destApt, planeToUse);
                            launchedAny = true;
                            break;
                        }
                    }
                    if (!launchedAny) break; // 如果扫了一圈都不够50人，就不飞了
                }
            }

            // ==========================================
            // 🎨 纯 UI 渲染：强制刷新机场颜色 (红/橙/绿)
            // ==========================================
            foreach (UIElement element in MainBlueprint.Children)
            {
                // 精准抓取我们画的小圆点
                if (element is System.Windows.Shapes.Ellipse dot && dot.Tag is GameAirportInfo infoDot)
                {
                    // 重新计算危急度 (保证使用浮点除法！)
                    double dangerRatio = (double)infoDot.CurrentPassengers / (double)infoDot.MaxCapacity;

                    if (dangerRatio < 0.5) dot.Fill = Brushes.MediumSeaGreen; // 安全：绿色
                    else if (dangerRatio < 0.8) dot.Fill = Brushes.DarkOrange; // 拥挤：橙色
                    else dot.Fill = Brushes.Crimson; // 爆仓：血红色
                }
            }
            // ==========================================
            // 🎨 4. 纯 UI 渲染层 (刷新右侧、左侧、顶部资金)
            // ==========================================
            long tickTotalProfit = 0; // 如果你有自动赚钱逻辑，在这里加

            if (tickTotalProfit > 0)
            {
                TxtFunds.Text = $"💰 资金: {playerFunds:N0} (+{tickTotalProfit:N0})";
                TxtFunds.Foreground = Brushes.LimeGreen;
            }
            else
            {
                TxtFunds.Text = $"💰 资金: {playerFunds:N0}";
                TxtFunds.Foreground = Brushes.Gold;
            }

            if (currentSelectedAirport != null && AirportInfoPanel.Visibility == Visibility.Visible)
            {
                RefreshPanelUI(currentSelectedAirport);
            }

            // 分配事件图标
            foreach (var ap in allAirportsList) ap.EventIcon = "";
            foreach (var ev in activeEvents)
            {
                var affectedAirport = allAirportsList.FirstOrDefault(a => a.Name == ev.TargetAirportName);
                if (affectedAirport != null)
                {
                    if (!ev.IsActive) affectedAirport.EventIcon = ev.Type == EventType.EconomicBoom ? $"⏳即将暴富({ev.WarningTicks})" : $"⚠️台风逼近({ev.WarningTicks})";
                    else affectedAirport.EventIcon = ev.Type == EventType.EconomicBoom ? $"💰金币狂欢({ev.RemainingTicks})" : $"⛈️雷暴肆虐({ev.RemainingTicks})";
                }
            }

            // 刷新左侧危险警报列表
            var urgentList = allAirportsList.OrderByDescending(a => (double)a.CurrentPassengers / a.MaxCapacity).ToList();
            UrgentAirportsList.ItemsSource = null;
            UrgentAirportsList.ItemsSource = urgentList;
            // ==========================================
            // 🚀 核心逻辑：航班发车员 (Dispatcher)
            // ==========================================
            foreach (var startApt in allAirportsList)
            {
                // 1. 检查这个机场有没有闲置飞机
                if (startApt.LocalFleet.Count <= 0) continue;

                // 2. 检查这个机场开通了哪些目的地
                // 找出所有以该机场为起点的已开通航线
                var myRoutes = activeRoutes.Where(r => r.StartAirport == startApt).ToList();

                foreach (var route in myRoutes)
                {
                    var destApt = route.EndAirport;

                    // 3. 检查是否有足够旅客 (比如满 50 人才飞一架，或者只要有人就飞)
                    int currentDemand = 0;
                    if (startApt.Demands.TryGetValue(destApt.Name, out currentDemand) && currentDemand >= 50)
                    {

                        // 4. 如果条件全满足，立刻从机库拉出一架飞机起飞！
                        var planeToUse = startApt.LocalFleet[0];
                        startApt.LocalFleet.RemoveAt(0);

                        // 🌟 执行起飞逻辑 (这里复用我们之前的起飞 UI 生成逻辑)
                        LaunchPlanePhysics(startApt, destApt, planeToUse);

                        // 如果一架飞机飞走了，就检查下一架，或者跳出处理下一个机场
                        break;
                    }
                }
            }
            // ==========================================
            // 🌟 5. 渲染图纸颜色 (直接遍历 Canvas 里的控件)
            // ==========================================
           
        }

        // ==========================================
        // 🚀 核心物理：发射单架航班 (封装版)
        // ==========================================
        private void LaunchPlanePhysics(GameAirportInfo startApt, GameAirportInfo endApt, GamePlaneInfo plane)
        {
            // 1. 安检登机：计算这架飞机能拉走多少人
            int paxToMove = Math.Min(plane.Capacity, startApt.CurrentPassengers);

            // 扣除候机楼里的旅客
            startApt.CurrentPassengers -= paxToMove;
            if (startApt.CurrentPassengers < 0) startApt.CurrentPassengers = 0;

            // 同时扣除排队需求里的数字（让排队队列也变短）
            if (startApt.Demands.ContainsKey(endApt.Name))
            {
                startApt.Demands[endApt.Name] -= paxToMove;
                if (startApt.Demands[endApt.Name] < 0) startApt.Demands[endApt.Name] = 0;
            }

            // 2. 财务审计：算算这趟能赚多少钱
            double distance = CalculateDistance(startApt.Lat, startApt.Lng, endApt.Lat, endApt.Lng);
            long ticketRevenue = (long)(paxToMove * distance * 1.5);
            long fuelCost = (long)(distance * plane.FuelCostPerKm);
            long expectedProfit = ticketRevenue - fuelCost;

            // ==========================================
            // 🌟 3. 图纸渲染：画出小飞机
            // ==========================================
            // 计算机头偏转角度
            // ✅ 正确代码：endY - startY 顺应 WPF 屏幕坐标系
            double angle = Math.Atan2(endApt.ScreenY - startApt.ScreenY, endApt.ScreenX - startApt.ScreenX) * 180 / Math.PI + 45;

            TextBlock planeVis = new TextBlock
            {
                Text = "✈",
                FontSize = 20 + (plane.Level * 4), // 飞机越高级，图标越大
                Foreground = expectedProfit < 0 ? Brushes.Red : Brushes.White, // 亏本航班标红！
                RenderTransformOrigin = new Point(0.5, 0.5),
                RenderTransform = new RotateTransform(angle),
                Cursor = Cursors.Hand
            };

            // 放置在起飞机场的位置
            Canvas.SetLeft(planeVis, startApt.ScreenX - 12);
            Canvas.SetTop(planeVis, startApt.ScreenY - 12);
            Canvas.SetZIndex(planeVis, 1000); // 保证飞机在图纸的最上层，不被航线挡住

            MainBlueprint.Children.Add(planeVis);

            // ==========================================
            // ⚙️ 4. 物理引擎入库
            // ==========================================
            // 计算飞行速度（距离越远，每帧推移的 progress 越小）
            double speed = (40.0 * plane.SpeedMultiplier) / distance;

            ActiveFlight newFlight = new ActiveFlight
            {
                PlaneElement = planeVis,
                StartAirport = startApt,
                EndAirport = endApt,
                Progress = 0,
                Speed = speed,
                Passengers = paxToMove,
                ExpectedProfit = expectedProfit,
                PhysicalPlane = plane,
                FlightCode = plane.Id
            };

            // 绑定点击事件（点击空中的飞机能看航班信息）
            planeVis.Tag = newFlight;
            planeVis.MouseLeftButtonDown += Flight_MouseLeftButtonDown;

            // 加入全局飞行队列，交给 AnimationTimer_Tick 去移动它！
            flyingPlanes.Add(newFlight);

            // 🌟 刷新出发地机场的 UI 面板（实时看到人数减少）
            if (currentSelectedAirport != null && currentSelectedAirport.Name == startApt.Name)
            {
                RefreshPanelUI(startApt);
            }
        }
        private void AnimationTimer_Tick(object sender, EventArgs e)
        {
            if (isGameOver) return;
            if (flyingPlanes == null) return;

            for (int i = flyingPlanes.Count - 1; i >= 0; i--)
            {
                var flight = flyingPlanes[i];

                // ==========================================
                // 🌪️ 核心物理引擎：气象阻力判定
                // ==========================================
                double currentSpeed = flight.Speed;
                // var endInfo = (flight.EndNode.Shape as FrameworkElement)?.Tag as GameAirportInfo;
                var endInfo = flight.EndAirport;
                if (endInfo != null && activeEvents.Any(ev => ev.TargetAirportName == endInfo.Name && ev.Type == EventType.SevereWeather && ev.IsActive))
                {
                    currentSpeed *= 0.3; // 陷入泥潭，只剩 30% 龟速！
                }

                // 🚀 核心推进：就算看不见图标，物理进度依然在涨！
                flight.Progress += currentSpeed;
                // ==========================================
                if (flight.Progress >= 1.0)
                {
                    playerFunds += flight.ExpectedProfit;
                    totalTransportedPax += flight.Passengers;
                    if (flight.PhysicalPlane != null && flight.EndAirport != null) flight.EndAirport.LocalFleet.Add(flight.PhysicalPlane);

                    // 💥 护盾：从画布上抹除飞机图标！
                    if (flight.PlaneElement != null) MainBlueprint.Children.Remove(flight.PlaneElement);
                    flyingPlanes.RemoveAt(i);
                }
                else
                {
                    // 🌟 飞机在天上飞，计算屏幕贝塞尔曲线
                    if (flight.PlaneElement != null)
                    {
                        double startX = flight.StartAirport.ScreenX;
                        double startY = flight.StartAirport.ScreenY;
                        double endX = flight.EndAirport.ScreenX;
                        double endY = flight.EndAirport.ScreenY;

                        double midX = (startX + endX) / 2.0;
                        double midY = (startY + endY) / 2.0;
                        double dx = endX - startX;
                        double dy = endY - startY;

                        // 曲线弯曲度
                        double curvature = 0.2;
                        double ctrlX = midX - dy * curvature;
                        double ctrlY = midY + dx * curvature;

                        double t = flight.Progress;
                        double u = 1 - t;

                        // 计算当前帧的屏幕像素 X 和 Y
                        double curX = (u * u * startX) + (2 * u * t * ctrlX) + (t * t * endX);
                        double curY = (u * u * startY) + (2 * u * t * ctrlY) + (t * t * endY);

                        // 修改原生飞机图标的位置
                        Canvas.SetLeft(flight.PlaneElement, curX - 12);
                        Canvas.SetTop(flight.PlaneElement, curY - 12);
                    }
                }
            }
        }
      
        private async void BtnSpeedSlow_Click(object sender, RoutedEventArgs e)
        {
            if (!isGameStarted || isPaused) return;

            if (RdoSingle.IsChecked == true)
            {
                // 单机直连：直接扔给本地处理器
                var localCmd = new GameSyncCommand { ActionType = "CHANGE_SPEED", Sender = TxtPlayerName.Text, TargetId = "0.5" };
                ExecuteSyncCommand(localCmd);
            }
            else
            {
                // 联机广播：发射到云端
                await SendCommandAsync("CHANGE_SPEED", "0.5");
            }
        }

        // ==========================================
        // ⏱️ 时间控制器：1.0x 标准
        // ==========================================
        private async void BtnSpeedNormal_Click(object sender, RoutedEventArgs e)
        {
            if (!isGameStarted || isPaused) return;

            if (RdoSingle.IsChecked == true)
            {
                var localCmd = new GameSyncCommand { ActionType = "CHANGE_SPEED", Sender = TxtPlayerName.Text, TargetId = "1.0" };
                ExecuteSyncCommand(localCmd);
            }
            else
            {
                await SendCommandAsync("CHANGE_SPEED", "1.0");
            }
        }

        // ==========================================
        // ⏱️ 时间控制器：2.0x 曲率加速
        // ==========================================
        private async void BtnSpeedFast_Click(object sender, RoutedEventArgs e)
        {
            if (!isGameStarted || isPaused) return;

            if (RdoSingle.IsChecked == true)
            {
                var localCmd = new GameSyncCommand { ActionType = "CHANGE_SPEED", Sender = TxtPlayerName.Text, TargetId = "2.0" };
                ExecuteSyncCommand(localCmd);
            }
            else
            {
                await SendCommandAsync("CHANGE_SPEED", "2.0");
            }
        }
    }
}
