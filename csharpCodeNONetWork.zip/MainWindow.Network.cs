﻿using GMap.NET;
using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace FlightDispatchClient
{
    public partial class MainWindow : Window
    {
        private string currentRoomPassword = ""; // 🌟 存储当前口令
        private bool isPartnerDisconnected = false; // 记录逃兵状态
        private bool isUploadLocked = false;        // 防止重复上传锁
        
        public enum DispatchStrategy
        {
            Off,          // 关闭自动调度
            ProfitFirst,  // 利润至上 (哪条线赚得多飞哪条)
            RescueFirst,  // 紧急救援 (哪个机场快爆了飞哪个)
            Balanced      // 均衡模式
        }

        // 在 MainWindow 中记录当前策略
        private DispatchStrategy currentAIStrategy = DispatchStrategy.Off;
        private async void BtnJoinRoom_Click(object sender, RoutedEventArgs e)
        {
            currentRoomId = TxtRoomId.Text.Trim();
            currentRoomPassword = TxtRoomPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(currentRoomId))
            {
                MessageBox.Show("战区代码不能为空！", "警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 🌟 1. 冻结面板，等待云端宣判 (绝对不要在这里显示“已进驻”)
            BtnJoinRoom.Content = "📡 校验口令中...";
            BtnJoinRoom.Background = Brushes.DimGray;
            BtnJoinRoom.IsEnabled = false;
            TxtRoomId.IsEnabled = false;
            if (TxtRoomPassword != null) TxtRoomPassword.IsEnabled = false;

            try
            {
                if (webSocket == null || webSocket.State != WebSocketState.Open)
                {
                    webSocket = new System.Net.WebSockets.ClientWebSocket();
                    await webSocket.ConnectAsync(new Uri("ws://124.220.178.183:8084/game-room"), System.Threading.CancellationToken.None);
                    _ = Task.Run(ReceiveNetworkMessages);
                    if (heartbeatTimer != null) heartbeatTimer.Start();
                }

                // 🌟 2. 发射加入请求，然后耐心等待服务器的回音
                await SendCommandAsync("JOIN_ROOM");
            }
            catch (Exception ex)
            {
                MessageBox.Show("连接总部服务器失败，请检查网络！\n" + ex.Message, "失联", MessageBoxButton.OK, MessageBoxImage.Error);
                ReturnToMainMenu(); // 如果连不上，直接格式化恢复 UI
            }
        }

        private async Task SendCommandAsync(string action, string target = "", string additional = "")
        {
            if (webSocket != null && webSocket.State == WebSocketState.Open)
            {
                var cmd = new GameSyncCommand
                {
                    Sender = TxtPlayerName.Text,
                    ActionType = action,
                    TargetId = target,
                    AdditionalData = additional,
                    RoomId = currentRoomId,
                    RoomPassword = currentRoomPassword
                };

                var options = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
                string json = JsonSerializer.Serialize(cmd, options);
                var bytes = Encoding.UTF8.GetBytes(json);
                await webSocket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, System.Threading.CancellationToken.None);
            }
        }
        private async Task ReceiveNetworkMessages()
        {
            var buffer = new byte[1024 * 8]; // 基础缓冲池扩大到 8KB
            try
            {
                while (webSocket.State == WebSocketState.Open)
                {
                    // 🌟 核心升级：使用内存流，拼接超大号的快照包裹！
                    using (var ms = new System.IO.MemoryStream())
                    {
                        WebSocketReceiveResult result;
                        do
                        {
                            result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), System.Threading.CancellationToken.None);
                            if (result.MessageType == WebSocketMessageType.Close) break;

                            ms.Write(buffer, 0, result.Count); // 把收到的碎片拼起来
                        }
                        while (!result.EndOfMessage); // 如果包没传完，继续收！

                        if (result.MessageType == WebSocketMessageType.Close) break;

                        // 包裹接收完毕，解压成字符串
                        ms.Seek(0, System.IO.SeekOrigin.Begin);
                        using (var reader = new System.IO.StreamReader(ms, Encoding.UTF8))
                        {
                            string message = reader.ReadToEnd();
                            Dispatcher.Invoke(() =>
                            {
                                try
                                {
                                    var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                                    var cmd = JsonSerializer.Deserialize<GameSyncCommand>(message, options);
                                    if (cmd != null && !string.IsNullOrEmpty(cmd.ActionType))
                                    {
                                        ExecuteSyncCommand(cmd);
                                    }
                                }
                                catch
                                {
                                    TxtRadioLog.Text += $"\n[乱码或非标指令]: {message}";
                                }
                            });
                        }
                    }
                }
            }
            catch (Exception) { /* 静默处理断线 */ }
        }
        private void ExecuteSyncCommand(GameSyncCommand cmd)
        {
            // ==========================================================
            // 🛡️ 第 1 层：【物理隔离防线】
            // ==========================================================
            if (!string.IsNullOrEmpty(cmd.RoomId) && cmd.RoomId != currentRoomId) return;

            // ==========================================================
            // 📡 第 2 层：【雷达身份嗅探】
            // ==========================================================
            if (cmd.Sender != TxtPlayerName.Text && cmd.Sender != "SERVER(总部服务器)" && !string.IsNullOrEmpty(cmd.Sender))
            {
                partnerName = cmd.Sender;
            }

            // ==========================================================
            // 🛑 第 3 层：【安检与生命线拦截】 
            // ==========================================================
            if (cmd.ActionType == "WRONG_PASSWORD")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (webSocket != null) { webSocket.Abort(); webSocket.Dispose(); webSocket = null; }
                    if (heartbeatTimer != null) heartbeatTimer.Stop();

                    BtnJoinRoom.Content = "📡 进 驻 战 区";
                    BtnJoinRoom.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));
                    BtnJoinRoom.IsEnabled = true;
                    TxtRoomId.IsEnabled = true;
                    if (TxtRoomPassword != null) TxtRoomPassword.IsEnabled = true;

                    MessageBox.Show($"进驻战区 [{currentRoomId}] 失败！\n\n机密口令不正确。", "访问被拒绝", MessageBoxButton.OK, MessageBoxImage.Error);
                    currentRoomId = ""; currentRoomPassword = "";
                });
                return;
            }

            if (cmd.ActionType == "ROOM_FULL")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (webSocket != null) { webSocket.Abort(); webSocket.Dispose(); webSocket = null; }
                    if (heartbeatTimer != null) heartbeatTimer.Stop();

                    BtnJoinRoom.Content = "📡 进 驻 战 区";
                    BtnJoinRoom.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));
                    BtnJoinRoom.IsEnabled = true; TxtRoomId.IsEnabled = true;
                    if (TxtRoomPassword != null) TxtRoomPassword.IsEnabled = true;

                    MessageBox.Show($"战区 [{currentRoomId}] 已经满员！", "战区满员", MessageBoxButton.OK, MessageBoxImage.Warning);
                    currentRoomId = "";
                });
                return;
            }

            if (cmd.ActionType == "PLAYER_LEFT")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    isPartnerDisconnected = true;
                    if (PauseGameBtn != null) { PauseGameBtn.Content = "⚠️ 僚机断连 (单飞模式)"; PauseGameBtn.Background = Brushes.DarkGoldenrod; }

                    if (GameOverOverlay.Visibility == Visibility.Visible)
                    {
                        if (BtnUploadReport != null) { BtnUploadReport.IsEnabled = true; BtnUploadReport.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC")); }
                        if (SubmitScoreBtn != null) { SubmitScoreBtn.IsEnabled = true; SubmitScoreBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF8C00")); }
                        MessageBox.Show("🚨 僚机已断开连接！您已自动获得最高上传授权。", "紧急接管", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        TxtRadioLog.Text += "\n⚠️ [系统警报]: 僚机已断线！您已接管全盘指挥权，请随时准备为僚机提供快照！";
                        if (TxtRadioLog.Parent is ScrollViewer svLog) svLog.ScrollToBottom();
                        MessageBox.Show("🚨 僚机失联！\n\n【代号：凤凰】重连协议已就绪。请继续营运，僚机重连时会自动全息同步！", "僚机失联", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                });
                return;
            }

            // ==========================================================
            // 🔁 第 4 层：【大厅进驻与“代号凤凰”重连系统】 (🌟已彻底剔除GMap🌟)
            // ==========================================================
            if (cmd.ActionType == "JOIN_ROOM")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (cmd.Sender == TxtPlayerName.Text)
                    {
                        BtnJoinRoom.Content = "✅ 已进驻"; BtnJoinRoom.Background = Brushes.SeaGreen;
                        BtnReady.IsEnabled = true; BtnReady.Background = Brushes.DarkGoldenrod;
                        if (BtnLeaveRoom != null) BtnLeaveRoom.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        if (isGameStarted)
                        {
                            isPartnerDisconnected = false;
                            TxtRadioLog.Text += $"\n📡 侦测到僚机 [{partnerName}] 重连！正在打包图纸状态...";

                            try
                            {
                                var state = new FullStateDTO
                                {
                                    Funds = playerFunds,
                                    Pax = totalTransportedPax,
                                    Ticks = gameVirtualTime.Ticks,
                                    IsPaused = isPaused,
                                    Airports = allAirportsList,
                                    Routes = activeRoutes.Select(r => new SyncRouteDTO { StartName = r.StartAirport.Name, EndName = r.EndAirport.Name }).ToList(),
                                    Flights = flyingPlanes.Select(f => new SyncFlightDTO { StartName = f.StartAirport.Name, EndName = f.EndAirport.Name, Progress = f.Progress, Passengers = f.Passengers, ExpectedProfit = f.ExpectedProfit, FlightCode = f.FlightCode, PhysicalPlane = f.PhysicalPlane }).ToList()
                                };
                                string jsonState = System.Text.Json.JsonSerializer.Serialize(state, new System.Text.Json.JsonSerializerOptions { PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase });

                                TxtRadioLog.Text += $"\n📦 [系统提示]: 快照发射！";
                                _ = SendCommandAsync("SYNC_FULL_STATE", "", jsonState);
                            }
                            catch (Exception ex) { MessageBox.Show($"打包失败：{ex.Message}"); }
                        }
                        else
                        {
                            TxtRadioLog.Text += $"\n✅ 僚机 [{partnerName}] 已进入战区。";
                        }
                        if (TxtRadioLog.Parent is ScrollViewer svLog) svLog.ScrollToBottom();
                    }
                });
                return;
            }

            if (cmd.ActionType == "SYNC_FULL_STATE")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    try
                    {
                        var options = new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                        var state = System.Text.Json.JsonSerializer.Deserialize<FullStateDTO>(cmd.AdditionalData, options);

                        if (allAirportsList == null || allAirportsList.Count == 0) { LoadDataBtn_Click(null, null); }

                        playerFunds = state.Funds; totalTransportedPax = state.Pax; gameVirtualTime = new DateTime(state.Ticks);
                        isPaused = state.IsPaused; TxtFunds.Text = $"💰 资金: {playerFunds:N0}";

                        foreach (var syncApt in state.Airports)
                        {
                            var localApt = allAirportsList.FirstOrDefault(a => a.Name == syncApt.Name);
                            if (localApt != null)
                            {
                                localApt.Level = syncApt.Level; localApt.CurrentPassengers = syncApt.CurrentPassengers;
                                localApt.Profit = syncApt.Profit; localApt.LocalFleet = syncApt.LocalFleet; localApt.Demands = syncApt.Demands;
                            }
                        }

                        // 🌟 核心重绘
                        DrawAirportsOnBlueprint();
                        activeRoutes.Clear(); flyingPlanes.Clear();

                        Color[] neonColors = { Color.FromArgb(200, 0, 255, 255), Color.FromArgb(200, 255, 0, 255), Color.FromArgb(200, 255, 165, 0), Color.FromArgb(200, 50, 255, 50) };

                        // 🌟 重建航线
                        foreach (var rData in state.Routes)
                        {
                            var startApt = allAirportsList.FirstOrDefault(a => a.Name == rData.StartName);
                            var endApt = allAirportsList.FirstOrDefault(a => a.Name == rData.EndName);

                            if (startApt != null && endApt != null)
                            {
                                double dist = CalculateDistance(startApt.Lat, startApt.Lng, endApt.Lat, endApt.Lng);
                                Color routeColor = neonColors[randomEngine.Next(neonColors.Length)];

                                System.Windows.Shapes.Path routePath = new System.Windows.Shapes.Path
                                {
                                    Stroke = new SolidColorBrush(routeColor),
                                    StrokeThickness = 2,
                                    StrokeDashArray = new DoubleCollection { 4, 3 },
                                    Effect = new System.Windows.Media.Effects.DropShadowEffect { Color = routeColor, BlurRadius = 10, ShadowDepth = 0 }
                                };

                                double midX = (startApt.ScreenX + endApt.ScreenX) / 2.0; double midY = (startApt.ScreenY + endApt.ScreenY) / 2.0;
                                double dx = endApt.ScreenX - startApt.ScreenX; double dy = endApt.ScreenY - startApt.ScreenY;
                                double ctrlX = midX - dy * 0.2; double ctrlY = midY + dx * 0.2;

                                PathGeometry geo = new PathGeometry();
                                PathFigure fig = new PathFigure { StartPoint = new Point(startApt.ScreenX, startApt.ScreenY) };
                                fig.Segments.Add(new QuadraticBezierSegment(new Point(ctrlX, ctrlY), new Point(endApt.ScreenX, endApt.ScreenY), true));
                                geo.Figures.Add(fig); routePath.Data = geo;

                                Canvas.SetZIndex(routePath, -1);
                                MainBlueprint.Children.Add(routePath);
                                activeRoutes.Add(new GameRouteInfo { StartAirport = startApt, EndAirport = endApt, Distance = dist });
                            }
                        }

                        // 🌟 重建空中飞机
                        foreach (var fData in state.Flights)
                        {
                            var startApt = allAirportsList.FirstOrDefault(a => a.Name == fData.StartName);
                            var endApt = allAirportsList.FirstOrDefault(a => a.Name == fData.EndName);
                            if (startApt != null && endApt != null)
                            {
                                double t = fData.Progress, u = 1 - t;
                                double startX = startApt.ScreenX, startY = startApt.ScreenY;
                                double endX = endApt.ScreenX, endY = endApt.ScreenY;

                                double midX = (startX + endX) / 2.0, midY = (startY + endY) / 2.0;
                                double dx = endX - startX, dy = endY - startY;
                                double ctrlX = midX - dy * 0.2, ctrlY = midY + dx * 0.2;

                                double curX = (u * u * startX) + (2 * u * t * ctrlX) + (t * t * endX);
                                double curY = (u * u * startY) + (2 * u * t * ctrlY) + (t * t * endY);
                              
                                // ✅ 正确代码：endY - startY
                                double angle = Math.Atan2(endY - startY, endX - startX) * 180 / Math.PI + 45;
                                TextBlock planeVis = new TextBlock { Text = "✈", FontSize = 22 + (fData.PhysicalPlane.Level * 8), Foreground = Brushes.White, RenderTransformOrigin = new Point(0.5, 0.5), RenderTransform = new RotateTransform(angle), Cursor = Cursors.Hand };
                                Canvas.SetLeft(planeVis, curX - 12); Canvas.SetTop(planeVis, curY - 12);
                                MainBlueprint.Children.Add(planeVis);

                                double speed = 60.0 / CalculateDistance(startApt.Lat, startApt.Lng, endApt.Lat, endApt.Lng);

                                ActiveFlight nFlight = new ActiveFlight { PlaneElement = planeVis, StartAirport = startApt, EndAirport = endApt, Progress = fData.Progress, Speed = speed, Passengers = fData.Passengers, ExpectedProfit = fData.ExpectedProfit, PhysicalPlane = fData.PhysicalPlane, FlightCode = fData.FlightCode };
                                planeVis.Tag = nFlight;
                                planeVis.MouseLeftButtonDown += Flight_MouseLeftButtonDown;

                                flyingPlanes.Add(nFlight);
                            }
                        }

                        isGameStarted = true; isGameOver = false;
                        LoadDataBtn.Content = "🛑 结束游戏"; LoadDataBtn.Background = Brushes.Crimson;
                        BtnReady.Content = "⚔️ 重连成功！"; BtnReady.IsEnabled = false;

                        if (!isPaused) { gameTimer.Start(); animationTimer.Start(); }
                        MessageBox.Show("📡 全息快照图纸同步完成！", "代号：凤凰", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    catch (Exception ex) { MessageBox.Show($"重连解析失败：{ex.Message}"); }
                });
                return;
            }

            // ==========================================================
            // 🔒 第 5 层：【打榜防重复锁】
            // ==========================================================
            if (cmd.ActionType == "LOCK_SUBMIT_BTN")
            {
                Application.Current.Dispatcher.Invoke(() => { if (SubmitScoreBtn != null) { SubmitScoreBtn.IsEnabled = false; SubmitScoreBtn.Content = "🏆 队友已接管"; SubmitScoreBtn.Background = Brushes.Gray; } });
                return;
            }
            else if (cmd.ActionType == "LOCK_UPLOAD_BTN")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (BtnUploadReport != null) { BtnUploadReport.IsEnabled = false; BtnUploadReport.Content = "☁️ 队友正在传黑匣子"; BtnUploadReport.Background = Brushes.Gray; }
                });
                return;
            }

            // ==========================================================
            // 💥 第 6 层：【洗地与对账】
            // ==========================================================
            if (cmd.ActionType == "SYNC_GAME_OVER" || cmd.ActionType == "SYNC_AUTO_GAME_OVER")
            {
                long newFunds = playerFunds, newPax = totalTransportedPax, newTicks = gameVirtualTime.Ticks;
                if (!string.IsNullOrEmpty(cmd.AdditionalData) && cmd.AdditionalData.Contains("|"))
                {
                    string[] parts = cmd.AdditionalData.Split('|');
                    if (parts.Length >= 2) { long.TryParse(parts[0], out newFunds); long.TryParse(parts[1], out newPax); }
                    if (parts.Length >= 3) { long.TryParse(parts[2], out newTicks); }
                }

                bool shouldOverride = cmd.ActionType == "SYNC_GAME_OVER" || (!isGameOver) || (string.Compare(cmd.Sender, TxtPlayerName.Text) < 0);

                if (shouldOverride)
                {
                    playerFunds = newFunds; totalTransportedPax = newPax; gameVirtualTime = new DateTime(newTicks);
                    Application.Current.Dispatcher.Invoke(() => {
                        if (GameOverOverlay.Visibility == Visibility.Visible)
                        {
                            TxtFinalFunds.Text = $"💰 最终结余: ¥ {playerFunds:N0}";
                            TxtFinalPax.Text = $"👥 累计运送: {totalTransportedPax:N0} 人次";
                        }
                    });
                }

                if (!isGameOver)
                {
                    isGameOver = true; isGameStarted = false;
                    var crashedAirport = allAirportsList.FirstOrDefault(a => a.Name == cmd.TargetId);
                    Application.Current.Dispatcher.Invoke(() => {
                        if (gameTimer != null) gameTimer.Stop();
                        if (animationTimer != null) animationTimer.Stop();
                        LoadDataBtn.Content = "🛑 营运已终止"; LoadDataBtn.Background = Brushes.Gray; LoadDataBtn.IsEnabled = false;
                        TriggerGameOver(crashedAirport);
                    });
                }
                return;
            }

            if (isGameOver) return;

            // ==========================================================
            // ⚙️ 第 8 层：【日常战术业务层】 (🌟 完整无缺版 🌟)
            // ==========================================================
            Application.Current.Dispatcher.Invoke(() => {
                TxtRadioLog.Text += $"\n[{cmd.Sender}]: {cmd.ActionType}";
                if (TxtRadioLog.Parent is ScrollViewer sv) sv.ScrollToBottom();
            });

            if (cmd.ActionType == "START_GAME")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    TxtRadioLog.Text += "\n🚀 双方指挥官就绪，图纸沙盘点火！";
                    int seed = 0; if (!string.IsNullOrEmpty(currentRoomId) && int.TryParse(currentRoomId, out int parsedRoomId)) seed = parsedRoomId;
                    randomEngine = new Random(seed);

                    LoadDataBtn.IsEnabled = true; LoadDataBtn.Content = "▶️ 开始调度";
                    LoadDataBtn_Click(null, null);
                    BtnReady.Content = "⚔️ 联机交战中..."; BtnReady.Background = Brushes.DimGray; BtnReady.IsEnabled = false;
                });
            }
            else if (cmd.ActionType == "PAUSE")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (!isGameStarted) return;
                    if (gameTimer != null) gameTimer.Stop();
                    if (animationTimer != null) animationTimer.Stop();
                    isPaused = true;
                    if (PauseGameBtn != null)
                    {
                        PauseGameBtn.Content = "▶️ 解除冻结 (全网 Resume)";
                        PauseGameBtn.Background = Brushes.SeaGreen;
                    }
                });
            }
            else if (cmd.ActionType == "RESUME")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    if (!isGameStarted) return;
                    if (gameTimer != null) gameTimer.Start();
                    if (animationTimer != null) animationTimer.Start();
                    isPaused = false;
                    if (PauseGameBtn != null)
                    {
                        PauseGameBtn.Content = "⏸️ 战术暂停 (全网 Bullet Time)";
                        PauseGameBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF8C00"));
                    }
                });
            }
            else if (cmd.ActionType == "BUY_PLANE")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    var targetAirport = allAirportsList.FirstOrDefault(a => a.Icao == cmd.TargetId || a.Name == cmd.TargetId);
                    if (targetAirport != null)
                    {
                        PlaneModelType boughtModel = PlaneModelType.Regional;
                        if (!string.IsNullOrEmpty(cmd.AdditionalData)) Enum.TryParse(cmd.AdditionalData, out boughtModel);

                        GamePlaneInfo newPlane = new GamePlaneInfo
                        {
                            Id = (boughtModel == PlaneModelType.Supersonic ? "S-" : "B-") + randomEngine.Next(1000, 9999),
                            Model = boughtModel,
                            Level = boughtModel == PlaneModelType.Regional ? 1 : (boughtModel == PlaneModelType.Widebody ? 2 : 3)
                        };

                        playerFunds -= newPlane.Cost;
                        TxtFunds.Text = $"💰 资金: {playerFunds:N0}";

                        targetAirport.LocalFleet.Add(newPlane);

                        TxtRadioLog.Text += $"\n✈️ [军火]: 指挥官 {cmd.Sender} 耗资 ¥{newPlane.Cost / 100000000.0:0.##}亿，为 {targetAirport.Name} 添置了【{newPlane.ModelName}】({newPlane.Id})！";

                        if (currentSelectedAirport != null && currentSelectedAirport.Name == targetAirport.Name)
                        {
                            RefreshPanelUI(targetAirport);
                        }
                    }
                });
            }
            else if (cmd.ActionType == "UPGRADE_BASE")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    var targetAirport = allAirportsList.FirstOrDefault(a => a.Name == cmd.TargetId);
                    if (targetAirport != null && targetAirport.Level < 3)
                    {
                        long upgradeCost = targetAirport.Level == 1 ? 150000000 : 500000000;

                        playerFunds -= upgradeCost;
                        TxtFunds.Text = $"💰 资金: {playerFunds:N0}";
                        if (playerFunds < 0) TxtFunds.Foreground = Brushes.Red;

                        targetAirport.Level += 1;
                        targetAirport.MaxCapacity *= 3;

                        TxtRadioLog.Text += $"\n🏗️ [战报]: 指挥官 {cmd.Sender} 豪掷 ¥{upgradeCost / 100000000.0}亿，将 {targetAirport.Name} 扩建至 Lv.{targetAirport.Level} (容量暴增至 {targetAirport.MaxCapacity})！";

                        if (currentSelectedAirport != null && currentSelectedAirport.Name == targetAirport.Name)
                        {
                            RefreshPanelUI(targetAirport);
                        }
                    }
                });
            }
            else if (cmd.ActionType == "CHANGE_SPEED")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    double speedMode = 1.0;
                    double.TryParse(cmd.TargetId, out speedMode);

                    if (BtnSpeedSlow != null) BtnSpeedSlow.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#444455"));
                    if (BtnSpeedNormal != null) BtnSpeedNormal.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#444455"));
                    if (BtnSpeedFast != null) BtnSpeedFast.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#444455"));

                    if (speedMode == 0.5)
                    {
                        if (gameTimer != null) gameTimer.Interval = TimeSpan.FromMilliseconds(2000);
                        if (animationTimer != null) animationTimer.Interval = TimeSpan.FromMilliseconds(100);
                        if (BtnSpeedSlow != null) BtnSpeedSlow.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF8C00"));
                        TxtRadioLog.Text += $"\n🐢 [战报]: 指挥官 {cmd.Sender} 启动了时间缓速场 (0.5x)！";
                    }
                    else if (speedMode == 2.0)
                    {
                        if (gameTimer != null) gameTimer.Interval = TimeSpan.FromMilliseconds(500);
                        if (animationTimer != null) animationTimer.Interval = TimeSpan.FromMilliseconds(50);
                        if (BtnSpeedFast != null) BtnSpeedFast.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF8C00"));
                        TxtRadioLog.Text += $"\n🚀 [战报]: 指挥官 {cmd.Sender} 启动了时间加速引擎 (2.0x)！";
                    }
                    else
                    {
                        if (gameTimer != null) gameTimer.Interval = TimeSpan.FromMilliseconds(1000);
                        if (animationTimer != null) animationTimer.Interval = TimeSpan.FromMilliseconds(50);
                        if (BtnSpeedNormal != null) BtnSpeedNormal.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007ACC"));
                        TxtRadioLog.Text += $"\n▶️ [战报]: 指挥官 {cmd.Sender} 将时间流速重置为标准频率 (1.0x)。";
                    }
                });
            }
            else if (cmd.ActionType == "OPEN_ROUTE")
            {
                Application.Current.Dispatcher.Invoke(() => {
                    string srcName = cmd.TargetId; string destName = cmd.AdditionalData;

                    var startApt = allAirportsList.FirstOrDefault(a => a.Name == srcName);
                    var endApt = allAirportsList.FirstOrDefault(a => a.Name == destName);

                    if (startApt != null && endApt != null && !activeRoutes.Any(r => r.StartAirport == startApt && r.EndAirport == endApt))
                    {
                        double dist = CalculateDistance(startApt.Lat, startApt.Lng, endApt.Lat, endApt.Lng);
                        long routeCost = (long)(dist * 5000);

                        playerFunds -= routeCost; TxtFunds.Text = $"💰 资金: {playerFunds:N0}";
                        if (playerFunds < 0) TxtFunds.Foreground = Brushes.Red;

                        Color[] neonColors = { Color.FromArgb(200, 0, 255, 255), Color.FromArgb(200, 255, 0, 255), Color.FromArgb(200, 255, 165, 0), Color.FromArgb(200, 50, 255, 50) };
                        Color routeColor = neonColors[randomEngine.Next(neonColors.Length)];

                        System.Windows.Shapes.Path routePath = new System.Windows.Shapes.Path
                        {
                            Stroke = new SolidColorBrush(routeColor),
                            StrokeThickness = 2,
                            StrokeDashArray = new DoubleCollection { 4, 3 },
                            Effect = new System.Windows.Media.Effects.DropShadowEffect { Color = routeColor, BlurRadius = 10, ShadowDepth = 0 }
                        };

                        double midX = (startApt.ScreenX + endApt.ScreenX) / 2.0; double midY = (startApt.ScreenY + endApt.ScreenY) / 2.0;
                        double dx = endApt.ScreenX - startApt.ScreenX; double dy = endApt.ScreenY - startApt.ScreenY;
                        double ctrlX = midX - dy * 0.2; double ctrlY = midY + dx * 0.2;

                        PathGeometry geo = new PathGeometry();
                        PathFigure fig = new PathFigure { StartPoint = new Point(startApt.ScreenX, startApt.ScreenY) };
                        fig.Segments.Add(new QuadraticBezierSegment(new Point(ctrlX, ctrlY), new Point(endApt.ScreenX, endApt.ScreenY), true));
                        geo.Figures.Add(fig); routePath.Data = geo;

                        double tangentX = (endApt.ScreenX - startApt.ScreenX) + 2 * (ctrlX - midX);
                        double tangentY = (endApt.ScreenY - startApt.ScreenY) + 2 * (ctrlY - midY);
                        double arrowAngle = Math.Atan2(tangentY, tangentX) * 180 / Math.PI;

                        double arrowX = (0.25 * startApt.ScreenX) + (0.5 * ctrlX) + (0.25 * endApt.ScreenX);
                        double arrowY = (0.25 * startApt.ScreenY) + (0.5 * ctrlY) + (0.25 * endApt.ScreenY);

                        TextBlock arrowVis = new TextBlock
                        {
                            Text = "➤",
                            FontSize = 16,
                            Foreground = new SolidColorBrush(routeColor),
                            RenderTransformOrigin = new Point(0.5, 0.5),
                            RenderTransform = new RotateTransform(arrowAngle),
                            IsHitTestVisible = false
                        };

                        Canvas.SetZIndex(routePath, 1);
                        Canvas.SetZIndex(arrowVis, 2);
                        Canvas.SetLeft(arrowVis, arrowX - 8); 
                        Canvas.SetTop(arrowVis, arrowY - 10);
                        MainBlueprint.Children.Add(routePath); MainBlueprint.Children.Add(arrowVis);

                        activeRoutes.Add(new GameRouteInfo { StartAirport = startApt, EndAirport = endApt, Distance = dist });

                        TxtRadioLog.Text += $"\n🔗 [战报]: 指挥官 {cmd.Sender} 耗资 ¥{routeCost:N0}，打通了 {srcName} ⇌ {destName} 的航线！";
                    }
                });
            }
        }
    }
}
